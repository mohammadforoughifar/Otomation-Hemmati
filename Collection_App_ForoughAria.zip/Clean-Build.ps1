# اسکریپت پاک‌سازی bin/obj و رفع خطای webcil در Blazor WebAssembly
# قبل از اجرا، Visual Studio را ببندید.
Write-Host "در حال حذف پوشه‌های bin و obj ..." -ForegroundColor Cyan
Get-ChildItem -Path $PSScriptRoot -Recurse -Directory -Include bin,obj |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "پاک‌سازی کامل شد. در حال بیلد مجدد ..." -ForegroundColor Green
dotnet build "$PSScriptRoot\inventory\Inventory.sln"
