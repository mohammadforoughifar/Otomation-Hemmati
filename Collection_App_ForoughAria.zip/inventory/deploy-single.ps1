# deploy-single.ps1
# استقرار تک‌سروره در ویندوز: پابلیش کلاینت Blazor و کپی آن در wwwroot مربوط به API + پابلیش نهایی سرور
# خروجی آماده کپی به سرور: پوشه publish\server
# آدرس سرور (طبق appsettings.json -> Server:Port): http://192.168.30.104:8091
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "==> Publishing Blazor client..." -ForegroundColor Cyan
dotnet publish src/Inventory.Client -c Release -o publish/client
if ($LASTEXITCODE -ne 0) { throw "Publish failed" }

Write-Host "==> Copying static files into src/Inventory.Api/wwwroot ..." -ForegroundColor Cyan
$dest = Join-Path $PSScriptRoot "src/Inventory.Api/wwwroot"
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
New-Item -ItemType Directory -Path $dest | Out-Null
Copy-Item -Path (Join-Path $PSScriptRoot "publish/client/wwwroot/*") -Destination $dest -Recurse -Force

Write-Host "==> Publishing API (+client) for the server -> publish/server ..." -ForegroundColor Cyan
dotnet publish src/Inventory.Api -c Release -o publish/server
if ($LASTEXITCODE -ne 0) { throw "API publish failed" }

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
Write-Host "---------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "برای اجرای محلی روی همین سیستم:" -ForegroundColor White
Write-Host "    cd src\Inventory.Api" -ForegroundColor Yellow
Write-Host "    dotnet run" -ForegroundColor Yellow
Write-Host "    مرورگر: http://localhost:5100" -ForegroundColor Cyan
Write-Host ""
Write-Host "برای کپی به سرور (http://192.168.30.104:8091):" -ForegroundColor White
Write-Host "    ۱) کل محتویات پوشه publish\server را به پوشه‌ای روی سرور کپی کنید" -ForegroundColor Yellow
Write-Host "    ۲) روی سرور: Inventory.Api.exe را اجرا کنید (کنسول یا Windows Service)" -ForegroundColor Yellow
Write-Host "    ۳) فایروال ویندوز سرور — باز کردن پورت 8091:" -ForegroundColor Yellow
Write-Host '       New-NetFirewallRule -DisplayName "Inventory 8091" -Direction Inbound -Protocol TCP -LocalPort 8091 -Action Allow' -ForegroundColor Magenta
Write-Host "    ۴) مرورگر: http://192.168.30.104:8091" -ForegroundColor Cyan
Write-Host "---------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "نکته: پورت سرور از appsettings.json (Server:Port=8091) خوانده می‌شود" -ForegroundColor DarkYellow
Write-Host "      و رشته اتصال دیتابیس سرور هم از همان فایل (ConnectionStrings:Default)." -ForegroundColor DarkYellow
Write-Host ""
Write-Host "⚠️  بسیار مهم — پیوست‌های پروژه (تصاویر/مستندات):" -ForegroundColor Red -BackgroundColor Black
Write-Host "   فایل‌های رمزنگاری‌شده پیوست‌ها روی سرور داخل wwwroot\SecureFiles ذخیره می‌شوند." -ForegroundColor DarkYellow
Write-Host "   هنگام آپدیت نسخه روی سرور، این پوشه را پاک یا جایگزین نکنید؛ اول از آن بکاپ بگیرید:" -ForegroundColor DarkYellow
Write-Host '   Copy-Item -Recurse wwwroot\SecureFiles D:\Backup\SecureFiles_$(Get-Date -Format yyyyMMdd_HHmm)' -ForegroundColor Magenta
Write-Host "   (بدون فایل .key داخل آن پوشه، پیوست‌های قبلی غیرقابل بازگشتی خواهند بود)" -ForegroundColor DarkYellow
