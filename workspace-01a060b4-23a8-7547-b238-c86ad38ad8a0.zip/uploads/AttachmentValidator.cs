﻿using CoreApp.DTOs.IService.IAriyaServices;
using CoreApp.DTOs.ViewModel;
using DataLayerApp.Configuration.Ariya;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.Service.Ariya_Services
{
    public class AttachmentValidator : IAttachmentValidator
    {
        public ApiModel? Validate(IFormFile file, AttachmentSettings settings)
        {
            if (file == null)
                return Error(
                    "فایل معتبر نیست.");

            if (file.Length == 0)
                return Error(
                    "فایل خالی است.");

            var originalFileName =
                Path.GetFileName(file.FileName);

            if (string.IsNullOrWhiteSpace(originalFileName))
                return Error(
                    "نام فایل معتبر نیست.");

            var extension =
                Path.GetExtension(originalFileName)
                    .ToLowerInvariant();

            bool isImage =
                settings.AllowedImageExtensions
                    .Contains(extension);

            bool isDocument =
                settings.AllowedDocumentExtensions
                    .Contains(extension);

            if (!isImage && !isDocument)
                return Error(
                    $"پسوند {extension} مجاز نیست.");

            long maxSize =
                isImage
                    ? settings.MaxImageSize
                    : settings.MaxDocumentSize;

            if (file.Length > maxSize)
                return Error(
                    $"حداکثر حجم مجاز فایل {(maxSize / 1024 / 1024)} MB است.");

            return null;
        }
        private static ApiModel Error(
     string message)
        {
            return new ApiModel
            {
                Success = false,
                Status = 400,
                Message = message
            };
        }
    }
}

