﻿using DataLayerApp.Entites.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation
{
    public class Bayegani
    {
        public int Baygani_Id { get; set; }
        public string Title { get; set; }
        public int Parent_Id { get; set; }
        public int TypeBayegani { get; set; }
        public bool Is_Folder { get; set; }
        #region Relation
        public int Sematid { get; set; }
        public Semats Semats { get; set; }


        public Guid Userid { get; set; }
        public User User { get; set; }


        public int? ErjaId { get; set; }
        public Erja? Erja { get; set; }
        #endregion
        public bool IsDelete { get; set; }
    }
}
