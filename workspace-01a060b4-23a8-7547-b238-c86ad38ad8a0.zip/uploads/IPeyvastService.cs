﻿using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using DataLayerApp.Entites.Otomation;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CoreApp.DTOs.ViewModel.VMOtomations.VMPeyvast;

namespace CoreApp.DTOs.IService.IserviceOtomation
{
    public interface IPeyvastService
    {
        Task<ApiModel> AddPeyvastAsync(
        VMPeyvastUpload model);

        Task<ApiModel> DeletePeyvastWithSourceId(
            int sourceId);

        Task<List<int>> DeletePeyvastWithSourceIdAsync(
            int sourceId);

        Task<ApiModel> DownloadPeyvastAsync(
            int peyvastId);

        Task<ApiModel> GetPeyvastByIdAsync(
            int sourceId,
            GetResultQuery request);

    }
}
