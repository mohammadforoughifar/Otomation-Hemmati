﻿using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using Microsoft.AspNetCore.Mvc;
using PaginationSample.Models;

namespace WebAppApi.Controllers.ControllerV1.OtoController
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArchiveController(IArchive archive) : ControllerBase
    {

        [HttpGet]
        public async Task<IResult> GetAll(
            [FromQuery] GetResultQuery request)
        {
            var model = await archive.GetBayegani(request);

            if (model.Success &&
                model.Data is PagedList<TreeNodeBayegani> result)
            {
                foreach (var item in result.Items)
                {
                    item.Links = new List<Links>
                    {
                        new Links
                        {
                            Href = Url.Action(
                                nameof(GetBayegani),
                                ControllerContext.ActionDescriptor.ControllerName,
                                new
                                {
                                    version = "1",
                                    id = item.Baygani_Id
                                },
                                Request.Scheme),
                            Rel = "Self",
                            Method = "GET"
                        },

                        new Links
                        {
                            Href = Url.Action(
                                nameof(Deletearchive),
                                ControllerContext.ActionDescriptor.ControllerName,
                                new
                                {
                                    version = "1",
                                    id = item.Baygani_Id
                                },
                                Request.Scheme),
                            Rel = "Delete",
                            Method = "DELETE"
                        }
                    };
                }
            }

            return Results.Ok(model);
        }



        [HttpGet("{id}")]
        public async Task<ApiModel> GetBayegani(int id)
        {
            return await archive.GetBayeganiAsync(id);
        }


        [HttpPost("letter")]
        public async Task<ApiModel> AddLetterToArchiv(
            BayeganiRequest request)
        {
            var result = await archive.AddLetterToArchiv(request);

            AddSelfLink(result);

            return result;
        }



        [HttpPost("sub-category")]
        public async Task<ApiModel> AddSubCategory(
            BayeganiRequest request)
        {
            var result = await archive.AddSubCategory(request);

            AddSelfLink(result);

            return result;
        }

        [HttpPost("main-category")]
        public async Task<ApiModel> AddMainCategory(
            BayeganiRequest request)
        {
            var result = await archive.AddMainCategory(request);

            AddSelfLink(result);

            return result;
        }

        [HttpPost("move-folder/{id}")]
        public async Task<ApiModel> MoveFolder(
            int id,
            [FromQuery] int newParentId)
        {
            var result = await archive.MoveFolder(
                id,
                newParentId);

            AddSelfLink(result);

            return result;
        }



        [HttpPut("letter/{id}")]
        public async Task<ApiModel> EditLetterToArchiv(
            int id,
            BayeganiRequest request)
        {
            var result = await archive.EditLetterToArchiv(
                id,
                request);

            AddSelfLink(result);

            return result;
        }

        [HttpPut("sub-category/{id}")]
        public async Task<ApiModel> EditSubCategory(
            int id,
            BayeganiRequest request)
        {
            var result = await archive.EditSubCategory(
                id,
                request);

            AddSelfLink(result);

            return result;
        }



        [HttpPut("main-category/{id}")]
        public async Task<ApiModel> EditMainCategory(
            int id,
            BayeganiRequest request)
        {
            var result = await archive.EditMainCategory(
                id,
                request);

            AddSelfLink(result);

            return result;
        }


    
        [HttpDelete("{id}")]
        public async Task<ApiModel> Deletearchive(int id)
        {
            return await archive.DeleteBayegani(id);
        }
        private void AddSelfLink(ApiModel result)
        {
            if (result.Success &&
                result.Data is TreeNodeBayegani data)
            {
                data.Links = new List<Links>
                {
                    new Links
                    {
                        Href = Url.Action(
                            nameof(GetBayegani),
                            ControllerContext.ActionDescriptor.ControllerName,
                            new
                            {
                                version = "1",
                                id = data.Baygani_Id
                            },
                            Request.Scheme),
                        Rel = "Self",
                        Method = "GET"
                    }
                };
            }
        }
    }
}