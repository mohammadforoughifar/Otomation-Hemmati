﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class TreeNodeBayegani
    {
        public int Baygani_Id { get; set; }

        public string Title { get; set; }

        public int Parent_Id { get; set; }

        public int TypeBayegani { get; set; }

        public bool Is_Folder { get; set; }

        public int Sematid { get; set; }

        public Guid Userid { get; set; }

        public int? ErjaId { get; set; }

        public IEnumerable<Links> Links { get; set; } = new List<Links>();

        public List<TreeNodeBayegani> Children { get; set; } = new();
    }
}
