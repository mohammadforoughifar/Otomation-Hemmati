﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class DownloadFileVM
    {
        // محتوای واقعی فایل بعد از رمزگشایی
        public Stream FileStream { get; set; }

        // نام فایل برای دانلود
        public string FileName { get; set; }

        // نوع فایل
        public string ContentType { get; set; }
    }
}
