﻿using CoreApp.DTOs.ViewModel;
using DataLayerApp.Configuration.Ariya;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.IService.IAriyaServices
{
    public interface IAttachmentValidator
    {
        ApiModel? Validate(
       IFormFile file,
       AttachmentSettings settings);
    }
}
