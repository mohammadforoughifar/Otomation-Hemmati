﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMPeyvastUpload
    {
        /// <summary>
        /// شناسه نامه
        /// </summary>
        public int letterId { get; set; }

        /// <summary>
        /// شناسه سمت کاربر
        /// </summary>
        public int Sematid { get; set; }

        /// <summary>
        /// شناسه کاربر
        /// </summary>
        public Guid UserId { get; set; }

        /// <summary>
        /// فایل‌های ارسالی
        /// </summary>
        public List<IFormFile> AttachFiles { get; set; } = [];
    }
}
