﻿using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using DataLayerApp.Entites.Base;
using Microsoft.AspNetCore.Mvc;
using PaginationSample.Models;
using static CoreApp.DTOs.ViewModel.VMOtomations.VMPeyvast;

namespace WebAppApi.Controllers.ControllerV1.OtoController
{
    [Route("api/[controller]")]
    [ApiController]
    public class Peyvast_Controller(
        IPeyvastService peyvastService)
        : ControllerBase
    {
        #region Get List

        [HttpGet("ByLetter/{letterId}")]
        public async Task<ApiModel> GetPeyvastById(
            int letterId,
            [FromQuery] GetResultQuery request)
        {
            var model =
                await peyvastService.GetPeyvastByIdAsync(
                    letterId,
                    request);

            if (model.Success &&
                model.Data is PagedList<VMListPeyvast> result)
            {
                foreach (var item in result.Items)
                {
                    item.Links = new List<Links>
                    {
                        new()
                        {
                            Href = Url.Action(
                                nameof(GetPeyvastById),
                                "Peyvast_Controller",
                                new
                                {
                                    letterId
                                },
                                Request.Scheme),

                            Rel = "Self",
                            Method = "GET"
                        },

                        new()
                        {
                            Href = Url.Action(
                                nameof(DownloadPeyvast),
                                "Peyvast_Controller",
                                new
                                {
                                    peyvastId = item.Peyvast_Id
                                },
                                Request.Scheme),

                            Rel = "Download",
                            Method = "GET"
                        },

                        new()
                        {
                            Href = Url.Action(
                                nameof(Delete),
                                "Peyvast_Controller",
                                new
                                {
                                    sourceId = letterId
                                },
                                Request.Scheme),

                            Rel = "Delete",
                            Method = "DELETE"
                        }
                    };
                }
            }

            return model;
        }

        #endregion

        //------------------------------------------------------------

        #region Upload

        /// <summary>
        /// ثبت یک یا چند پیوست
        /// </summary>

        [HttpPost]

        [RequestFormLimits(
            MultipartBodyLengthLimit = 250_000_000)]

        [RequestSizeLimit(
            250_000_000)]

        public async Task<ApiModel> Post(
            [FromForm] VMPeyvastUpload model)
        {
            return await peyvastService
                .AddPeyvastAsync(model);
        }

        #endregion

        //------------------------------------------------------------

        #region Download

        [HttpGet("Download/{peyvastId}")]
        public async Task<IActionResult> DownloadPeyvast(
            int peyvastId)
        {
            var model =
                await peyvastService
                    .DownloadPeyvastAsync(peyvastId);

            if (!model.Success)
                return StatusCode(
                    model.Status,
                    model);

            if (model.Data is not DownloadFileVM file)
                return NotFound(model);

            return File(
                file.FileStream,
                file.ContentType,
                file.FileName);
        }

        #endregion

        //------------------------------------------------------------

        #region Delete

        [HttpDelete("{sourceId}")]

        public async Task<ApiModel> Delete(
            int sourceId)
        {
            return await peyvastService
                .DeletePeyvastWithSourceId(
                    sourceId);
        }

        #endregion
    }
}