﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMPeyvast
    {
        public class FileDetail
        {
            public string? FileName { get; set; }
            public string? DisplayName { get; set; }
            public byte[]? FileContent { get; set; }
        }
        public class VMListPeyvast
        {
            public int Peyvast_Id { get; set; }
            public string name_frstnde { get; set; }
            public string name_peyvast { get; set; }
            public IEnumerable<Links> Links { get; set; }
        }
    }
}
