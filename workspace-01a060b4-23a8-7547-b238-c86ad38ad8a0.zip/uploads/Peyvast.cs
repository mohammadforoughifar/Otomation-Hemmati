﻿using DataLayerApp.Entites.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation
{
    public class Peyvast
    {
        public int Peyvast_Id { get; set; }

        public int Type_Form { get; set; }

        public int SourceId { get; set; }

        public int SematId { get; set; }

        public Guid UserId { get; set; }

        // نام اصلی فایل (Encrypt شده)
        public string Peyvast_Name { get; set; }

        // نام واقعی فایل روی هارد
        public string StoredFileName { get; set; }

        public string Extension { get; set; }

        public long FileSize { get; set; }

        public bool IsDelete { get; set; }

        #region Relations

        [ForeignKey(nameof(SematId))]
        public Semats Semat { get; set; }

        [ForeignKey(nameof(UserId))]
        public User User { get; set; }

        [ForeignKey(nameof(SourceId))]
        public SourceKeyID Source { get; set; }

        #endregion
    }
}
