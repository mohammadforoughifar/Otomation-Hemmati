﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class BayeganiRequest
    {
        public string Title { get; set; }

        public int Parent_Id { get; set; }

        public int TypeBayegani { get; set; }

        public bool Is_Folder { get; set; }

        public int Sematid { get; set; }

        public Guid Userid { get; set; }

        public List<int> ErjaIds { get; set; } = new();
    }
}
