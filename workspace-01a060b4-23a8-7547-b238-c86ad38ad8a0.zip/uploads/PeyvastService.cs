﻿using Company.FileProtection.Abstractions;
using CoreApp.DTOs.IService.IAriyaServices;
using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Configuration.Ariya;
using Microsoft.AspNetCore.StaticFiles;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base.BaseEntitiesProvider;
using DataLayerApp.Entites.Otomation;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PaginationSample.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CoreApp.DTOs.ViewModel.VMOtomations.VMPeyvast;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class PeyvastService(
    DataContext _context,
    IFileProtectionService _fileProtection,
    ISourceKeyIdService sourceKeyIdService,
    IOptions<AttachmentSettings> options,
    IAttachmentValidator validator)
    : IPeyvastService
    {
        private readonly AttachmentSettings _settings = options.Value;

        private const int BufferSize = 1024 * 1024;
        private static readonly FileExtensionContentTypeProvider contentTypeProvider = new();
        private readonly string _uploadDir = Path.Combine(
            Directory.GetCurrentDirectory(),
            "wwwroot",
            "File",
            "Peyvast");

        #region Add Peyvast

        public async Task<ApiModel> AddPeyvastAsync(
            VMPeyvastUpload model)
        {

            // فایل‌هایی که در صورت خطا باید حذف شوند
            var savedFiles = new List<string>();

            // رکوردهای ثبت شده
            var addedPeyvasts = new List<Peyvast>();

            try
            {
                #region Validation

                if (model.UserId == Guid.Empty)
                    return ErrorResponse(
                        400,
                        "شناسه کاربر معتبر نیست.");

                if (model.letterId <= 0)
                    return ErrorResponse(
                        400,
                        "شناسه نامه معتبر نیست.");

                if (model.AttachFiles == null ||
                    !model.AttachFiles.Any())
                {
                    return ErrorResponse(
                        400,
                        "هیچ فایلی انتخاب نشده است.");
                }

                #endregion


                #region Check Letter

                if (!await sourceKeyIdService
                    .CheckSourceIdAsync(model.letterId))
                {
                    return ErrorResponse(
                        404,
                        "شناسه نامه معتبر نیست.");
                }

                #endregion


                #region User

                var user = await _context.Users
                    .AsNoTracking()
                    .Select(x => new
                    {
                        x.Id,
                        x.FirstName,
                        x.LastName
                    })
                    .FirstOrDefaultAsync(x =>
                        x.Id == model.UserId);

                if (user == null)
                    return ErrorResponse(
                        404,
                        "کاربر یافت نشد.");

                string fullName =
                    $"{user.FirstName} {user.LastName} ({user.Id})";

                #endregion


                Directory.CreateDirectory(_uploadDir);

                #region Upload Files

                foreach (var file in model.AttachFiles)
                {
                    if (file == null ||
                        file.Length == 0)
                        continue;



                    var validation =
                        validator.Validate(
                            file,
                            _settings);

                    if (validation != null)
                        return validation;



                    string originalFileName =
    Path.GetFileName(file.FileName);

                    string extension =
                        Path.GetExtension(originalFileName)
                        .ToLowerInvariant();

                    string encryptedName =
                        SecurityHelper.EncryptString(originalFileName);

                    string storedFileName =
                        $"{Guid.NewGuid():N}.bin";

                    string filePath =
                        Path.Combine(
                            _uploadDir,
                            storedFileName);

                    try
                    {


                        await using var inputStream =
                            file.OpenReadStream();



                        await using var encryptedStream =
                            await _fileProtection
                            .EncryptAsync(
                                inputStream,
                                filePath,
                                fullName);

                        encryptedStream.Position = 0;



                        await using var outputStream =
                            new FileStream(
                                filePath,
                                FileMode.CreateNew,
                                FileAccess.Write,
                                FileShare.None,
                                BufferSize,
                                true);

                        await encryptedStream
                            .CopyToAsync(outputStream);

                        savedFiles.Add(filePath);



                        var peyvast = new Peyvast
                        {
                            SourceId = model.letterId,
                            SematId = model.Sematid,
                            UserId = model.UserId,

                            // نام اصلی فایل (Encrypt)
                            Peyvast_Name = encryptedName,

                            // نام فایل روی هارد
                            StoredFileName = storedFileName,

                            Extension = extension,

                            FileSize = file.Length,

                            Type_Form = 0,

                            IsDelete = false
                        };

                        _context.Peyvast.Add(peyvast);

                        addedPeyvasts.Add(peyvast);
                    }
                    catch
                    {
                        if (File.Exists(filePath))
                            File.Delete(filePath);

                        throw;
                    }
                }

                #endregion


                if (!addedPeyvasts.Any())
                {
                    return ErrorResponse(
                        400,
                        "هیچ فایل معتبری وجود ندارد.");
                }

                //------------------------------------------------
                // ذخیره دیتابیس
                //------------------------------------------------

                await _context.SaveChangesAsync();

                //------------------------------------------------
                // خروجی
                //------------------------------------------------

                var result =
                    addedPeyvasts
                    .Select(x => new VMListPeyvast
                    {
                        Peyvast_Id = x.Peyvast_Id,

                        name_peyvast =
                            SecurityHelper.DecryptString(
                                x.Peyvast_Name),

                        name_frstnde =
                            $"{user.FirstName} {user.LastName}"
                    })
                    .ToList();

                return new ApiModel
                {
                    Success = true,

                    Status = 200,

                    Message =
                        "پیوست‌ها با موفقیت ثبت شدند.",

                    Data = result,

                    TotalCount = result.Count
                };
            }
            catch
            {
                //------------------------------------------------
                // Rollback فایل‌ها
                //------------------------------------------------

                foreach (var file in savedFiles)
                {
                    try
                    {
                        if (File.Exists(file))
                            File.Delete(file);
                    }
                    catch
                    {
                    }
                }

                _context.ChangeTracker.Clear();

                return ErrorResponse(
                    500,
                    "خطا در ذخیره پیوست.");
            }
        }

        #endregion

        #region Delete Peyvast

        public async Task<ApiModel>
            DeletePeyvastWithSourceId(
            int Peyvastid)
        {
            try
            {
                var peyvasts =
                    await _context.Peyvast
                    .Where(x =>
                        x.Peyvast_Id == Peyvastid)
                    .ToListAsync();

                if (!peyvasts.Any())
                {
                    return ErrorResponse(
                        404,
                        "پیوستی برای این نامه یافت نشد.");
                }

               

                foreach (var item in peyvasts)
                {
                    DeletePhysicalFile(
                        item.StoredFileName);
                }

              

                var deletedIds =
                    peyvasts
                    .Select(x => x.Peyvast_Id)
                    .ToList();

                

                _context.Peyvast.RemoveRange(peyvasts);

                await _context.SaveChangesAsync();

                return new ApiModel
                {
                    Success = true,

                    Status = 200,

                    Message =
                        "پیوست‌ها با موفقیت حذف شدند.",

                    Data = deletedIds,

                    TotalCount = deletedIds.Count
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطا در حذف پیوست.");
            }
        }

        #endregion

        #region Delete Peyvast 

        public async Task<List<int>>
            DeletePeyvastWithSourceIdAsync(
            int sourceId)
        {
            var result = new List<int>();

            var peyvasts =
                await _context.Peyvast
                .Where(x => x.SourceId == sourceId)
                .ToListAsync();

            if (!peyvasts.Any())
                return result;

            foreach (var item in peyvasts)
            {
                // حذف فایل فیزیکی
                DeletePhysicalFile(item.StoredFileName);

                result.Add(item.Peyvast_Id);
            }

            _context.Peyvast.RemoveRange(peyvasts);

            return result;
        }

        #endregion

        #region Download Peyvast

        public async Task<ApiModel> DownloadPeyvastAsync(
            int peyvastId)
        {
            try
            {


                var peyvast = await _context.Peyvast
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Peyvast_Id == peyvastId);

                if (peyvast == null)
                {
                    return ErrorResponse(
                        404,
                        "پیوست یافت نشد.");
                }



                var originalFileName =
                    SecurityHelper.DecryptString(
                        peyvast.Peyvast_Name);



                var filePath = Path.Combine(
                _uploadDir,
                peyvast.StoredFileName);

                if (!File.Exists(filePath))
                {
                    return ErrorResponse(
                        404,
                        "فایل روی سرور وجود ندارد.");
                }

                

                await using var encryptedStream =
                    new FileStream(
                        filePath,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read);

                

                var decryptedStream =
                    await _fileProtection.DecryptAsync(
                        encryptedStream,
                        filePath);

                

                return new ApiModel
                {
                    Success = true,

                    Status = 200,

                    Message = "دانلود فایل انجام شد.",

                    Data = new DownloadFileVM
                    {
                        FileStream = decryptedStream,

                        FileName = originalFileName,

                        ContentType =
                          GetContentType(peyvast.Extension)
                    }
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطا در دانلود فایل.");
            }
        }

        #endregion

        #region ContentType

        private static string GetContentType(
            string fileName)
        {
            if (contentTypeProvider.TryGetContentType(
                fileName,
                out var contentType))
            {
                return contentType;
            }

            return "application/octet-stream";
        }

        #endregion
        #region Delete Physical File

        private void DeletePhysicalFile(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                return;

           
            var safeFileName =
                Path.GetFileName(fileName);

            var filePath =
                Path.Combine(
                    _uploadDir,
                    safeFileName);

            if (!File.Exists(filePath))
                return;

            try
            {
                File.Delete(filePath);
            }
            catch
            {
                // در پروژه واقعی Logger استفاده شود.
            }
        }

        #endregion
        #region Get Peyvast List

        public async Task<ApiModel> GetPeyvastByIdAsync(
            int sourceId,
            GetResultQuery request)
        {
            try
            {
                //------------------------------------------------
                // Query
                //------------------------------------------------

                var query = _context.Peyvast
                    .AsNoTracking()
                    .Where(x => x.SourceId == sourceId);

                #region Search

                /*
                 * چون نام فایل Encrypt شده است
                 * Search روی نام فایل امکان پذیر نیست.
                 *
                 * در صورت نیاز باید نام فایل به صورت جداگانه
                 * در دیتابیس ذخیره شود.
                 */

                if (!string.IsNullOrWhiteSpace(request.SearchTerm))
                {
                    var search =
                        request.SearchTerm.Trim();

                    query = query.Where(x =>
                        (x.User.FirstName + " " +
                         x.User.LastName)
                        .Contains(search));
                }

                #endregion

                #region Filter

                if (!string.IsNullOrWhiteSpace(request.FilterColumn) &&
                    !string.IsNullOrWhiteSpace(request.FilterValue))
                {
                    switch (request.FilterColumn
                        .Trim()
                        .ToLowerInvariant())
                    {
                        case "name_frstnde":

                            query = query.Where(x =>
                                (x.User.FirstName + " " +
                                 x.User.LastName)
                                .ToLower()
                                .Trim() ==
                                request.FilterValue
                                .ToLower()
                                .Trim());

                            break;

                        case "type_form":

                            if (int.TryParse(
                                request.FilterValue,
                                out var type))
                            {
                                query = query.Where(x =>
                                    x.Type_Form == type);
                            }

                            break;
                    }
                }

                #endregion

                #region Sort

                query =
                    request.SortOrder?.ToLower() == "desc"
                    ? query.OrderByDescending(x =>
                        x.Peyvast_Id)
                    : query.OrderBy(x =>
                        x.Peyvast_Id);

                #endregion

                //------------------------------------------------
                // Projection
                //------------------------------------------------

                var result =
                    query.Select(x =>
                        new VMListPeyvast
                        {
                            Peyvast_Id =
                                x.Peyvast_Id,

                            name_peyvast =
                                SecurityHelper
                                .DecryptString(
                                    x.Peyvast_Name),

                            name_frstnde =
                                x.User.FirstName +
                                " " +
                                x.User.LastName
                        });

                //------------------------------------------------
                // Paging
                //------------------------------------------------

                var data =
                    await PagedList<VMListPeyvast>
                    .CreateAsync(
                        result,
                        (int)request.Page!,
                        (int)request.PageSize!);

                return new ApiModel
                {
                    Success = true,

                    Status = 200,

                    Message = "عملیات با موفقیت انجام شد.",

                    Data = data
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطا در دریافت اطلاعات.");
            }
        }

        #endregion
        #region Error Response

        private static ApiModel ErrorResponse(
            int status,
            string message)
        {
            return new ApiModel
            {
                Success = false,

                Status = status,

                Message = message,

                Data = null
            };
        }

        #endregion
    }
}

