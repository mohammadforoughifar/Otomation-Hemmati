﻿using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using DataLayerApp.Entites.Otomation;

public interface IArchive
{
    Task<ApiModel> AddLetterToArchiv(BayeganiRequest request);

    Task<ApiModel> EditLetterToArchiv(
        int bayeganiId,
        BayeganiRequest request);

    Task<ApiModel> AddSubCategory(BayeganiRequest request);

    Task<ApiModel> EditSubCategory(
        int bayeganiId,
        BayeganiRequest request);

    Task<ApiModel> AddMainCategory(BayeganiRequest request);

    Task<ApiModel> EditMainCategory(
        int bayeganiId,
        BayeganiRequest request);

    Task<ApiModel> MoveFolder(
        int bayeganiId,
        int newParentId);

    Task<Bayegani?> GetBayeganiEntityAsync(
        int bayeganiId);

    Task<ApiModel> GetBayeganiAsync(
        int bayeganiId);

    Task<ApiModel> GetBayegani(
        GetResultQuery request);

    Task<ApiModel> DeleteBayegani(
        int bayeganiId);
}