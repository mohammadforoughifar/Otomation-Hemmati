﻿using Azure.Core;
using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using DataLayerApp.Context;
using DataLayerApp.Entites.Otomation;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class ArchiveServices(DataContext context) : IArchive
    {

        public async Task<ApiModel> AddLetterToArchiv(BayeganiRequest request)
        {
            try
            {
                // بررسی ورودی
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                // این متد فقط برای نامه است
                if (request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "برای بایگانی نامه، Is_Folder باید false باشد.");
                }

                // حداقل یک نامه باید انتخاب شده باشد
                if (request.ErjaIds == null || !request.ErjaIds.Any())
                {
                    return ErrorResponse(
                        400,
                        "حداقل یک نامه برای بایگانی انتخاب کنید.");
                }

                // اعتبارسنجی اطلاعات عمومی
                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                // حذف شناسه‌های تکراری
                var erjaIds = request.ErjaIds
                    .Distinct()
                    .ToList();

                // بررسی شناسه‌ها
                if (erjaIds.Any(x => x <= 0))
                {
                    return ErrorResponse(
                        400,
                        "یکی از شناسه‌های نامه نامعتبر است.");
                }

                // بررسی اینکه Parent واقعاً یک پوشه فعال است
                var parentExists = await context.Bayeganis
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.Baygani_Id == request.Parent_Id &&
                        x.Is_Folder &&
                        !x.IsDelete);

                if (!parentExists)
                {
                    return ErrorResponse(
                        404,
                        "پوشه مقصد یافت نشد.");
                }

                // نامه‌هایی که قبلاً بایگانی شده‌اند
                var archivedIds = await context.Bayeganis
     .Where(x =>
        x.ErjaId.HasValue &&
        erjaIds.Contains(x.ErjaId.Value) &&
        !x.IsDelete)
    .Select(x => x.ErjaId.Value)
    .ToListAsync();

                if (archivedIds.Any())
                {
                    return ErrorResponse(
                        400,
                        $"برخی از نامه‌ها قبلاً بایگانی شده‌اند: {string.Join(", ", archivedIds)}");
                }

                // دریافت تمام نامه‌ها با یک 
                var erjas = await context.Erja
                    .Where(x =>
                        erjaIds.Contains(x.ErjaId) &&
                        !x.IsDelete)
                    .ToListAsync();

                // پیدا کردن نامه‌های ناموجود
                var missingIds = erjaIds
                    .Except(erjas.Select(x => x.ErjaId))
                    .ToList();

                if (missingIds.Any())
                {
                    return ErrorResponse(
                        404,
                        $"نامه‌های زیر یافت نشدند: {string.Join(", ", missingIds)}");
                }

                // ایجاد رکوردهای بایگانی
                foreach (var erja in erjas)
                {
                    context.Bayeganis.Add(new Bayegani
                    {
                        Title = request.Title.Trim(),
                        ErjaId = erja.ErjaId,
                        Is_Folder = false,
                        Sematid = request.Sematid,
                        Userid = request.Userid,
                        Parent_Id = request.Parent_Id,
                        TypeBayegani = request.TypeBayegani,
                        IsDelete = false
                    });

                    // تغییر وضعیت نامه
                    erja.Is_Bayegani = true;
                }

                // یک بار ذخیره
                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = request,
                    Status = 200,
                    Success = true,
                    Message = "نامه‌ها با موفقیت در بایگانی ثبت شدند."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> EditLetterToArchiv(
            int bayeganiId,
            BayeganiRequest request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه بایگانی نامعتبر است.");
                }

                // این متد فقط برای نامه است
                if (request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "این متد فقط برای ویرایش نامه بایگانی شده است.");
                }

                var isParentFolder = await context.Bayeganis
     .AnyAsync(x =>
         x.Baygani_Id == request.Parent_Id &&
         x.Is_Folder &&
         !x.IsDelete);

                if (!isParentFolder)
                {
                    return ErrorResponse(
                        400,
                        "پوشه والد نمیتواند نامه باشد");
                }

                if (request.Parent_Id < 0)
                    {
                        return ErrorResponse(
                            400,
                        "پوشه مقصد یافت نشد.");
                    }


                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                // دریافت رکورد
                var entity = await GetBayeganiEntityAsync(bayeganiId);

                if (entity == null)
                {
                    return ErrorResponse(
                        404,
                        "نامه بایگانی شده یافت نشد.");
                }

                // رکورد باید نامه باشد
                if (entity.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "رکورد انتخاب‌شده یک پوشه است، نه نامه.");
                }
                entity.Title = request.Title.Trim();
                entity.Sematid = request.Sematid;
                entity.Userid = request.Userid;
                entity.Parent_Id = request.Parent_Id;
                entity.TypeBayegani = request.TypeBayegani;

                // Parent را اینجا تغییر نمی‌دهیم.
                // برای جابجایی از MoveFolder استفاده شود.

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 200,
                    Success = true,
                    Message = "نامه بایگانی شده با موفقیت ویرایش شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> AddSubCategory(BayeganiRequest request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                if (!request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "برای ایجاد زیرپوشه، Is_Folder باید true باشد.");
                }

                if (request.Parent_Id <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه پوشه والد نامعتبر است.");
                }

                // زیرپوشه نباید نامه داشته باشد
                if (request.ErjaIds != null && request.ErjaIds.Any())
                {
                    return ErrorResponse(
                        400,
                        "برای ایجاد زیرپوشه نباید نامه ارسال شود.");
                }

                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                // بررسی Parent
                var parentExists = await context.Bayeganis
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.Baygani_Id == request.Parent_Id &&
                        x.Is_Folder &&
                        !x.IsDelete);

                if (!parentExists)
                {
                    return ErrorResponse(
                        404,
                        "پوشه والد یافت نشد.");
                }

                var entity = new Bayegani
                {
                    Title = request.Title.Trim(),
                    ErjaId = null,
                    Is_Folder = true,
                    Sematid = request.Sematid,
                    Userid = request.Userid,
                    Parent_Id = request.Parent_Id,
                    TypeBayegani = request.TypeBayegani,
                    IsDelete = false
                };

                context.Bayeganis.Add(entity);

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 201,
                    Success = true,
                    Message = "زیرپوشه با موفقیت ایجاد شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> EditSubCategory(
            int bayeganiId,
            BayeganiRequest request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه زیرپوشه نامعتبر است.");
                }

                if (!request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "این متد فقط برای ویرایش زیرپوشه است.");
                }
                if (request.ErjaIds != null && request.ErjaIds.Any())
                {
                    return ErrorResponse(
                        400,
                        "برای ویرایش زیرپوشه نباید نامه ارسال شود.");
                }

                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                var entity = await GetBayeganiEntityAsync(bayeganiId);

                if (entity == null)
                {
                    return ErrorResponse(
                        404,
                        "زیرپوشه یافت نشد.");
                }

                if (!entity.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "رکورد انتخاب‌شده یک پوشه نیست.");
                }

                // فقط مشخصات تغییر می‌کند
                // Parent_Id فقط توسط MoveFolder تغییر می‌کند.
                entity.Title = request.Title.Trim();
                entity.Sematid = request.Sematid;
                entity.Userid = request.Userid;
                entity.TypeBayegani = request.TypeBayegani;

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 200,
                    Success = true,
                    Message = "زیرپوشه با موفقیت ویرایش شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> AddMainCategory(BayeganiRequest request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                if (!request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "دسته اصلی باید از نوع پوشه باشد.");
                }

                // دسته اصلی باید Root باشد
                if (request.Parent_Id != 0)
                {
                    return ErrorResponse(
                        400,
                        "دسته اصلی نباید پوشه والد داشته باشد.");
                }

                if (request.ErjaIds != null && request.ErjaIds.Any())
                {
                    return ErrorResponse(
                        400,
                        "برای ایجاد دسته اصلی نباید نامه ارسال شود.");
                }

                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                var entity = new Bayegani
                {
                    Title = request.Title.Trim(),
                    ErjaId = null,
                    Is_Folder = true,
                    Sematid = request.Sematid,
                    Userid = request.Userid,
                    Parent_Id = 0,
                    TypeBayegani = request.TypeBayegani,
                    IsDelete = false
                };

                context.Bayeganis.Add(entity);

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 201,
                    Success = true,
                    Message = "دسته اصلی با موفقیت ایجاد شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> EditMainCategory(
            int bayeganiId,
            BayeganiRequest request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات ورودی نمی‌تواند خالی باشد.");
                }

                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه دسته اصلی نامعتبر است.");
                }

                if (!request.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "دسته اصلی باید از نوع پوشه باشد.");
                }

                if (request.Parent_Id != 0)
                {
                    return ErrorResponse(
                        400,
                        "دسته اصلی نباید پوشه والد داشته باشد.");
                }

                if (request.ErjaIds != null && request.ErjaIds.Any())
                {
                    return ErrorResponse(
                        400,
                        "برای ویرایش دسته اصلی نباید نامه ارسال شود.");
                }

                var validationResult = Validators(
                    request.Title,
                    request.Sematid,
                    request.Parent_Id,
                    request.Userid,
                    request.TypeBayegani);

                if (!validationResult.Success)
                {
                    return validationResult;
                }

                var entity = await GetBayeganiEntityAsync(bayeganiId);

                if (entity == null)
                {
                    return ErrorResponse(
                        404,
                        "دسته اصلی یافت نشد.");
                }

                if (!entity.Is_Folder || entity.Parent_Id != 0)
                {
                    return ErrorResponse(
                        400,
                        "رکورد انتخاب‌شده دسته اصلی نیست.");
                }

                entity.Title = request.Title.Trim();
                entity.Sematid = request.Sematid;
                entity.Userid = request.Userid;
                entity.TypeBayegani = request.TypeBayegani;

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 200,
                    Success = true,
                    Message = "دسته اصلی با موفقیت ویرایش شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        public async Task<ApiModel> MoveFolder(
            int bayeganiId,
            int newParentId)
        {
            try
            {
                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه پوشه نامعتبر است.");
                }

                if (newParentId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه پوشه مقصد نامعتبر است.");
                }

                if (bayeganiId == newParentId)
                {
                    return ErrorResponse(
                        400,
                        "پوشه نمی‌تواند داخل خودش قرار بگیرد.");
                }

                var entity = await GetBayeganiEntityAsync(bayeganiId);

                if (entity == null)
                {
                    return ErrorResponse(
                        404,
                        "پوشه موردنظر یافت نشد.");
                }

                if (!entity.Is_Folder)
                {
                    return ErrorResponse(
                        400,
                        "رکورد انتخاب‌شده پوشه نیست.");
                }

                // مقصد باید پوشه فعال باشد
                var destinationExists = await context.Bayeganis
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.Baygani_Id == newParentId &&
                        x.Is_Folder &&
                        !x.IsDelete);

                if (!destinationExists)
                {
                    return ErrorResponse(
                        404,
                        "پوشه مقصد یافت نشد.");
                }

                // جلوگیری از Circular Reference
                var createsCycle = await IsDescendantAsync(
                    bayeganiId,
                    newParentId);

                if (createsCycle)
                {
                    return ErrorResponse(
                        400,
                        "پوشه نمی‌تواند داخل یکی از زیرپوشه‌های خودش قرار بگیرد.");
                }

                entity.Parent_Id = newParentId;

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 200,
                    Success = true,
                    Message = "پوشه با موفقیت جابجا شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }


        public async Task<Bayegani?> GetBayeganiEntityAsync(int bayeganiId)
        {
            return await context.Bayeganis
                .SingleOrDefaultAsync(x =>
                    x.Baygani_Id == bayeganiId);
        }


        public async Task<ApiModel> GetBayeganiAsync(int bayeganiId)
        {
            try
            {
                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه دسته‌بندی نامعتبر است.");
                }

                var entity = await context.Bayeganis
                    .AsNoTracking()
                    .SingleOrDefaultAsync(x =>
                        x.Baygani_Id == bayeganiId);

                if (entity == null)
                {
                    return ErrorResponse(
                        404,
                        "دسته‌بندی یافت نشد.");
                }

                return new ApiModel
                {
                    Data = MapToResponse(entity),
                    Status = 200,
                    Success = true,
                    Message = "دسته‌بندی با موفقیت یافت شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }


        public async Task<ApiModel> GetBayegani(GetResultQuery request)
        {
            try
            {
                if (request == null)
                {
                    return ErrorResponse(
                        400,
                        "اطلاعات درخواست نمی‌تواند خالی باشد.");
                }

                // Pagination
                if (request.Page is null || request.Page <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شماره صفحه باید بزرگ‌تر از صفر باشد.");
                }

                if (request.PageSize is null || request.PageSize <= 0)
                {
                    return ErrorResponse(
                        400,
                        "تعداد آیتم‌های صفحه باید بزرگ‌تر از صفر باشد.");
                }

                if (request.PageSize > 100)
                {
                    return ErrorResponse(
                        400,
                        "تعداد آیتم در هر صفحه نمی‌تواند بیشتر از 100 باشد.");
                }

                var query = context.Bayeganis
                    .AsNoTracking();


                // Search
                if (!string.IsNullOrWhiteSpace(request.SearchTerm))
                {
                    var search = request.SearchTerm.Trim();

                    query = query.Where(x =>
                        x.Title.Contains(search));
                }

                // Filter
                if (request.SematId is int sematId)
                {
                    query = query.Where(x =>
                        x.Sematid == sematId);
                }

                if (request.UserId is Guid userId)
                {
                    query = query.Where(x =>
                        x.Userid == userId);
                }

                if (!string.IsNullOrWhiteSpace(request.FilterColumn) &&
                    !string.IsNullOrWhiteSpace(request.FilterValue))
                {
                    var filterColumn =
                        request.FilterColumn.Trim().ToLowerInvariant();

                    var filterValue =
                        request.FilterValue.Trim();

                    switch (filterColumn)
                    {
                        case "title":

                            query = query.Where(x =>
                                x.Title.Contains(filterValue));

                            break;

                        case "isfolder":

                            if (!bool.TryParse(
                                    filterValue,
                                    out var isFolder))
                            {
                                return ErrorResponse(
                                    400,
                                    "مقدار IsFolder باید true یا false باشد.");
                            }

                            query = query.Where(x =>
                                x.Is_Folder == isFolder);

                            break;

                        case "parentid":

                            if (!int.TryParse(
                                    filterValue,
                                    out var parentId))
                            {
                                return ErrorResponse(
                                    400,
                                    "مقدار ParentId نامعتبر است.");
                            }

                            query = query.Where(x =>
                                x.Parent_Id == parentId);

                            break;

                        case "erjaid":

                            if (!int.TryParse(
                                    filterValue,
                                    out var erjaId))
                            {
                                return ErrorResponse(
                                    400,
                                    "مقدار ErjaId نامعتبر است.");
                            }

                            query = query.Where(x =>
    x.ErjaId.HasValue &&
    x.ErjaId.Value == erjaId);

                            break;
                    }
                }

                // Sort
                var sortColumn =
                    request.SortColumn?.Trim().ToLowerInvariant();

                var sortOrder =
                    request.SortOrder?.Trim().ToLowerInvariant();

                switch (sortColumn)
                {
                    case "erjaid":

                        query = sortOrder == "desc"
                            ? query.OrderByDescending(x => x.ErjaId)
                            : query.OrderBy(x => x.ErjaId);

                        break;

                    case "baygani_id":

                        query = sortOrder == "desc"
                            ? query.OrderByDescending(x => x.Baygani_Id)
                            : query.OrderBy(x => x.Baygani_Id);

                        break;

                    case "title":

                        query = sortOrder == "desc"
                            ? query.OrderByDescending(x => x.Title)
                            : query.OrderBy(x => x.Title);

                        break;

                    default:

                        // ترتیب پیش‌فرض برای Pagination پایدار
                        query = query.OrderByDescending(
                            x => x.Baygani_Id);

                        break;
                }


                // Projection
                var dataQuery = query.Select(x => new TreeNodeBayegani
                {
                    Baygani_Id = x.Baygani_Id,
                    Title = x.Title,
                    Parent_Id = x.Parent_Id,
                    TypeBayegani = x.TypeBayegani,
                    Is_Folder = x.Is_Folder,
                    Sematid = x.Sematid,
                    Userid = x.Userid,
                    ErjaId = x.ErjaId
                });

                var data = await PagedList<TreeNodeBayegani>.CreateAsync(
                    dataQuery,
                    request.Page.Value,
                    request.PageSize.Value);

                return new ApiModel
                {
                    Data = data,
                    Status = 200,
                    Success = true,
                    Message = "لیست بایگانی‌ها با موفقیت دریافت شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        // 11. حذف بایگانی

        public async Task<ApiModel> DeleteBayegani(int bayeganiId)
        {
            try
            {
                if (bayeganiId <= 0)
                {
                    return ErrorResponse(
                        400,
                        "شناسه دسته‌بندی نامعتبر است.");
                }

                var bayegani =
                    await GetBayeganiEntityAsync(bayeganiId);

                if (bayegani == null)
                {
                    return ErrorResponse(
                        404,
                        "دسته‌بندی یافت نشد.");
                }

                // اگر پوشه است باید کاملاً خالی باشد
                if (bayegani.Is_Folder)
                {
                    var hasChildren = await context.Bayeganis
                        .AnyAsync(x =>
                            x.Parent_Id == bayeganiId &&
                            !x.IsDelete);

                    if (hasChildren)
                    {
                        return ErrorResponse(
                            400,
                            "این پوشه دارای محتوا یا زیرپوشه است. ابتدا محتویات پوشه را حذف کنید.");
                    }
                }

                // Soft Delete
                bayegani.IsDelete = true;

                // اگر نامه است، وضعیت بایگانی را آزاد کن
                if (bayegani.ErjaId.HasValue)
                {
                    var erja = await context.Erja
                        .SingleOrDefaultAsync(x =>
                            x.ErjaId == bayegani.ErjaId);

                    if (erja != null)
                    {
                        erja.Is_Bayegani = false;
                    }
                }

                await context.SaveChangesAsync();

                return new ApiModel
                {
                    Data = MapToResponse(bayegani),
                    Status = 200,
                    Success = true,
                    Message = bayegani.Is_Folder
                        ? "پوشه با موفقیت حذف شد."
                        : "نامه از بایگانی خارج شد."
                };
            }
            catch
            {
                return ErrorResponse(
                    500,
                    "خطایی در پردازش درخواست رخ داد.");
            }
        }



        private static ApiModel Validators(
            string title,
            int sematId,
            int parentId,
            Guid userId,
            int typeBayegani)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                return ErrorResponse(
                    400,
                    "عنوان را وارد کنید.");
            }

            if (title.Trim().Length > 250)
            {
                return ErrorResponse(
                    400,
                    "عنوان نمی‌تواند بیشتر از 250 کاراکتر باشد.");
            }

            if (sematId <= 0)
            {
                return ErrorResponse(
                    400,
                    "SematId نامعتبر است.");
            }

            if (parentId < 0)
            {
                return ErrorResponse(
                    400,
                    "ParentId نامعتبر است.");
            }

            if (userId == Guid.Empty)
            {
                return ErrorResponse(
                    400,
                    "UserId نامعتبر است.");
            }

            if (typeBayegani < 0)
            {
                return ErrorResponse(
                    400,
                    "TypeBayegani نامعتبر است.");
            }

            return new ApiModel
            {
                Success = true,
                Status = 200,
                Message = "اطلاعات معتبر است.",
                Data = null
            };
        }



        private static ApiModel ErrorResponse(
            int status,
            string message)
        {
            return new ApiModel
            {
                Success = false,
                Status = status,
                Message = message,
                Data = null
            };
        }

        private static TreeNodeBayegani MapToResponse(
            Bayegani entity)
        {
            return new TreeNodeBayegani
            {
                Baygani_Id = entity.Baygani_Id,
                Title = entity.Title,
                Parent_Id = entity.Parent_Id,
                TypeBayegani = entity.TypeBayegani,
                Is_Folder = entity.Is_Folder,
                Sematid = entity.Sematid,
                Userid = entity.Userid,
                ErjaId = entity.ErjaId
            };
        }
        private async Task<bool> IsDescendantAsync(
            int folderId,
            int targetParentId)
        {
            var currentParentId = targetParentId;

            while (currentParentId > 0)
            {
                if (currentParentId == folderId)
                {
                    return true;
                }

                currentParentId = await context.Bayeganis
                    .Where(x =>
                        x.Baygani_Id == currentParentId &&
                        x.Is_Folder &&
                        !x.IsDelete)
                    .Select(x => x.Parent_Id)
                    .FirstOrDefaultAsync();
            }

            return false;
        }
    }
}
