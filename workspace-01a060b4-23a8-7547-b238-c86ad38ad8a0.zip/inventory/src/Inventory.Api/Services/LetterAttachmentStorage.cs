using Inventory.Api.Data;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Services;

// ============================================================
// ذخیره‌سازی پیوست‌های «ماژول اتوماسیون اداری» روی دیسک سمت API
// بر اساس الگوی PeyvastService کارفرما:
//   • فایل با نام تصادفی ({Guid:N}.bin) روی هارد ذخیره می‌شود
//   • محتوای فایل رمزنگاری می‌شود (AES-256-GCM — IProjectFileProtection)
//   • اعتبارسنجی پسوند و حجم قبل از ذخیره (AttachmentValidator)
//   • در صورت خطا فایل‌های نوشته‌شده Rollback (حذف) می‌شوند
//   • دانلود = رمزگشایی و برگرداندن استریم با نام و ContentType اصلی
// فقط ماژول‌های InnerLetters و Pishnevis از این مسیر استفاده می‌کنند؛
// بقیه ماژول‌های سیستم مثل قبل در دیتابیس می‌مانند.
// مسیر فیزیکی: wwwroot/SecureFiles (قابل تغییر با Files:SecureRoot)
// ============================================================

/// <summary>تنظیمات اعتبارسنجی پیوست — معادل AttachmentSettings طرح کارفرما (بخش Attachments در appsettings)</summary>
public class AttachmentSettings
{
    public string[] AllowedImageExtensions { get; set; } =
        { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tif", ".tiff" };

    public string[] AllowedDocumentExtensions { get; set; } =
        { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
          ".txt", ".csv", ".zip", ".rar", ".7z", ".msg", ".eml" };

    /// <summary>حداکثر حجم تصویر (پیش‌فرض ۱۰ مگابایت)</summary>
    public long MaxImageSize { get; set; } = 10 * 1024 * 1024;

    /// <summary>حداکثر حجم سند (پیش‌فرض ۲۰ مگابایت — قاعده مصوب ماژول)</summary>
    public long MaxDocumentSize { get; set; } = 20 * 1024 * 1024;
}

/// <summary>اعتبارسنج پیوست — معادل IAttachmentValidator/AttachmentValidator طرح کارفرما</summary>
public interface ILetterAttachmentValidator
{
    /// <summary>null یعنی معتبر؛ در غیر این صورت پیام خطای فارسی</summary>
    string? Validate(string fileName, long length);
}

public class LetterAttachmentValidator : ILetterAttachmentValidator
{
    private readonly AttachmentSettings _settings;

    public LetterAttachmentValidator(IConfiguration config)
    {
        _settings = config.GetSection("Attachments").Get<AttachmentSettings>() ?? new AttachmentSettings();
    }

    public string? Validate(string fileName, long length)
    {
        if (length <= 0)
            return "فایل خالی است و قابل بارگذاری نیست.";

        var originalFileName = Path.GetFileName(fileName);
        if (string.IsNullOrWhiteSpace(originalFileName))
            return "نام فایل معتبر نیست.";

        var extension = Path.GetExtension(originalFileName).ToLowerInvariant();

        bool isImage = _settings.AllowedImageExtensions.Contains(extension);
        bool isDocument = _settings.AllowedDocumentExtensions.Contains(extension);

        if (!isImage && !isDocument)
            return $"پسوند {extension} مجاز نیست.";

        long maxSize = isImage ? _settings.MaxImageSize : _settings.MaxDocumentSize;
        if (length > maxSize)
            return $"حداکثر حجم مجاز این نوع فایل {maxSize / 1024 / 1024} مگابایت است.";

        return null;
    }
}

/// <summary>نتیجه دانلود — معادل DownloadFileVM طرح کارفرما</summary>
public class LetterAttachmentDownload
{
    public Stream FileStream { get; set; } = Stream.Null;
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "application/octet-stream";
}

public interface ILetterAttachmentStorage
{
    /// <summary>آیا پیوست این ماژول روی دیسک ذخیره می‌شود؟ (فقط ماژول‌های اتوماسیون اداری)</summary>
    bool IsFileBacked(string module);

    /// <summary>رمزنگاری و ذخیره روی دیسک — خروجی: نام فایل ذخیره‌شده و حجم اصلی</summary>
    Task<(string storedFileName, long size)> SaveAsync(string fileName, Stream content, CancellationToken ct = default);

    /// <summary>باز کردن محتوا برای دانلود — از دیسک (رمزگشایی) یا برای رکوردهای قدیمی از دیتابیس</summary>
    Task<LetterAttachmentDownload?> OpenAsync(AppAttachment att, CancellationToken ct = default);

    /// <summary>حذف فایل فیزیکی (اگر روی دیسک باشد)</summary>
    void DeleteFile(AppAttachment att);

    /// <summary>انتقال یکباره پیوست‌های قدیمی اتوماسیون از دیتابیس به دیسک (هنگام بالا آمدن برنامه)</summary>
    Task MigrateDbAttachmentsToDiskAsync(AppDbContext db, CancellationToken ct = default);
}

public class LetterAttachmentStorage : ILetterAttachmentStorage
{
    /// <summary>ماژول‌های اتوماسیون اداری که پیوستشان روی دیسک است</summary>
    private static readonly HashSet<string> AutomationModules =
        new(StringComparer.OrdinalIgnoreCase) { "InnerLetters", "Pishnevis" };

    private static readonly FileExtensionContentTypeProvider ContentTypeProvider = new();

    private readonly IProjectFileProtection _fileProtection;
    private readonly ILogger<LetterAttachmentStorage> _log;

    public LetterAttachmentStorage(IProjectFileProtection fileProtection, ILogger<LetterAttachmentStorage> log)
    {
        _fileProtection = fileProtection;
        _log = log;
    }

    public bool IsFileBacked(string module) => AutomationModules.Contains(module);

    public async Task<(string storedFileName, long size)> SaveAsync(string fileName, Stream content, CancellationToken ct = default)
    {
        var size = content.CanSeek ? content.Length : 0;
        // رمزنگاری + ذخیره با نام تصادفی ({Guid:N}.bin) — الگوی PeyvastService
        var storedName = await _fileProtection.EncryptAndStoreAsync(content, ct);
        return (storedName, size);
    }

    public async Task<LetterAttachmentDownload?> OpenAsync(AppAttachment att, CancellationToken ct = default)
    {
        Stream? stream = null;

        if (!string.IsNullOrWhiteSpace(att.StoredFileName))
        {
            // رکورد جدید: فایل رمزنگاری‌شده روی دیسک
            if (!File.Exists(_fileProtection.GetPath(att.StoredFileName)))
            {
                _log.LogWarning("فایل پیوست {Id} روی سرور پیدا نشد: {Stored}", att.Id, att.StoredFileName);
                return null;
            }
            stream = await _fileProtection.LoadAndDecryptAsync(att.StoredFileName, ct);
        }
        else if (att.Data is { Length: > 0 })
        {
            // رکورد قدیمی: محتوا هنوز در دیتابیس
            stream = new MemoryStream(att.Data, writable: false);
        }

        if (stream == null) return null;

        return new LetterAttachmentDownload
        {
            FileStream = stream,
            FileName = att.FileName,
            ContentType = GetContentType(att.FileName, att.ContentType)
        };
    }

    public void DeleteFile(AppAttachment att)
    {
        if (string.IsNullOrWhiteSpace(att.StoredFileName)) return;
        try { _fileProtection.Delete(att.StoredFileName); }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "حذف فایل فیزیکی پیوست {Id} ناموفق بود.", att.Id);
        }
    }

    public async Task MigrateDbAttachmentsToDiskAsync(AppDbContext db, CancellationToken ct = default)
    {
        // فقط پیوست‌های اتوماسیون که هنوز داخل دیتابیس هستند
        var pending = await db.AppAttachments
            .Where(a => (a.Module == "InnerLetters" || a.Module == "Pishnevis")
                        && a.StoredFileName == null && a.Data.Length > 0)
            .ToListAsync(ct);
        if (pending.Count == 0) return;

        var moved = 0;
        foreach (var att in pending)
        {
            try
            {
                using var ms = new MemoryStream(att.Data, writable: false);
                var (stored, size) = await SaveAsync(att.FileName, ms, ct);
                att.StoredFileName = stored;
                att.Size = size;
                att.Data = Array.Empty<byte>(); // خالی کردن ستون دیتابیس
                moved++;
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "انتقال پیوست {Id} به دیسک ناموفق بود — فعلاً در دیتابیس می‌ماند.", att.Id);
            }
        }
        await db.SaveChangesAsync(ct);
        Console.WriteLine($"[Attachments] {moved} پیوست اتوماسیون اداری از دیتابیس به دیسک (SecureFiles) منتقل شد.");
    }

    private static string GetContentType(string fileName, string fallback)
    {
        if (ContentTypeProvider.TryGetContentType(fileName, out var ct)) return ct;
        return string.IsNullOrWhiteSpace(fallback) ? "application/octet-stream" : fallback;
    }
}
