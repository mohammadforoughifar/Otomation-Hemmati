using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Data;

/// <summary>ساخت خودکار دیتابیس و بارگذاری داده اولیه در زمان راه‌اندازی.</summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var config = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        var provider = config["Database:Provider"] ?? "SqlServer";
        // داده نمونه (دمو) فقط وقتی ساخته می‌شود که صریحاً فعال شده باشد — پیش‌فرض: دیتابیس تمیز
        var seedDemo = string.Equals(config["Database:SeedDemoData"], "true", StringComparison.OrdinalIgnoreCase);

        const int maxAttempts = 5;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                if (provider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
                {
                    // حالت توسعه/تست: بدون مایگریشن
                    db.Database.EnsureCreated();
                }
                else
                {
                    // SQL Server: اعمال مایگریشن‌ها (در صورت نبود دیتابیس، خودش می‌سازد)
                    db.Database.Migrate();
                }

                if (seedDemo && !db.Products.Any())
                {
                    Console.WriteLine("[DB] حالت دمو فعال است؛ در حال بارگذاری داده نمونه...");
                    Seeder.Seed(db);
                    Console.WriteLine("[DB] داده نمونه با موفقیت بارگذاری شد.");
                }

                // ==================== RBAC Seed ====================
                await RbacSeeder.SeedAsync(db);

                // بک‌فیل یک‌باره‌ی «کد پروژه» برای داده‌های قبل از این فیلد (خودکار، بدون از دست رفتن داده)
                await BackfillProjectCodesAsync(db);

                // انبار پیش‌فرض (در اولین اجرا — قابل ویرایش/تغییر نام از بخش انبارها)
                if (!db.Warehouses.Any())
                {
                    db.Warehouses.Add(new Warehouse { Name = "انبار مرکزی" });
                    db.SaveChanges();
                    Console.WriteLine("[DB] انبار پیش‌فرض «انبار مرکزی» ساخته شد.");
                }

                // ============ اتوماسیون اداری: عملگرهای پیش‌فرض ارجاع ============
                if (!db.Amalgars.Any())
                {
                    db.Amalgars.AddRange(
                        new Amalgar { Title = "جهت اطلاع", TaeedEmza = "" },
                        new Amalgar { Title = "جهت اقدام", TaeedEmza = "" },
                        new Amalgar { Title = "جهت بررسی و اعلام نظر", TaeedEmza = "" },
                        new Amalgar { Title = "جهت تایید و امضا", TaeedEmza = "تایید" },
                        new Amalgar { Title = "جهت پاسخگویی", TaeedEmza = "" },
                        new Amalgar { Title = "جهت بایگانی", TaeedEmza = "" });
                    db.SaveChanges();
                    Console.WriteLine("[DB] عملگرهای پیش‌فرض ارجاع نامه ساخته شدند.");
                }

                // ============ اتوماسیون اداری: ساختار پیش‌فرض شماره اندیکاتور ============
                // ترتیب پیش‌فرض: واحد/شماره/سال → مثل MQ/1/1405 (ساختار مرجع کارفرما)
                if (!db.LetterStratures.Any(s => s.TypeForm == 1))
                {
                    db.LetterStratures.AddRange(
                        new LetterStrature { TypeForm = 1, TypeStrature = "واحد" },
                        new LetterStrature { TypeForm = 1, TypeStrature = "شماره" },
                        new LetterStrature { TypeForm = 1, TypeStrature = "سال" });
                    db.SaveChanges();
                    Console.WriteLine("[DB] ساختار پیش‌فرض شماره اندیکاتور (واحد/شماره/سال) ساخته شد.");
                }

                // بازسازی شماره اندیکاتور نامه‌های قدیمی با ساختار جدید
                // (شماره ترتیبی Number ثابت می‌ماند؛ فقط رشته نمایشی بازتولید می‌شود)
                {
                    var structure = db.LetterStratures.Where(s => s.TypeForm == 1)
                        .OrderBy(s => s.StratureId).Select(s => s.TypeStrature).ToList();
                    if (structure.Count > 0)
                    {
                        var unit = config?["Letters:UnitCode"] ?? "MQ";
                        var pc = new System.Globalization.PersianCalendar();
                        var toFix = db.InnerLetters.Where(l => !l.IsDelete).ToList();
                        int fixedCount = 0;
                        foreach (var l in toFix)
                        {
                            var parts = new List<string>();
                            foreach (var p in structure)
                                switch (p)
                                {
                                    case "سال": parts.Add(pc.GetYear(l.DateSabt).ToString()); break;
                                    case "واحد": if (!string.IsNullOrEmpty(unit)) parts.Add(unit); break;
                                    case "شماره": parts.Add(l.Number.ToString()); break;
                                }
                            var newNum = string.Join("/", parts);
                            if (l.LetterNumber != newNum) { l.LetterNumber = newNum; fixedCount++; }
                        }
                        if (fixedCount > 0)
                        {
                            db.SaveChanges();
                            Console.WriteLine($"[DB] شماره اندیکاتور {fixedCount} نامه قدیمی با ساختار جدید بازسازی شد.");
                        }
                    }
                }

                // بازسازی گروه‌های کالا برای دیتابیس‌های قدیمی:
                // هر گروهی که روی کالاها ثبت شده ولی در جدول گروه‌ها نیست، اضافه می‌شود.
                var existing = db.ProductCategories.Select(c => c.Name).ToHashSet();
                var missing = db.Products.Where(p => p.Category != null)
                    .Select(p => p.Category!).Distinct().ToList()
                    .Where(n => !existing.Contains(n)).ToList();
                if (missing.Count > 0)
                {
                    foreach (var name in missing)
                        db.ProductCategories.Add(new ProductCategory { Name = name, CreatedAt = DateTime.Now });
                    db.SaveChanges();
                    Console.WriteLine($"[DB] {missing.Count} گروه کالا از روی کالاهای موجود ساخته شد.");
                }

                // بازسازی واحدهای شمارش برای دیتابیس‌های قدیمی:
                // واحدهای پیش‌فرض + واحدهای استفاده‌شده روی کالاها که در جدول نیستند اضافه می‌شوند.
                var knownUnits = db.MeasureUnits.Select(u => u.Name).ToHashSet();
                var wanted = Seeder.DefaultUnits
                    .Concat(db.Products.Select(p => p.Unit).Distinct().ToList())
                    .Where(n => !string.IsNullOrWhiteSpace(n))
                    .Distinct()
                    .Where(n => !knownUnits.Contains(n))
                    .ToList();
                if (wanted.Count > 0)
                {
                    foreach (var name in wanted)
                        db.MeasureUnits.Add(new MeasureUnit { Name = name, CreatedAt = DateTime.Now });
                    db.SaveChanges();
                    Console.WriteLine($"[DB] {wanted.Count} واحد شمارش اضافه شد.");
                }

                // کاربر پیش‌فرض مدیر: admin / admin (در اولین اجرا)
                if (!db.Users.Any())
                {
                    db.Users.Add(new User
                    {
                        Username = "admin",
                        PasswordHash = Services.AuthService.HashPassword("admin"),
                        Role = "Admin",
                        CreatedAt = DateTime.Now
                    });
                    db.SaveChanges();
                    Console.WriteLine("[DB] کاربر پیش‌فرض ساخته شد: admin / admin — حتماً رمز را تغییر دهید.");
                }

                // کاربران نمونه برای دموی کارتابل نامه (فقط در حالت دمو)
                if (seedDemo && db.Users.Count() <= 1)
                {
                    db.Users.AddRange(
                        new User { Username = "ali", PasswordHash = Services.AuthService.HashPassword("ali123"), Role = "Operator", FirstName = "علی", LastName = "رضایی", CreatedAt = DateTime.Now },
                        new User { Username = "sahar", PasswordHash = Services.AuthService.HashPassword("sahar123"), Role = "Operator", FirstName = "سحر", LastName = "محمدی", CreatedAt = DateTime.Now },
                        new User { Username = "fatemeh", PasswordHash = Services.AuthService.HashPassword("fatemeh123"), Role = "Operator", FirstName = "فاطمه", LastName = "کریمی", CreatedAt = DateTime.Now });
                    db.SaveChanges();
                    Console.WriteLine("[DB] کاربران دمو ساخته شدند: ali/ali123 — sahar/sahar123 — fatemeh/fatemeh123");
                }

                // گروه‌های نمونه گیرندگان نامه (فقط در حالت دمو)
                if (seedDemo && !db.LetterGroups.Any())
                {
                    var admin2 = db.Users.FirstOrDefault(u => u.Username == "admin");
                    var demoUsers = db.Users.Where(u => u.Username != "admin").Take(3).ToList();
                    if (admin2 != null && demoUsers.Count > 0)
                    {
                        var g1 = new LetterGroup { NameGroup = "کارشناسان اداری", CreatorUserId = admin2.Id };
                        foreach (var u in demoUsers) g1.Members.Add(new LetterGroupMember { UserId = u.Id });
                        var g2 = new LetterGroup { NameGroup = "مدیران", CreatorUserId = admin2.Id };
                        g2.Members.Add(new LetterGroupMember { UserId = admin2.Id });
                        if (demoUsers.Count > 0) g2.Members.Add(new LetterGroupMember { UserId = demoUsers[0].Id });
                        db.LetterGroups.AddRange(g1, g2);
                        db.SaveChanges();
                        Console.WriteLine("[DB] گروه‌های دمو گیرندگان نامه ساخته شدند.");
                    }
                }

                // دسته‌های هزینه پیش‌فرض (در اولین اجرا — کاربر می‌تواند مدیریتشان کند)
                if (!db.ExpenseCategories.Any())
                {
                    foreach (var name in new[] { "اجاره", "حقوق و دستمزد", "قبوض (آب/برق/گاز/تلفن)", "حمل و نقل", "ملزومات و اداری", "پذیرایی", "تعمیر و نگهداری", "تبلیغات و بازاریابی", "متفرقه" })
                        db.ExpenseCategories.Add(new ExpenseCategory { Name = name, CreatedAt = DateTime.Now });
                    db.SaveChanges();
                    Console.WriteLine("[DB] دسته‌های هزینه پیش‌فرض ساخته شدند.");
                }

                // دیتابیس‌های قدیمی: کالاهای بدون انبار اختصاصی به «انبار مرکزی» اختصاص می‌یابند
                var centralWh = db.Warehouses.FirstOrDefault(w => w.Name.Contains("مرکزی"))
                                ?? db.Warehouses.OrderBy(w => w.Id).FirstOrDefault();
                if (centralWh is not null)
                {
                    var orphan = db.Products.Where(p => p.WarehouseId == null && !p.IsService).ToList();
                    if (orphan.Count > 0)
                    {
                        foreach (var p in orphan) p.WarehouseId = centralWh.Id;
                        db.SaveChanges();
                        Console.WriteLine($"[DB] {orphan.Count} کالا به «{centralWh.Name}» اختصاص یافت.");
                    }
                }

                Console.WriteLine("[DB] اتصال و آماده‌سازی دیتابیس با موفقیت انجام شد ✔");
                return;
            }
            catch (Exception ex) when (ex is SqlException or InvalidOperationException)
            {
                Console.WriteLine($"[DB] تلاش {attempt} از {maxAttempts} برای اتصال به دیتابیس ناموفق بود: {ex.Message}");

                if (attempt == maxAttempts)
                {
                    Console.WriteLine();
                    Console.WriteLine("================= خطای اتصال به SQL Server =================");
                    Console.WriteLine("برنامه نتوانست به SQL Server وصل شود. موارد زیر را بررسی کنید:");
                    Console.WriteLine("  1) سرویس SQL Server در حال اجرا باشد:");
                    Console.WriteLine("     services.msc → SQL Server (MSSQLSERVER) → Start");
                    Console.WriteLine("  2) اگر نسخه Express دارید، آدرس سرور باید .\\SQLEXPRESS باشد؛");
                    Console.WriteLine("     در appsettings.json مقدار Server=. را به Server=.\\SQLEXPRESS تغییر دهید.");
                    Console.WriteLine("  3) پروتکل TCP/IP یا Shared Memory در SQL Server Configuration Manager فعال باشد.");
                    Console.WriteLine("  4) رشته اتصال فعلی:");
                    Console.WriteLine($"     {config.GetConnectionString("Default")}");
                    Console.WriteLine("  5) برای تست بدون SQL Server، در appsettings.json مقدار");
                    Console.WriteLine("     Database:Provider را روی \"Sqlite\" و ConnectionStrings:Default را روی");
                    Console.WriteLine("     \"Data Source=inventory.db\" بگذارید.");
                    Console.WriteLine("=============================================================");
                    throw;
                }

                Thread.Sleep(TimeSpan.FromSeconds(3));
            }
        }
    }

    /// <summary>
    /// بک‌فیل یک‌باره‌ی «کد پروژه» برای دیتابیس‌هایی که قبل از افزودن فیلد CodeProject ساخته شده‌اند:
    /// پروژه‌های عادی ← کد = Id قدیمی (تا شماره‌های موجود حفظ شوند)؛
    /// برگشتی‌ها ← کد = «REn-کد مبدأ» و فیلد ReturnProjectId از معنای قدیمی (Id مبدأ) به معنای جدید (عدد برگشتی n) تبدیل می‌شود؛
    /// گزارش‌های کار هم کد پروژه‌شان پر می‌شود. چنانچه پیوست‌ها/پروژه‌ها CodeProject داشته باشند، هیچ کاری انجام نمی‌شود.
    /// </summary>
    private static async Task BackfillProjectCodesAsync(AppDbContext db)
    {
        try
        {
            if (!await db.ProjectEntryExits.AnyAsync(p => p.CodeProject == "" || p.CodeProject == null))
                return;

            var all = await db.ProjectEntryExits.OrderBy(p => p.Id).ToListAsync();

            // ۱) پروژه‌های عادی: کد = Id فعلی (حفظ شماره‌های موجود)
            foreach (var p in all.Where(p => p.ReturnProjectId <= 0 && string.IsNullOrEmpty(p.CodeProject)))
                p.CodeProject = p.Id.ToString();

            var byId = all.ToDictionary(p => p.Id, p => p.CodeProject);

            // ۲) برگشتی‌ها: تبدیل معنای ReturnProjectId از «Id مبدأ» به «عدد برگشتی n» + ساخت کد REn-کدمبدأ
            var counters = new Dictionary<int, int>();
            foreach (var p in all.Where(p => p.ReturnProjectId > 0 && string.IsNullOrEmpty(p.CodeProject)))
            {
                var parentId = p.ReturnProjectId; // معنای قدیمی: شناسه پروژه مبدأ
                counters.TryGetValue(parentId, out var n); n++;
                counters[parentId] = n;
                var parentCode = byId.TryGetValue(parentId, out var c) && !string.IsNullOrEmpty(c)
                    ? c : parentId.ToString();
                p.CodeProject = $"RE{n}-{parentCode}";
                p.ReturnProjectId = n; // معنای جدید: عدد برگشتی
            }

            // ۳) گزارش‌های کار: پر کردن کد پروژه
            var reports = await db.ReportWorks.Where(r => r.CodeProject == "" || r.CodeProject == null).ToListAsync();
            foreach (var r in reports)
                if (byId.TryGetValue(r.ProjectId, out var c) && !string.IsNullOrEmpty(c))
                    r.CodeProject = c;

            await db.SaveChangesAsync();
            Console.WriteLine($"[DB] بک‌فیل کد پروژه انجام شد ({all.Count} پروژه، {reports.Count} گزارش) ✔");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[DB] هشدار: بک‌فیل کد پروژه انجام نشد — {ex.Message}");
        }
    }
}
