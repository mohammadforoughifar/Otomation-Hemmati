﻿using CoreApp.DTOs.IService.IServiceBase;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class SystemLogService(DataContext _context) : ISystemLogService
    {
        public async Task<bool> AddSystemLogAsync(List<SystemLog> logs)
        {
            if (logs == null || logs.Count == 0)
                return false;

            try
            {
                _context.SystemLog.AddRange(logs);
                var savedCount = await _context.SaveChangesAsync();

                return savedCount == logs.Count;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> AddSystemLogAsync(SystemLog log)
        {
            if (log == null)
                return false;

            try
            {
                _context.SystemLog.Add(log);
                var savedCount = await _context.SaveChangesAsync();
                return savedCount == 1;
            }
            catch (Exception ex)
            { 
                return false;
            }
        }
    }
}
