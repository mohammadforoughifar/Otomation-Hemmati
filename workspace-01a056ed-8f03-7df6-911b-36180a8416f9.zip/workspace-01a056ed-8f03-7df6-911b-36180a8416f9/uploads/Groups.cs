﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Base.Settings
{
    public class Groups
    {
        public int GroupId { get; set; }
        public string NameGroup { get; set; }
        public bool Condition { get; set; }
        public bool IsDelete { get; set; }
        public int CreatSematId { get; set; }
        public Guid CreateUserId { get; set; }

        #region Relation
        [ForeignKey(nameof(CreatSematId))]
        public Semats Semat { get; set; }
        [ForeignKey("CreateUserId")]
        public User User { get; set; }
        public ICollection<SematGroups> SematGroups { get; set; } = new List<SematGroups>();

        #endregion
    }
    public class SematGroups
    {
        public int GroupSematId { get; set; }
        public int GroupId { get; set; }
        public int SematId { get; set; }

        #region Relation
        [ForeignKey("GroupId")]
      public  Groups Groups { get; set; }
        [ForeignKey(nameof(SematId))]
        public Semats Semat { get; set; }
        #endregion
    }
}
