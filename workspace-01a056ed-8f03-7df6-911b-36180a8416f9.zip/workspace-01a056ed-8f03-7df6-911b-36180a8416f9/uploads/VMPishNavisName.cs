﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMPishNavisName
    {
        public int Pishnevis_Id { get; set; }
        public string Title { get; set; }
        public string Text { get; set; }
        public Guid UserId { get; set; }
        public int SematId { get; set; }
        public bool IsNeshan { get; set; }

        public bool IsDelete { get; set; }
        public IEnumerable<Links> Links { get; set; }

    }
}
