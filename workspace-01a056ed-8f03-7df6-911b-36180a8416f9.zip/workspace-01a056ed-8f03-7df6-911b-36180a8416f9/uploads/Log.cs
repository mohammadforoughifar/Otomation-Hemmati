﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Base.Settings
{
  

        public class SystemLog
        {
            public int LogId { get; set; }
            public int SematId { get; set; }
            public Guid UserId { get; set; }
            public DateTime LastDate { get; set; }
            public int FormId { get; set; }
            public int FormType { get; set; }
            public int Action { get; set; }
            public string? Number { get; set; } //شماره 
            public bool IsDelete { get; set; }

            #region relation

            [ForeignKey(nameof(SematId))]
            public Semats Semat { get; set; }

            [ForeignKey(nameof(UserId))]
            public User User { get; set; }

            #endregion
        }
    }
