﻿using CoreApp.DTOs.IService.IServiceBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMBasic;
using CoreApp.Helps.Responses;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base.BaseEntitiesProvider;
using DataLayerApp.Entites.Base.Settings;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Entites.Base;
using Microsoft.Data.SqlClient;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class StructureLetterService(DataContext context, IOrganizationServices _organizationServices
    ) : IStructureLetterService
    {
        ApiModel model = new ApiModel();
        public async Task<ApiModel> AddStratureLetter(AddStructure structure)
        {


            if (structure.TypeForm is 0)
            {
                return new ApiModel();
            }


            try
            {
                var isitem = context.LetterStratures.FirstOrDefault(c=>c.TypeForm==structure.TypeForm);
                if (isitem != null)
                {
                    model.Data = null;
                    model.Status = 410;
                    model.Message = MessageCode.StatusCode.TryGetValue(410, out string messager1) 
                        ? model.Message = messager1
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = false;

                    return model;
                }

          
                foreach (var item in structure.struc)
                {
                    LetterStrature letter = new LetterStrature();
                    letter.TypeForm = structure.TypeForm;
                    letter.TypeStrature = item;
                    context.LetterStratures.Add(letter);


                }
                context.SaveChanges();

                model.Data = structure;
                model.Status = 201;
                model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;

                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;

                return model;

            }




        }

        public async Task<ApiModel> GetAllStractureLetter()
        {
            IEnumerable<LetterStrature> structure = context.LetterStratures;
      
            try
            {
                var resultDict = new Dictionary<int, VMStructure>();
                string[] formStrings = {"", "نامه داخلی", "نامه صادره", "نامه وارده" };
                foreach (var item in structure)
                {
                    int formType = item.TypeForm;
                    if (!resultDict.TryGetValue(formType, out var letterNumber))
                    {
                        var formString = formStrings.ElementAtOrDefault(formType) ?? "";
                        letterNumber = new VMStructure
                        {
                            Typestracture = "",
                            TypeForm = formType,
                            TypeFormstring = formString
                        };
                        resultDict.Add(formType, letterNumber);
                    }
                    letterNumber.Typestracture = AppendToStructure(letterNumber.Typestracture, item.TypeStrature);
                }
                var result = resultDict.Values.ToList();

                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }
          
            return model;
        }

        public async Task<ApiModel> GetStructureByTyepformId(int TypeForm)
        {
            try
            {
                List<string> liststring = new List<string>();
                var result = context.LetterStratures.Where(c => c.TypeForm == TypeForm);
                foreach (var strature in result)
                {
                    liststring.Add(strature.TypeStrature);
                }

                var vmmodel = new AddStructure()
                {
                    TypeForm = TypeForm,
                    struc = liststring
                };
                model.Data = vmmodel;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }

            return model;
        }

        public async Task<ApiModel> EditStratureLetter(AddStructure typestrature)
        {
            var records = context.LetterStratures.Where(x => x.TypeForm == typestrature.TypeForm);
            try
            {
                context.LetterStratures.RemoveRange(records);
          
                foreach (var item in typestrature.struc)
                {
                    LetterStrature letter = new LetterStrature();
                    letter.TypeForm = typestrature.TypeForm;
                    letter.TypeStrature = item;
                    context.LetterStratures.Add(letter);


                }
                context.SaveChanges();
                model.Data = typestrature;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
              
            }
            catch
            {
                model.Data = null;
                model.Status = 204;
                model.Message = MessageCode.StatusCode.TryGetValue(204, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = 0;
            }

            return model;
        }

        private string AppendToStructure(string structure, string newPart)
        {

            return string.IsNullOrEmpty(structure) ? newPart : $"{structure}/{newPart}";
        }

        public async Task<string> TotalNumberAsync(int number, int TypeForm, int SematId)
        {
            if (number == -1)
                return string.Empty;

            // دریافت ساختار نامه‌های مربوط به فرم خاص
            var structureletter = await context.LetterStratures
                .Where(c => c.TypeForm == TypeForm)
                .ToListAsync();

            // اگر ساختار نامه موجود نیست یا خالی است، خروجی خالی برگردان
            if (structureletter == null || !structureletter.Any())
                return string.Empty;

            List<string> parts = new List<string>();

            // مقدار سال شمسی جاری را یک‌بار محاسبه می‌کنیم
            var persianCalendar = new PersianCalendar();
            var currentYear = persianCalendar.GetYear(DateTime.Now);

            // نام سازمان را بر اساس شناسه سمت دریافت می‌کنیم
            string organizationName = await _organizationServices.GetOrganizationNameUniqAsync(SematId);

            // پیمایش در ساختار نامه‌ها و ساخت رشته نهایی
            foreach (var item in structureletter)
            {
                switch (item.TypeStrature)
                {
                    case "سال":
                        // افزودن سال شمسی
                        parts.Add(currentYear.ToString());
                        break;

                    case "واحد":
                        // افزودن نام سازمان
                        if (!string.IsNullOrEmpty(organizationName))
                        {
                            parts.Add(organizationName);
                        }
                        break;

                    case "شماره":
                        parts.Add(number.ToString());
                        break;

                    default:
                        break;
                }
            }

            // ساختن رشته نهایی با جداکننده '/'
            string totalLetter = string.Join("/", parts);
            return totalLetter;
        }
    }
}
