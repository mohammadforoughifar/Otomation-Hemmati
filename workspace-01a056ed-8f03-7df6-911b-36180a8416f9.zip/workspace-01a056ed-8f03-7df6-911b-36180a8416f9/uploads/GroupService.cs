﻿using CoreApp.DTOs.IService.IServiceBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMBasic;
using CoreApp.Helps.Responses;
using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Context;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;
using CoreApp.Helps.StatusCode;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using static CoreApp.DTOs.ViewModel.VMBasic.VmSemats;
using System.Linq.Expressions;
using System.Text.RegularExpressions;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class GroupService(DataContext context) : IGroupService
    {
        ApiModel model = new ApiModel();
        public async Task<ApiModel> AddGroup(VMSettings.AddGroup group)
        {
            try
            {
                if (group.NameGroup is "")
                {
                    return new ApiModel();
                }
                var groupentity = new Groups()
                {
                    NameGroup = group.NameGroup,
                    Condition = true,
                    CreatSematId = group.sematId,
                    CreateUserId = group.userId,
                    

                };
                context.Groups.Add(groupentity);
                context.SaveChanges();
                foreach (var item in group.FullNames)
                {
                    var semaGroups = new SematGroups()
                    {
                        SematId = item.sematId,
                        GroupId = groupentity.GroupId,
                    };
                    context.Add(semaGroups);
                }
                context.SaveChanges();
                model.Data = groupentity.NameGroup;
                model.Status = 201;
                model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;

                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;

                return model;
            }

        }

        public async Task<ApiModel> GetGroupTuple(GetResultQuery request)
        {
            int totalUsers = context.Semats.Count();

            try
            {
                var semats = context.Groups

                    .Select(s => new VMGroup()
                    {
                        groupid = s.GroupId,
                        Namegroup = s.NameGroup, // or s.UserId if it's a property of Semats
                        status = s.Condition ? "فعال" : "غیرفعال",

                    });
                // فیلتر کردن بر اساس جستجو  
                if (!string.IsNullOrEmpty(request.SearchTerm))
                {
                    semats = semats.Where(ca => ca.Namegroup.Trim().Contains(request.SearchTerm) || ca.status.Contains(request.SearchTerm));
                    //users = users.Where(ca => ca.CodePersoneli.Contains(request.SearchTerm));
                }
                if (!string.IsNullOrEmpty(request.SortColumn))
                {
                    semats = semats.Where(ca => ca.status == request.SortColumn);
                }
                if (request.SortOrder?.ToLower() == "desc")
                    semats = semats.OrderByDescending(GetSortProperty(request));
                else
                    semats = semats.OrderBy(GetSortProperty(request));
                var result = await PagedList<VMGroup>.CreateAsync(semats, (int)request.Page, (int)request.PageSize);
                ApiModel model = new ApiModel();
                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.TotalCount = totalUsers;
                return model;
            }
            catch (Exception exception)
            {
                ApiModel model = new ApiModel();
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
                return model;
            }
        }

        public async Task<ApiModel> GetGroupById(int groupId)
        {
            try
            {

                var groups = context.Groups
                    .Include(c => c.SematGroups)
                    .ThenInclude(sg => sg.Semat)
                    .ThenInclude(s => s.User)
                    .Where(c => c.GroupId == groupId)
                    .ToList();

                var resultList = groups.Select(c => new VMSettings.AddGroup()
                {
                    userId = c.CreateUserId,
                    sematId = c.CreatSematId,
                    NameGroup = c.NameGroup,
                    status = c.Condition,
                    GroupId = c.GroupId,
                    FullNames = c.SematGroups.Select(sg => new SematUserFullName()
                    {
                        FullName = sg.Semat.Title + " " + sg.Semat.User.FirstName + " " + sg.Semat.User.LastName,
                        userId = sg.Semat.User.Id,
                        sematId = sg.Semat.SematId
                    }).ToList()
                }).FirstOrDefault();


                model.Data = resultList;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }

            return model;
        }

        public async Task<ApiModel> EditGroup(VMSettings.AddGroup addGroup)
        {
            try
            {
                var group = context.Groups.Find(addGroup.GroupId);
                
                    group.Condition = addGroup.status;
                    group.CreatSematId = addGroup.sematId;
                    group.CreateUserId = addGroup.userId;
                    group.NameGroup = addGroup.NameGroup;

               
                context.SaveChanges();
                var sematgroups = context.SematGroups.Where(c => c.GroupId == addGroup.GroupId);
                context.SematGroups.RemoveRange(sematgroups);
                foreach (var item in addGroup.FullNames)
                {
                    var semaGroups = new SematGroups()
                    {
                        SematId = item.sematId,
                        GroupId = group.GroupId,
                    };
                    context.Add(semaGroups);
                }
                context.SaveChanges();
                model.Data = addGroup;
                model.Status = 201;
                model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }

            return model;

        }

        public async Task<ApiModel> DeleteGroup(int GroupId)
        {
            var group = context.Groups.Find(GroupId);
            if (group is not null)
            {
                group.IsDelete = true;
                var sematgroups = context.SematGroups.Where(c => c.GroupId == GroupId);
                context.SematGroups.RemoveRange(sematgroups);
                context.SaveChanges();
                model.Data = null;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            else
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }

            return model;
        }

        public async Task<ApiModel> GetAllNameGroup()
        {
            var groups = context.Groups
                .OrderBy(s => s.NameGroup) // مرتب‌سازی بر اساس حرف الفبا
                .Select(s => new VMGroup()
                {
                    groupid = s.GroupId,
                    Namegroup = s.NameGroup,
                }).ToList();

            if (groups.Any())
            {
                model.Data = groups;
                model.Status = 201;
                model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }

            else
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(404, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 404;
                model.Success = false;

                return model;
            }
        }


        private Expression<Func<VMGroup, object>> GetSortProperty(GetResultQuery request)
            => request.SortColumn?.ToLower() switch
            {
                "Namegroup" => Student => Student.Namegroup,
                "status" => Student => Student.status,
                _ => Student => Student.groupid,
            };

        public async Task<bool> CheckGroupIdAsync(List<int> groupIds)
        {
            //if (groupId.Count() > 0)
            //{
            //    foreach (var item in groupId)
            //    {
            //        if (!await _context.Groups.AnyAsync(c => c.GroupId == item && c.Condition == true))
            //            return false;
            //    }
            //    return true;
            //}
            //return false;

            if (groupIds == null || groupIds.Count == 0)
                return false;

            var existingCount = await context.Groups
                .Where(g => groupIds.Contains(g.GroupId) && g.Condition)
                .CountAsync();

            return existingCount == groupIds.Count;
        }

        public async Task<List<SematUserFullName>> GetUserByGroupIdAsync(List<int> groupsId)
        {
            if (groupsId == null || groupsId.Count == 0)
                return new List<SematUserFullName>();

            var data = await context.SematGroups
                .Where(c => groupsId.Contains(c.GroupId))
                .Select(c => new SematUserFullName
                {
                    FullName = c.Semat.User.FirstName + " " + c.Semat.User.LastName,
                    sematId = c.SematId,
                    userId = c.Semat.UserId
                })
                .ToListAsync();

            // sematId شبیه به هم را حذف می کند
            return data.DistinctBy(c => c.sematId).ToList();
        }
    }
}
