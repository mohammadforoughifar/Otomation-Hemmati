﻿using System.ComponentModel.DataAnnotations.Schema;
using DataLayerApp.Entites.Base;

namespace DataLayerApp.Entites.Otomation.Letter
{
    public class InnerLetter
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string? Letter_Number { get; set; } //شماره نامه
        public int Number { get; set; } //
        public int CreatorSematId { get; set; }
        public Guid CreatorUserId { get; set; }
        public string Title { get; set; }
        public string? Text { get; set; }
        public DateTime DateSabt { get; set; }
        public string? Mahramanegi { get; set; }
        public string? Foriat { get; set; }
        public bool IsDelete { get; set; }

        #region Relations
        [ForeignKey(nameof(Id))]
        public SourceKeyID Source { get; set; }

        [ForeignKey(nameof(CreatorSematId))]
        public Semats Semat { get; set; }

        [ForeignKey(nameof(CreatorUserId))]
        public User User { get; set; }

        #endregion



    }
}
