﻿using DataLayerApp.Entites.Otomation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


namespace DataLayerApp.Entites.Base.Settings
{
    public class Amalgar
    {
        public int Amalgar_Id { get; set; }
        public string Title { get; set; }
        public string Taeed_Emza { get; set; }
        public bool IsDelete { get; set; }

        #region Relations

        public ICollection<Erja> Erjas { get; set; } = new List<Erja>();

        #endregion
    }
}
