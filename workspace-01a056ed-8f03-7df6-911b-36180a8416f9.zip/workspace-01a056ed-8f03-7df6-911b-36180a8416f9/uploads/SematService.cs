﻿using System.Linq.Expressions;
using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser;
using CoreApp.DTOs.ViewModel.VMBasic;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using static CoreApp.DTOs.ViewModel.VMBasic.VmSemats;
using static CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser.UsersViewModel;
using DataLayerApp.Entites.Base.BaseEntitiesProvider;
using Microsoft.AspNetCore.Identity;
using static DataLayerApp.Entites.Base.BaseEntitiesProvider.Permission;
using static CoreApp.DTOs.ViewModel.VMBasic.VmChartOrganization;
using System.Security;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class SematService(DataContext context
        ) : ISematService
    {
        private ISematService _sematServiceImplementation;
        private ApiModel _model = new ApiModel();
        public async Task<ApiModel> GetAllSematFullName()
        {
            try
            {

                var result = context.Semats
                    .Include(c => c.User)
                    .OrderBy(c => c.Title)  // یا بر اساس نام‌های کاربری و غیره
                    .AsEnumerable()
                    .Select(c => new SematUserFullName()
                    {
                        FullName = c.Title + " " + c.User.FirstName + " " + c.User.LastName,
                        userId = c.User.Id,
                        sematId = c.SematId
                    })
                    .OrderBy(c => c.FullName.ToLower())
                    .ToList();

                _model.Data = result;
                _model.Status = 200;
                _model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Success = true;
            }
            catch (Exception e)
            {
                _model.Data = null;
                _model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Status = 500;
                _model.Success = false;
                _model.TotalCount = 0;
            }

            return _model;
        }
        public async Task<ApiModel> GetAllRolesByTitle(string RoleName)
        {
            ApiModel model = new ApiModel();

            var Role = await context.Roles.FirstOrDefaultAsync(c => c.Name == RoleName);

            Guid roleId = Role.Id;

            var SematIDs = await context.SematRoles.Where(x => x.RoleId == roleId)
                .Select(x => x.SematId)
                .ToListAsync();

            var UserIDs = await context.Users
                .Where(u => context.Semats
                .Any(s => SematIDs.Contains(s.SematId) && s.UserId == u.Id))
                .Select(u => new UserViewModel
                {
                    UserId = u.Id,
                    FullName = u.FirstName + " " + u.LastName,
                })
                .ToListAsync();

            if (UserIDs == null || SematIDs == null || roleId == null)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                    ? model.Message = messager2
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
            }
            else
            {
                model.Data = UserIDs;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                    ? model.Message = messager2
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 200;
                model.Success = true;
            }
            return model;
        }
        public async Task<ApiModel> GetSematTuple(GetResultQuery request)
        {
            int totalUsers = context.Semats.Count();

            try
            {
                var semats = context.Semats
                    .Include(s => s.Organizations)
                    .Include(s => s.User)
                    .Select(s => new VmSemats.SematBuName()
                    {
                        sematId = s.SematId,
                        userid = s.User.Id, // or s.UserId if it's a property of Semats
                        FullName = s.User.FirstName + " " + s.User.LastName,
                        Organization = s.Organizations.NameUnit,
                        TitleSemat = s.Title,
                        TitleMokatebati = s.OnvanMokatebati,
                        Parent = s.Parent,
                        ParentName = s.Parent == 0
                            ? "بدون والد"
                            : context.Semats
                                .Where(z => z.SematId == s.Parent)
                                .Select(z => z.User.FirstName + " " + z.User.LastName)
                                .FirstOrDefault()
                    });
                // فیلتر کردن بر اساس جستجو  
                if (!string.IsNullOrEmpty(request.SearchTerm))
                {
                    semats = semats.Where(ca => ca.FullName.Trim().Contains(request.SearchTerm) || ca.TitleSemat.Contains(request.SearchTerm) || ca.Organization.Contains(request.SearchTerm));
                    //users = users.Where(ca => ca.CodePersoneli.Contains(request.SearchTerm));
                }
                if (!string.IsNullOrEmpty(request.SortColumn))
                {
                    semats = semats.Where(ca => ca.ParentName == request.SortColumn);
                }
                if (request.SortOrder?.ToLower() == "desc")
                    semats = semats.OrderByDescending(GetSortProperty(request));
                else
                    semats = semats.OrderBy(GetSortProperty(request));
                var result = await PagedList<SematBuName>.CreateAsync(semats, (int)request.Page, (int)request.PageSize);
                ApiModel model = new ApiModel();
                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.TotalCount = totalUsers;
                return model;
            }
            catch (Exception exception)
            {
                ApiModel model = new ApiModel();
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
                return model;
            }
        }

        public async Task<List<VmSemats.SematBuName>> GetSematNameUser()
        {
            var semats = await context.Semats
                .Include(x => x.User)
                .Where(c => c.IsActive)
                .OrderBy(s => s.Title) // مرتب‌سازی بر اساس حرف الفبا
                .Select(c => new VmSemats.SematBuName()
                {
                    FullName = c.Title + "/" + (c.User != null ? c.User.FirstName + " " + c.User.LastName : "Unknown User"),
                    sematId = c.SematId,
                    userid = c.UserId
                }).ToListAsync();

            return semats;
        }

        public async Task<ApiModel> GetSematId(int sematId)
        {
            var model = new ApiModel();
            var result = await context.Semats.FindAsync(sematId);
            if (result is not null)
            {

                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.UserId = result.UserId;
                model.SematId = result.SematId;
                return model;
            }

            model.Data = null;
            model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                ? model.Message = messager2
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Status = 500;
            model.Success = false;

            return model;

        }

        public async Task<ApiModel> AddSemat(SematViewModel semat)
        {
            ApiModel model = new ApiModel();
            if (semat.Title is "" || semat.OnvanMokatebati is "")
            {
                return new ApiModel();
            }
            else
            {
                try
                {
                    var sem = new Semats
                    {
                        DefaultSemat = semat.DefaultSemat,
                        Title = semat.Title,
                        Parent = (int)semat.Parent,
                        OrganizationId = semat.OrganizationId,
                        UserId = semat.UserId,
                        IsActive = semat.IsActive,
                        OnvanMokatebati = semat.OnvanMokatebati
                    };
                    context.Semats.Add(sem);
                    await context.SaveChangesAsync();

                    model.Data = sem;
                    model.Status = 201;
                    model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                    model.UserId = sem.UserId;
                    model.SematId = sem.SematId;
                    return model;
                }
                catch (Exception e)
                {
                    model.Data = null;
                    model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Status = 500;
                    model.Success = false;

                    return model;

                }


            }
        }

        public async Task<List<SematViewModel>> GetAllSematForParent()
        {
            var model = new ApiModel();
            var semats = context.Semats

                .Include(s => s.User).Where(x => !x.IsDelete && x.IsActive)
                .Select(s => new SematViewModel()
                {
                    SematId = s.SematId,
                    Title = s.Title,
                    Parent = s.Parent,
                    ParentName = s.SematId == 0
                        ? "بدون والد"
                        : context.Semats
                            .Where(z => z.SematId == s.SematId)
                            .Select(z => z.Title + " " + z.User.FirstName + " " + z.User.LastName)
                            .FirstOrDefault()

                }).ToList();
            return semats;
        }

        public async Task<ApiModel> DeleteSemat(int sematId)
        {
            ApiModel model = new ApiModel();
            var get = context.Semats.Find(sematId);
            var result = context.Signatures.Where(x => x.SematId == get.SematId);
            if (get is not null)
            {
                get.IsDelete = true;
                context.SaveChanges();
                if (result is not null)
                {
                    foreach (var signature in result)
                    {
                        signature.SematId = null;
                        context.SaveChanges();
                    }

                }
                model.Data = get;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager2) == true
                    ? model.Message = messager2
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = get.OrganizationId;
                return model;
            }

            model.Data = null;
            model.Status = 500;
            model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = false;
            model.SematId = 0;
            return model;


        }
        public async Task<ApiModel> updateSemaTask(SematViewModel semat)
        {
            ApiModel model = new ApiModel();
            if (semat.Title is "" || semat.OrganizationId is 0)
            {
                return new ApiModel();
            }

            try
            {
                var get = context.Semats.Find(semat.SematId);
                get.Title = semat.Title;
                get.OnvanMokatebati = semat.OnvanMokatebati;
                get.OrganizationId = semat.OrganizationId;
                get.UserId = semat.UserId;
                get.IsActive = semat.IsActive;
                get.Parent = (int)semat.Parent;
                get.DefaultSemat = semat.DefaultSemat;
                context.SaveChanges();
                model.Data = get;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = get.OrganizationId;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Status = 204;
                model.Message = MessageCode.StatusCode.TryGetValue(204, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = 0;
            }

            return model;
        }

        public async Task<ApiModel> GetRoles(int SematId)
        {
            ApiModel model = new ApiModel();
            List<string> titels = new List<string>();
            var result = context.SematRoles.Where(X => X.SematId == SematId);
            if (result.Any())
            {
                foreach (var itemRole in result)
                {
                    var f = context.Roles.Find(itemRole.RoleId).Name;
                    titels.Add(f);
                }

                //var modelrole = new VmChartOrganization.vMRole();
                //modelrole.Role = titels;
                model.Data = titels;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            model.Data = null;
            model.Status = 404;
            model.Message = MessageCode.StatusCode.TryGetValue(404, out string messager2) == true
                ? model.Message = messager2
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = true;
            model.SematId = 0;
            return model;

        }

        public async Task<ApiModel> AddRoleSemat(VmChartOrganization.VmRole role)
        {

            if (role.SematId is not 0 && role.Role.Any())
            {
                foreach (var item in role.Role)
                {
                    var sematrole = new SematRole();
                    sematrole.RoleId = item;
                    sematrole.SematId = role.SematId;


                    context.SematRoles.Add(sematrole);
                }

                context.SaveChanges();
                _model.Data = role;
                _model.Status = 200;
                _model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Success = true;
                _model.SematId = role.SematId;
                return _model;
            }
            _model.Data = null;
            _model.Status = 204;
            _model.Message = MessageCode.StatusCode.TryGetValue(204, out string messager2) == true
                ? _model.Message = messager2
                : _model.Message = "کد وضعیت نامعتبر است.";
            _model.Success = true;
            _model.SematId = 0;
            return _model;
        }

        public async Task<ApiModel> GetAllRoles()
        {
            var roles = context.Roles

                .Select(s => new GetRole()
                {
                    Roleid = s.Id,
                    Name = s.Name,


                }).ToList();

            if (roles.Any())
            {
                _model.Data = roles;
                _model.Status = 201;
                _model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Success = true;
                return _model;
            }

            else
            {
                _model.Data = null;
                _model.Message = MessageCode.StatusCode.TryGetValue(404, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Status = 404;
                _model.Success = false;

                return _model;
            }


        }

        private Expression<Func<VmSemats.SematBuName, object>> GetSortProperty(GetResultQuery request)
            => request.SortColumn?.ToLower() switch
            {
                "FullName" => Student => Student.FullName,
                "TitleSemat" => Student => Student.TitleMokatebati,
                "Organization" => Student => Student.Organization,

                _ => Student => Student.sematId,
            };

        public async Task<ApiModel> GetSematIdByUserId(Guid userId)
        {
            var model = new ApiModel();
            var result = context.Semats.FirstOrDefault(c=>c.UserId==userId&&c.DefaultSemat==true).SematId;
            if (result is not 0)
            {

                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
       
                model.SematId = result;
                return model;
            }

            model.Data = null;
            model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                ? model.Message = messager2
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Status = 500;
            model.Success = false;

            return model;
        }
        public async Task<bool> CheckSematIdAsync(List<int> sematIds)
        {
            //if (sematId.Count() > 0)
            //{
            //    foreach (var item in sematId)
            //    {
            //        if (!await _context.Semats.AnyAsync(c => c.SematId == item))
            //            return false;
            //    }
            //    return true;
            //}
            //return false;

            if (sematIds == null || sematIds.Count == 0)
                return false;
            var existingCount = await context.Semats
                .Where(s => sematIds.Contains(s.SematId))
                .CountAsync();

            return existingCount == sematIds.Count;
        }

        public async Task<bool> CheckSematIdAndUserIdAsync(int sematId, Guid userId)
        {
            return await context.Semats.AnyAsync(c => c.SematId == sematId && c.UserId == userId);
        }
    }
}
