﻿using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class SourceKeyIdService(DataContext _context) : ISourceKeyIdService
    {
        public SourceKeyID AddSource(SourceKeyID source)
        {
            _context.SourceKeyID.Add(source);
            return source;
        }

        public async Task<bool> CheckSourceIdAsync(int sourceId)
        {
            return await _context.SourceKeyID.AnyAsync(c => c.Id == sourceId);
        }
        public async Task<ApiModel> GetAllSourceAsync(GetResultQuery request, GetResultQueryErja requestErja)
        {
            ApiModel model = new ApiModel();

            if (requestErja.SematId == 0 || requestErja.SourceType == 0 || requestErja.BoxType == 0)
            {
                model.Data = null;
                model.Status = 400;
                model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager)
                    ? messager
                    : "کد وضعیت نامعتبر است.";
                model.Success = false;
                return model;
            }

            try
            {
                var query = _context.SourceKeyID
                    .Where(c => c.SourceType == requestErja.SourceType)
                    .AsNoTracking();

                if (requestErja.BoxType == 1)
                {
                    query = query.Where(c => c.Erjas.Any(x =>
                        x.Reciver_SematId == requestErja.SematId &&
                        x.Sender_SematId != requestErja.SematId));
                }

                if (requestErja.BoxType == 2)
                {
                    query = query.Where(c => c.Erjas.Any(x =>
                        x.Reciver_SematId == requestErja.SematId &&
                        x.Sender_SematId == requestErja.SematId));
                }

                if (requestErja.WithAnswers != null)
                {
                    query = requestErja.WithAnswers == true
                        ? query.Where(c => c.Erjas.Any(x => x.Answer != null && x.Answer != ""))
                        : query.Where(c => c.Erjas.Any(x => x.Answer == null || x.Answer == ""));
                }

                if (requestErja.SourceType == 1)
                {
                    if (!string.IsNullOrEmpty(request.SearchTerm))
                    {
                        var searchTerm = request.SearchTerm.Trim();
                        query = query.Where(c =>
                            c.InnerLetter.Title.Contains(searchTerm) ||
                            c.InnerLetter.Letter_Number.Contains(searchTerm));
                    }

                    if (!string.IsNullOrEmpty(request.FilterColumn) && !string.IsNullOrEmpty(request.FilterValue))
                    {
                        var filterValue = request.FilterValue.Trim();
                        var filterColumn = request.FilterColumn.Trim().ToLower();

                        switch (filterColumn)
                        {
                            case "isneshan" when bool.TryParse(filterValue, out var isNeshan):
                                query = query.Where(r => r.Erjas.Any(x => x.IsNeshan == isNeshan));
                                break;
                            case "foriat":
                                query = query.Where(r => r.InnerLetter.Foriat == filterValue);
                                break;
                            case "mahramanegi":
                                query = query.Where(r => r.InnerLetter.Mahramanegi == filterValue);
                                break;
                        }
                    }

                    if (request.FirstDate != null && request.EndDate != null)
                    {
                        query = query.Where(c =>
                            c.InnerLetter.DateSabt >= request.FirstDate.Value &&
                            c.InnerLetter.DateSabt <= request.EndDate.Value);
                    }
                    else if (request.FirstDate != null)
                    {
                        query = query.Where(c => c.InnerLetter.DateSabt >= request.FirstDate.Value);
                    }
                    else if (request.EndDate != null)
                    {
                        query = query.Where(c => c.InnerLetter.DateSabt <= request.EndDate.Value);
                    }

                    if (request.SortColumn != null)
                    {
                        if (request.SortOrder?.ToLower() == "desc")
                        {
                            query = request.SortColumn.ToLower() switch
                            {
                                "date" => query.OrderByDescending(x => x.InnerLetter.DateSabt),
                                _ => query.OrderByDescending(x => x.Id)
                            };
                        }
                        else
                        {
                            query = request.SortColumn.ToLower() switch
                            {
                                "date" => query.OrderBy(x => x.InnerLetter.DateSabt),
                                _ => query.OrderBy(x => x.Id)
                            };
                        }
                    }
                    else
                    {
                        query = query.OrderBy(x => x.Id);
                    }

                    var page = request.Page ?? 1;
                    var pageSize = request.PageSize ?? 10;

                    var count = await query.CountAsync();

                    var ids = await query
                        .Skip((page - 1) * pageSize)
                        .Take(pageSize)
                        .Select(c => c.Id)
                        .ToListAsync();

                    var rows = await query
                        .Where(c => ids.Contains(c.Id))
                        .Select(c => new
                        {
                            c.Id,
                            LetterNumber = c.InnerLetter != null ? c.InnerLetter.Letter_Number : null,
                            Number = c.InnerLetter != null ? (int?)c.InnerLetter.Number : null,
                            Date = c.InnerLetter != null ? (DateTime?)c.InnerLetter.DateSabt : null,
                            Title = c.InnerLetter != null ? c.InnerLetter.Title : null,
                            Text = c.InnerLetter != null ? c.InnerLetter.Text : null,
                            Foriat = c.InnerLetter != null ? c.InnerLetter.Foriat : null,
                            Mahramanegi = c.InnerLetter != null ? c.InnerLetter.Mahramanegi : null,
                            SenderSematId = c.InnerLetter != null ? (int?)c.InnerLetter.CreatorSematId : null,
                            SenderUserId = c.InnerLetter != null ? (Guid?)c.InnerLetter.CreatorUserId : null,
                            SematTitle = c.InnerLetter != null && c.InnerLetter.Semat != null
                                ? c.InnerLetter.Semat.Title : null,
                            FirstName = c.InnerLetter != null && c.InnerLetter.Semat != null && c.InnerLetter.Semat.User != null
                                ? c.InnerLetter.Semat.User.FirstName : null,
                            LastName = c.InnerLetter != null && c.InnerLetter.Semat != null && c.InnerLetter.Semat.User != null
                                ? c.InnerLetter.Semat.User.LastName : null,
                            Erjas = c.Erjas.Select(x => new
                            {
                                x.Type,
                                x.Sender_SematId,
                                x.Reciver_SematId,
                                ReciverUserId = (Guid?)x.Reciver_UserId,
                                IsRead = (bool?)x.IsRead,
                                TypeTaeed = (int?)x.Type_Taeed,
                                RecTitle = x.SematReceiver != null ? x.SematReceiver.Title : null,
                                RecFirst = x.UserReciver != null ? x.UserReciver.FirstName : null,
                                RecLast = x.UserReciver != null ? x.UserReciver.LastName : null,
                                Avatar = x.UserReciver != null ? x.UserReciver.UserPicture : null
                            }).ToList()
                        })
                        .ToListAsync();

                    static string FullName(params string?[] parts)
                        => string.Join(" ", parts.Where(s => !string.IsNullOrWhiteSpace(s)));

                    var items = rows.Select(c => new VMInnerLetrer.InnerLetrer
                    {
                        InnerId = c.Id,
                        Letter_Number = c.LetterNumber,
                        Number = c.Number,
                        Date = c.Date ?? DateTime.Now,
                        Title = c.Title,
                        Text = c.Text,
                        SenderName = FullName(c.SematTitle, c.FirstName, c.LastName),
                        Sender_SematId = c.SenderSematId ?? 0,
                        Sender_UserId = c.SenderUserId ?? Guid.Empty,
                        Foriat = c.Foriat ?? "عادی",
                        Mahramanegi = c.Mahramanegi ?? "عادی",
                        IsRead = c.Erjas
                            .Where(x => x.Type == "E" && x.Reciver_SematId == x.Sender_SematId)
                            .Select(x => x.IsRead)
                            .FirstOrDefault(),
                        Reciver_Girande = c.Erjas.Where(x => x.Type == "G").Select(x => new SematUserFullName
                        {
                            FullName = FullName(x.RecTitle, x.RecFirst, x.RecLast),
                            userId = x.ReciverUserId ?? Guid.Empty,
                            sematId = x.Reciver_SematId
                        }).ToList(),
                        Reciver_Erja = c.Erjas
                            .Where(x => x.Type == "E" && x.Reciver_SematId != x.Sender_SematId)
                            .Select(x => new SematUserFullName
                            {
                                FullName = FullName(x.RecTitle, x.RecFirst, x.RecLast),
                                userId = x.ReciverUserId ?? Guid.Empty,
                                sematId = x.Reciver_SematId
                            }).ToList(),
                        Reciver_Hamesh = c.Erjas.Where(x => x.Type == "H").Select(x => new SematUserFullName
                        {
                            FullName = FullName(x.RecTitle, x.RecFirst, x.RecLast),
                            userId = x.ReciverUserId ?? Guid.Empty,
                            sematId = x.Reciver_SematId
                        }).ToList(),
                        UsersGirandeAvatar = c.Erjas.Where(x => x.Type == "G").Select(x => new UsersViewModel.UserAvatarVM
                        {
                            Name = FullName(x.RecFirst, x.RecLast),
                            AvatarUrl = x.Avatar,
                            Type_Taeed = x.TypeTaeed ?? 0,
                            IsRead = x.IsRead ?? false
                        }).ToList()
                    }).ToList();

                    model.Data = new PagedList<VMInnerLetrer.InnerLetrer>(items, page, pageSize, count);
                }

                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager)
                    ? messager
                    : "کد وضعیت نامعتبر است.";
                return model;
            }
            catch (Exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager)
                    ? messager
                    : "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }



        // متد کمکی برای تبدیل Type_Taeed

        //public async Task<ApiModel> GetAllSourceAsync(GetResultQuery request, GetResultQueryErja requestErja)
        //{
        //    ApiModel model = new ApiModel();

        //    if (requestErja.SematId == 0 || requestErja.SourceType == 0 || requestErja.BoxType == 0)
        //    {
        //        model.Data = null;
        //        model.Status = 400;
        //        model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
        //            ? model.Message = messager
        //            : model.Message = "کد وضعیت نامعتبر است.";
        //        model.Success = false;
        //        return model;
        //    }

        //    try
        //    {
        //        var query = _context.SourceKeyID.Where(c => c.SourceType == requestErja.SourceType).AsNoTracking();

        //        // 1 یعنی دریافتی
        //        if (requestErja.BoxType == 1)
        //        {
        //            query = query.Where(c => c.Erjas.Any(x => x.Reciver_SematId == requestErja.SematId && x.Sender_SematId != requestErja.SematId));
        //        }
        //        // 2 یعنی ارسالی
        //        if (requestErja.BoxType == 2)
        //        {
        //            query = query.Where(c => c.Erjas.Any(x => x.Reciver_SematId == requestErja.SematId && x.Sender_SematId == requestErja.SematId));
        //        }
        //        if (requestErja.WithAnswers != null)
        //        {
        //            if (requestErja.WithAnswers == true)
        //            {
        //                query = query.Where(c => c.Erjas.Any(x => x.Answer != null && x.Answer != ""));
        //            }
        //            else
        //            {
        //                query = query.Where(c => c.Erjas.Any(x => x.Answer == null || x.Answer == ""));
        //            }
        //        }

        //        if (requestErja.SourceType == 1)
        //        {
        //            // جستجو نامه بر اساس عنوان، شماره نامه  
        //            if (!string.IsNullOrEmpty(request.SearchTerm))
        //            {
        //                var searchTerm = request.SearchTerm.Trim();
        //                query = query.Where(c => c.InnerLetter.Title.Contains(searchTerm) || c.InnerLetter.Letter_Number.Contains(searchTerm));
        //            }

        //            // فیلتر کردن نامه بر اساس نشانه گذاری ها، عادی در طبقه بندی، فوری، محرمانه، عادی در محرمانه، فوق محرمانه
        //            if (!string.IsNullOrEmpty(request.FilterColumn) && !string.IsNullOrEmpty(request.FilterValue))
        //            {
        //                var filterValue = request.FilterValue.Trim();
        //                var filterColumn = request.FilterColumn.Trim().ToLower();

        //                switch (filterColumn)
        //                {
        //                    case "isneshan" when bool.TryParse(filterValue, out var isNeshan):
        //                        query = query.Where(r => r.Erjas.Any(x => x.IsNeshan == isNeshan));
        //                        break;

        //                    case "foriat":
        //                        query = query.Where(r => r.InnerLetter.Foriat == filterValue);
        //                        break;

        //                    case "mahramanegi":
        //                        query = query.Where(r => r.InnerLetter.Mahramanegi == filterValue);
        //                        break;

        //                }
        //            }

        //            // نامه ها را از تاریخ فلان تا تاریخ فلان نمایش دهد
        //            if (request.FirstDate != null && request.EndDate != null)
        //            {
        //                query = query.Where(c =>
        //               c.InnerLetter.DateSabt >= request.FirstDate.Value && c.InnerLetter.DateSabt <= request.EndDate.Value);
        //            }
        //            //نامه ها را از تاریخ فلان به بعد
        //            else if (request.FirstDate != null)
        //            {
        //                query = query.Where(c =>
        //               c.InnerLetter.DateSabt >= request.FirstDate.Value);
        //            }
        //            //نامه ها را از تاریخ فلان به قبل
        //            else if (request.EndDate != null)
        //            {
        //                query = query.Where(c =>
        //               c.InnerLetter.DateSabt <= request.EndDate.Value);
        //            }

        //            //Order => صعودی یا نزولی desc/asc
        //            //بعد از آن مرتب کن بر اساس ستونی که کاربر می دهد SortColumn
        //            if (request.SortColumn != null)
        //            {
        //                if (request.SortOrder?.ToLower() == "desc")
        //                {
        //                    query = request.SortColumn.ToLower() switch
        //                    {
        //                        "date" => query.OrderByDescending(x => x.InnerLetter.DateSabt),

        //                        _ => query.OrderByDescending(x => x.Id)
        //                    };
        //                }
        //                else
        //                {
        //                    query = request.SortColumn.ToLower() switch
        //                    {
        //                        "date" => query.OrderBy(x => x.InnerLetter.DateSabt),

        //                        _ => query.OrderBy(x => x.Id)
        //                    };
        //                }
        //            }
        //            else
        //            {
        //                query = query.OrderBy(x => x.Id);
        //            }

        //            var result = query.Select(c => new VMInnerLetrer.InnerLetrer()
        //            {
        //                InnerId = c.Id,
        //                Letter_Number = c.InnerLetter.Letter_Number,
        //                Number = c.InnerLetter.Number,
        //                Date = c.InnerLetter.DateSabt,
        //                Title = c.InnerLetter.Title,
        //                Text = c.InnerLetter.Text,
        //                SenderName = c.InnerLetter.Semat.Title + " " + c.InnerLetter.Semat.User.FirstName + " " + c.InnerLetter.Semat.User.LastName,
        //                Sender_SematId = c.InnerLetter.CreatorSematId,
        //                Sender_UserId = c.InnerLetter.CreatorUserId,
        //                Foriat = c.InnerLetter.Foriat,
        //                Mahramanegi = c.InnerLetter.Mahramanegi,
        //                IsRead = c.Erjas.Where(x => x.Type == "E" && x.Reciver_SematId == x.Sender_SematId)
        //                                   .Select(x => (bool?)x.IsRead).FirstOrDefault(),
        //                Reciver_Girande = c.Erjas
        //                                   .Where(x => x.Type == "G")
        //                                   .Select(x => new SematUserFullName
        //                                   {
        //                                       FullName = x.SematReceiver.Title + " " + x.SematReceiver.User.FirstName + " " + x.SematReceiver.User.LastName,
        //                                       userId = x.Reciver_UserId,
        //                                       sematId = x.Reciver_SematId
        //                                   }).ToList(),
        //                Reciver_Erja = c.Erjas
        //                                   .Where(x => x.Type == "E" && x.Reciver_SematId != x.Sender_SematId)
        //                                   .Select(x => new SematUserFullName
        //                                   {
        //                                       FullName = x.SematReceiver.Title + " " + x.SematReceiver.User.FirstName + " " + x.SematReceiver.User.LastName,
        //                                       userId = x.Reciver_UserId,
        //                                       sematId = x.Reciver_SematId
        //                                   }).ToList(),
        //                Reciver_Hamesh = c.Erjas
        //                                   .Where(x => x.Type == "H")
        //                                   .Select(x => new SematUserFullName
        //                                   {
        //                                       FullName = x.SematReceiver.Title + " " + x.SematReceiver.User.FirstName + " " + x.SematReceiver.User.LastName,
        //                                       userId = x.Reciver_UserId,

        //                                       sematId = x.Reciver_SematId
        //                                   }).ToList(),
        //                UsersGirandeAvatar = c.Erjas
        //                                   .Where(x => x.Type == "G")
        //                                   .Select(x => new UsersViewModel.UserAvatarVM
        //                                   {
        //                                       Name = x.SematReceiver.User.FirstName + " " + x.SematReceiver.User.LastName,
        //                                       AvatarUrl = x.SematReceiver.User.UserPicture,
        //                                       Type_Taeed = x.Type_Taeed,
        //                                       IsRead = x.IsRead
        //                                   }).ToList(),

        //                UsersSenderAvatar = c.Erjas
        //                                   .Where(x => x.Type == "G")
        //                                   .Select(x => new UsersViewModel.UserAvatarVM
        //                                   {
        //                                       Name = x.SematSender.User.FirstName + " " + x.SematSender.User.LastName,
        //                                       AvatarUrl = x.SematSender.User.UserPicture,
        //                                       Type_Taeed = x.Type_Taeed,
        //                                   }).ToList()
        //            });

        //            var data = await PagedList<VMInnerLetrer.InnerLetrer>.CreateAsync(result, (int)request.Page, (int)request.PageSize);
        //            model.Data = data;
        //            model.TotalCount = data.TotalCount;
        //        }

        //        model.Status = 200;
        //        model.Success = true;
        //        model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
        //            ? model.Message = messager
        //            : model.Message = "کد وضعیت نامعتبر است.";
        //        return model;
        //    }
        //    catch (Exception exception)
        //    {
        //        model.Data = null;
        //        model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
        //            ? model.Message = messager
        //            : model.Message = "کد وضعیت نامعتبر است.";
        //        model.Status = 500;
        //        model.Success = false;
        //        return model;
        //    }
        //}

        public async Task<SourceKeyID> GetSourceByIdAsync(int sourceId)
        {
            var result = await _context.SourceKeyID.FindAsync(sourceId);
            if (result is not null)
            {
                return result;
            }
            return new SourceKeyID();
        }
    }
}
