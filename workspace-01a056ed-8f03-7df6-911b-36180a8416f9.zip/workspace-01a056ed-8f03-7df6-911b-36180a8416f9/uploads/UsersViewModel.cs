﻿using CoreApp.DTOs.ViewModel.VMTicket;
using System.ComponentModel.DataAnnotations;

namespace CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser
{
    public class UsersViewModel
    {
        public class UserViewModel
        {

            public Guid? UserId { get; set; }
            public string F_Name { get; set; }
            public string L_Name { get; set; }

            //[Required(ErrorMessage = "لطفا نام و نام خانوادگی را وارد کنید")]
            public string FullName { get; set; }

            // [Required(ErrorMessage = "لطفا نام کاربری را وارد کنید")]
            public string UserName { get; set; }
            public string Gender { get; set; }
            //[MinLength(1, ErrorMessage = "حداقل یک شرکت باید انتخاب شود")]
            public List<CompanyforCombo> SelectedCompanyId { get; set; } = new List<CompanyforCombo>();

            // [Required(ErrorMessage = "لطفا کلمه ورود را وارد کنید")]
            public string Password { get; set; }
            public string Address { get; set; }
            public string CodePersoneli { get; set; }
            public string CodeMeli { get; set; }
            public string? UserPicture { get; set; }

            //[Required(ErrorMessage = "لطفا شماره تماس را وارد کنید")]
            public string PhoneNumber { get; set; }
            public string? Email { get; set; }
            public bool IsActive { get; set; } = true;
            public bool IsDelete { get; set; } = false;
            public DateTime? TavalodDate { get; set; }
            public string? FileName { get; set; }
            public byte[]? FileContent { get; set; }
            public List<SignaturesUserModel> Signatures { get; set; } = new List<SignaturesUserModel>();


        }

        public class GetUserName
        {
            public Guid UserId { get; set; }
            public string FullName { get; set; }
        }
        public class UserAvatarVM
        {
            public string Name { get; set; }
            public string AvatarUrl { get; set; }
            public int? ConditionTodo { get; set; }
            public int? Type_Taeed { get; set; }
            public int SenderId { get; set; }
            public int ReciverId { get; set; }
            public bool IsForMe { get; set; }
            public DateTime? LastActionDate { get; set; }
            public bool IsRead { get; set; }
        }
    }
}
