﻿using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.Service.ServiceBase;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using PaginationSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class ErjaService(DataContext _context, ISourceKeyIdService _sourceKeyIdService, IAmalgarService _amalgarService, ISematService _sematService, IGroupService _groupService) : IErjaService
    {
        public void AddErja(List<Erja> erjas)
        {
            if (erjas == null || erjas.Count == 0)
                return;

            _context.Erjas.AddRange(erjas);
        }

        private Erja CreateErja(int sourceId, int senderSematId, Guid senderUserId,
                        int receiverSematId, Guid receiverUserId,
                        DateTime date, string type, string matnErja, int amalgarId, DateTime? mohlat_Pasokh)
        {
            return new Erja
            {
                SourceId = sourceId,
                Sender_SematId = senderSematId,
                Reciver_SematId = receiverSematId,
                Sender_UserId = senderUserId,
                Reciver_UserId = receiverUserId,
                Date = date,
                Type = type,
                Type_Taeed = 0,
                Answer = "",
                IsRead = false,
                Is_Bayegani = false,
                Matn_Erja = matnErja,
                Amalgar_Id = amalgarId,
                IsNeshan = false,
                ShowForAll = false,
                ShowMassage = true,
                IsReadAnswer = false,
                ShowMassageAnswer = false,
                Mohlat_Pasokh = mohlat_Pasokh,
                IsDelete = false,
            };
        }

        public async Task<ApiModel> AddErjaAsync(VMErja vmErja)
        {
            ApiModel model = new ApiModel();
            DateTime dateNow = DateTime.Now;

            // متن ارجاع نباید خالی باشد یا نباید IsErja == IsHamesh باشد
            if (string.IsNullOrEmpty(vmErja.Matn_Erja) || (vmErja.IsErja == vmErja.IsHamesh))
            {
                model.Data = null;
                model.Status = 400;
                model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
                return model;
            }
            try
            {
                if (!await _sourceKeyIdService.CheckSourceIdAsync(vmErja.SourceId))
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "آیدی منبع معتبر نیست";
                    model.Success = false;
                    return model;
                }

                if (!await _amalgarService.CheckAmalgarIdAsync(vmErja.Amalgar_Id))
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "آیدی عملگر معتبر نیست";
                    model.Success = false;
                    return model;
                }

                if (!await _sematService.CheckSematIdAndUserIdAsync(vmErja.Sender_SematId, vmErja.Sender_UserId))
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "آیدی سمت فرستنده یا آیدی یوزر فرستنده معتبر نیست";
                    model.Success = false;
                    return model;
                }

                List<Erja> listErja = new List<Erja>();

                if (vmErja.IsErja)
                {
                    bool isErjaEmpty = vmErja.Reciver_Erja == null || vmErja.Reciver_Erja.Count == 0;
                    bool isGroupsErjaEmpty = vmErja.Reciver_GroupsErja == null || vmErja.Reciver_GroupsErja.Count == 0;

                    if (isErjaEmpty == isGroupsErjaEmpty)
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "نمی تواند لیست گروه ارجاع و لیست ارجاع هردو پر باشد یا هردو خالی باشد";
                        model.Success = false;
                        return model;
                    }

                    if (!isErjaEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmErja.Reciver_Erja.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }

                        listErja.AddRange(vmErja.Reciver_Erja.Select(item =>
                                                 CreateErja(vmErja.SourceId, vmErja.Sender_SematId,
                                                 vmErja.Sender_UserId, item.sematId, item.userId,
                                                 dateNow, "E", vmErja.Matn_Erja, vmErja.Amalgar_Id, vmErja.Mohlat_Pasokh)));
                    }
                    if (!isGroupsErjaEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmErja.Reciver_GroupsErja))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }

                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmErja.Reciver_GroupsErja);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(vmErja.SourceId, vmErja.Sender_SematId,
                                                 vmErja.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "E", vmErja.Matn_Erja, vmErja.Amalgar_Id, vmErja.Mohlat_Pasokh)));
                    }

                }

                if (vmErja.IsHamesh)
                {
                    bool isHameshEmpty = vmErja.Reciver_Hamesh == null || vmErja.Reciver_Hamesh.Count == 0;
                    bool isGroupsHameshEmpty = vmErja.Reciver_GroupsHamesh == null || vmErja.Reciver_GroupsHamesh.Count == 0;

                    if (isHameshEmpty == isGroupsHameshEmpty)
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "نمی تواند لیست گروه هامش و لیست هامش هردو پر باشد یا هردو خالی باشد";
                        model.Success = false;
                        return model;
                    }

                    if (!isHameshEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmErja.Reciver_Hamesh.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }

                        listErja.AddRange(vmErja.Reciver_Hamesh.Select(item =>
                        CreateErja(vmErja.SourceId, vmErja.Sender_SematId,
                        vmErja.Sender_UserId, item.sematId, item.userId,
                        dateNow, "H", vmErja.Matn_Erja, vmErja.Amalgar_Id, vmErja.Mohlat_Pasokh)));

                    }
                    if (!isGroupsHameshEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmErja.Reciver_GroupsHamesh))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }

                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmErja.Reciver_GroupsHamesh);

                        listErja.AddRange(usersGroup.Select(item =>
                        CreateErja(vmErja.SourceId, vmErja.Sender_SematId,
                        vmErja.Sender_UserId, item.sematId, item.userId,
                        dateNow, "H", vmErja.Matn_Erja, vmErja.Amalgar_Id, vmErja.Mohlat_Pasokh)));
                    }

                }
                _context.Erjas.AddRange(listErja);
                await _context.SaveChangesAsync();

                var data = listErja.Select(item => new VMErja
                {
                    ErjaId = item.ErjaId,
                    SourceId = item.SourceId,
                    Sender_SematId = item.Sender_SematId,
                    Reciver_SematId = item.Reciver_SematId,
                    Sender_UserId = item.Sender_UserId,
                    Reciver_UserId = item.Reciver_UserId,
                    Date = item.Date,
                    Type = item.Type,
                    Type_Taeed = item.Type_Taeed,
                    Answer = item.Answer,
                    IsRead = item.IsRead,
                    Is_Bayegani = item.Is_Bayegani,
                    Mohlat_Pasokh = item.Mohlat_Pasokh,
                    Matn_Erja = item.Matn_Erja,
                    Amalgar_Id = item.Amalgar_Id,
                    IsNeshan = item.IsNeshan,
                    ShowForAll = item.ShowForAll,
                    ShowMassage = item.ShowMassage,
                    DateRead = item.DateRead,
                    DateEmza = item.DateEmza,
                    DateAnswer = item.DateAnswer,
                    IsReadAnswer = item.IsReadAnswer,
                    ShowMassageAnswer = item.ShowMassageAnswer
                }).ToList();

                model.Data = data;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }

        }

        public async Task DeleteErjaWithSourceIdAsync(int sourceId)
        {
            var erja = await _context.Erjas.Where(c => c.SourceId == sourceId).ToListAsync();
            if (erja.Any())
            {
                _context.Erjas.RemoveRange(erja);
            }
        }

        public async Task<ApiModel> GetErjaByIdVMAsync(int erjaId)
        {
            var model = new ApiModel();

            var data = await _context.Erjas
                .Where(e => e.ErjaId == erjaId)
                .Select(e => new VMErja
                {
                    ErjaId = e.ErjaId,
                    SourceId = e.SourceId,
                    Sender_SematId = e.Sender_SematId,
                    Reciver_SematId = e.Reciver_SematId,
                    Sender_UserId = e.Sender_UserId,
                    Reciver_UserId = e.Reciver_UserId,
                    Date = e.Date,
                    Type = e.Type,
                    Type_Taeed = e.Type_Taeed,
                    Answer = e.Answer,
                    IsRead = e.IsRead,
                    Is_Bayegani = e.Is_Bayegani,
                    Mohlat_Pasokh = e.Mohlat_Pasokh,
                    Matn_Erja = e.Matn_Erja,
                    Amalgar_Id = e.Amalgar_Id,
                    Amalgar_Title = e.Amalgar.Title,
                    IsNeshan = e.IsNeshan,
                    ShowForAll = e.ShowForAll,
                    ShowMassage = e.ShowMassage,
                    DateRead = e.DateRead,
                    DateEmza = e.DateEmza,
                    DateAnswer = e.DateAnswer,
                    IsReadAnswer = e.IsReadAnswer,
                    ShowMassageAnswer = e.ShowMassageAnswer,
                    SenderName = e.SematSender.Title + " " + e.SematSender.User.FirstName + " " + e.SematSender.User.LastName,
                    ReciverName = e.SematReceiver.Title + " " + e.SematReceiver.User.FirstName + " " + e.SematReceiver.User.LastName
                })
                .FirstOrDefaultAsync();

            if (data != null)
            {
                model.Data = data;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            else
            {
                model.Data = null;
                model.Status = 0;
                model.Message = "این آیدی در جدول وجود ندارد";
                model.Success = false;
            }

            return model;
        }

        public async Task<ApiModel> GetGardeshErjaAsync(int sourceId, GetResultQuery request)
        {
            var model = new ApiModel();
            try
            {
                var query = _context.Erjas.Where(c => c.SourceId == sourceId && c.Sender_SematId != c.Reciver_SematId).AsNoTracking();

                // جستجو ارجاع بر اساس متن عملگر، متن ارجاع، گیرنده، فرستنده  
                if (!string.IsNullOrEmpty(request.SearchTerm))
                {
                    var searchTerm = request.SearchTerm.Trim();
                    query = query.Where(c => c.Amalgar.Title.Contains(searchTerm) || c.Matn_Erja.Contains(searchTerm) ||
                    c.UserSender.FirstName.Contains(searchTerm) || c.UserSender.LastName.Contains(searchTerm) ||
                    c.SematSender.Title.Contains(searchTerm) || c.UserReciver.FirstName.Contains(searchTerm) ||
                    c.UserReciver.LastName.Contains(searchTerm) || c.SematReceiver.Title.Contains(searchTerm));
                }

                //Order => صعودی یا نزولی desc/asc
                //بعد از آن مرتب کن بر اساس ستونی که کاربر می دهد SortColumn
                if (request.SortColumn != null)
                {
                    if (request.SortOrder?.ToLower() == "desc")
                    {
                        query = request.SortColumn.ToLower() switch
                        {
                            "date" => query.OrderByDescending(x => x.Date),

                            _ => query.OrderByDescending(x => x.ErjaId)
                        };
                    }
                    else
                    {
                        query = request.SortColumn.ToLower() switch
                        {
                            "date" => query.OrderBy(x => x.Date),

                            _ => query.OrderBy(x => x.ErjaId)
                        };
                    }
                }
                else
                {
                    query = query.OrderBy(x => x.ErjaId);
                }

                var result = query.Select(e => new VMErja()
                {
                    ErjaId = e.ErjaId,
                    SourceId = e.SourceId,
                    Sender_SematId = e.Sender_SematId,
                    Reciver_SematId = e.Reciver_SematId,
                    Sender_UserId = e.Sender_UserId,
                    Reciver_UserId = e.Reciver_UserId,
                    Date = e.Date,
                    Type = e.Type,
                    Type_Taeed = e.Type_Taeed,
                    Answer = e.Answer,
                    IsRead = e.IsRead,
                    Is_Bayegani = e.Is_Bayegani,
                    Mohlat_Pasokh = e.Mohlat_Pasokh,
                    Matn_Erja = e.Matn_Erja,
                    Amalgar_Id = e.Amalgar_Id,
                    Amalgar_Title = e.Amalgar.Title,
                    IsNeshan = e.IsNeshan,
                    ShowForAll = e.ShowForAll,
                    ShowMassage = e.ShowMassage,
                    DateRead = e.DateRead,
                    DateEmza = e.DateEmza,
                    DateAnswer = e.DateAnswer,
                    IsReadAnswer = e.IsReadAnswer,
                    ShowMassageAnswer = e.ShowMassageAnswer,
                    SenderName = e.SematSender.Title + " " + e.SematSender.User.FirstName + " " + e.SematSender.User.LastName,
                    ReciverName = e.SematReceiver.Title + " " + e.SematReceiver.User.FirstName + " " + e.SematReceiver.User.LastName,
                    UsersGirandeAvatar = new List<UsersViewModel.UserAvatarVM>
                    {
                       new()
                       {
                              Name = e.SematReceiver.User.FirstName + " " + e.SematReceiver.User.LastName,
                              AvatarUrl = e.SematReceiver.User.UserPicture,
                              Type_Taeed = e.Type_Taeed,
                              IsRead = e.IsRead,
                              ReciverId = e.Reciver_SematId,
                              SenderId = e.Sender_SematId
                       }
                    },

                    UsersSenderAvatar = new List<UsersViewModel.UserAvatarVM>
                    {
                           new()
                           {
                              Name = e.UserSender.FirstName + " " + e.SematSender.User.LastName,
                              AvatarUrl = e.UserSender.UserPicture,
                              Type_Taeed = e.Type_Taeed,
                              SenderId = e.Sender_SematId,
                              ReciverId = e.Reciver_SematId
                           }
                    }
                });
                    
                
               
                int page = request.Page ?? 1;
                int pageSize = request.PageSize ?? 10;

                var data = await PagedList<VMErja>.CreateAsync(result, page, pageSize);
                model.Data = data;

                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<ApiModel> AnswerToErjaAsync(int erjaId, string answer, bool showForAll, int type_Taeed)
        {
            var model = new ApiModel();

            if (string.IsNullOrWhiteSpace(answer))
            {
                model.Data = null;
                model.Status = 400;
                model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
                return model;
            }
            try
            {
                var erja = await GetErjaByIdAsync(erjaId);

                if (erja.ErjaId == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                if (!string.IsNullOrWhiteSpace(erja.Answer))
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "برای این ارجاع پاسخ ثبت شده است";
                    model.Success = false;
                    return model;
                }

                erja.Answer = answer;
                erja.ShowForAll = showForAll;
                erja.DateAnswer = DateTime.Now;
                erja.ShowMassageAnswer = true;
                erja.Type_Taeed = type_Taeed;

                await _context.SaveChangesAsync();

                var erjaVM = new VMErja();

                erjaVM.ErjaId = erja.ErjaId;
                erjaVM.SourceId = erja.SourceId;
                erjaVM.Sender_SematId = erja.Sender_SematId;
                erjaVM.Reciver_SematId = erja.Reciver_SematId;
                erjaVM.Sender_UserId = erja.Sender_UserId;
                erjaVM.Reciver_UserId = erja.Reciver_UserId;
                erjaVM.Date = erja.Date;
                erjaVM.Type = erja.Type;
                erjaVM.Type_Taeed = erja.Type_Taeed;
                erjaVM.Answer = erja.Answer;
                erjaVM.IsRead = erja.IsRead;
                erjaVM.Is_Bayegani = erja.Is_Bayegani;
                erjaVM.Mohlat_Pasokh = erja.Mohlat_Pasokh;
                erjaVM.Matn_Erja = erja.Matn_Erja;
                erjaVM.Amalgar_Id = erja.Amalgar_Id;
                erjaVM.Amalgar_Title = erja.Amalgar.Title;
                erjaVM.IsNeshan = erja.IsNeshan;
                erjaVM.ShowForAll = erja.ShowForAll;
                erjaVM.ShowMassage = erja.ShowMassage;
                erjaVM.DateRead = erja.DateRead;
                erjaVM.DateEmza = erja.DateEmza;
                erjaVM.DateAnswer = erja.DateAnswer;
                erjaVM.IsReadAnswer = erja.IsReadAnswer;
                erjaVM.ShowMassageAnswer = erja.ShowMassageAnswer;
                erjaVM.SenderName = erja.SematSender.Title + " " + erja.SematSender.User.FirstName + " " + erja.SematSender.User.LastName;
                erjaVM.ReciverName = erja.SematReceiver.Title + " " + erja.SematReceiver.User.FirstName + " " + erja.SematReceiver.User.LastName;

                model.Data = erjaVM;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<Erja> GetErjaByIdAsync(int erjaId)
        {
            var result = await _context.Erjas
                        .Include(e => e.Amalgar)
                        .Include(e => e.SematSender).ThenInclude(s => s.User)
                        .Include(e => e.SematReceiver).ThenInclude(s => s.User)
                        .FirstOrDefaultAsync(e => e.ErjaId == erjaId);
            if (result is not null)
            {
                return result;
            }
            return new Erja();
        }

        public async Task<ApiModel> AddNeshanInErjaAsync(int erjaId)
        {
            var model = new ApiModel();

            try
            {
                var erja = await GetErjaByIdAsync(erjaId);

                if (erja.ErjaId == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                erja.IsNeshan = true;

                await _context.SaveChangesAsync();

                var erjaVM = new VMErja();

                erjaVM.ErjaId = erja.ErjaId;
                erjaVM.SourceId = erja.SourceId;
                erjaVM.Sender_SematId = erja.Sender_SematId;
                erjaVM.Reciver_SematId = erja.Reciver_SematId;
                erjaVM.Sender_UserId = erja.Sender_UserId;
                erjaVM.Reciver_UserId = erja.Reciver_UserId;
                erjaVM.Date = erja.Date;
                erjaVM.Type = erja.Type;
                erjaVM.Type_Taeed = erja.Type_Taeed;
                erjaVM.Answer = erja.Answer;
                erjaVM.IsRead = erja.IsRead;
                erjaVM.Is_Bayegani = erja.Is_Bayegani;
                erjaVM.Mohlat_Pasokh = erja.Mohlat_Pasokh;
                erjaVM.Matn_Erja = erja.Matn_Erja;
                erjaVM.Amalgar_Id = erja.Amalgar_Id;
                erjaVM.Amalgar_Title = erja.Amalgar.Title;
                erjaVM.IsNeshan = erja.IsNeshan;
                erjaVM.ShowForAll = erja.ShowForAll;
                erjaVM.ShowMassage = erja.ShowMassage;
                erjaVM.DateRead = erja.DateRead;
                erjaVM.DateEmza = erja.DateEmza;
                erjaVM.DateAnswer = erja.DateAnswer;
                erjaVM.IsReadAnswer = erja.IsReadAnswer;
                erjaVM.ShowMassageAnswer = erja.ShowMassageAnswer;
                erjaVM.SenderName = erja.SematSender.Title + " " + erja.SematSender.User.FirstName + " " + erja.SematSender.User.LastName;
                erjaVM.ReciverName = erja.SematReceiver.Title + " " + erja.SematReceiver.User.FirstName + " " + erja.SematReceiver.User.LastName;

                model.Data = erjaVM;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<bool> CheckListSourceIdAndReciverAndSenderAsync(List<int> sourceIds, int sematId, int related)
        {

            if (sourceIds == null || sourceIds.Count == 0 || related == 0 || sematId == 0)
                return false;

            // فقط حالات مجاز را بررسی کن
            if (related != 1 && related != 2)
                return false;

            // حذف مقادیر تکراری
            var distinctSourceIds = sourceIds.Distinct().ToList();

            int existingCount = 0;

            if (related == 1)
            {
                existingCount = await _context.Erjas
                .Where(s => distinctSourceIds.Contains(s.SourceId) && s.Sender_SematId == sematId && s.Reciver_SematId == sematId)
                .Select(s => s.SourceId)
                .Distinct()
                .CountAsync();
            }

            if (related == 2)
            {
                existingCount = await _context.Erjas
                .Where(s => distinctSourceIds.Contains(s.SourceId) && s.Sender_SematId != sematId && s.Reciver_SematId == sematId)
                .Select(s => s.SourceId)
                .Distinct()
                .CountAsync();
            }

            return existingCount == distinctSourceIds.Count;
        }

        public async Task<ApiModel> DeleteNeshanInErjaAsync(int erjaId)
        {
            var model = new ApiModel();

            try
            {
                var erja = await GetErjaByIdAsync(erjaId);

                if (erja.ErjaId == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                erja.IsNeshan = false;

                await _context.SaveChangesAsync();

                var erjaVM = new VMErja();

                erjaVM.ErjaId = erja.ErjaId;
                erjaVM.SourceId = erja.SourceId;
                erjaVM.Sender_SematId = erja.Sender_SematId;
                erjaVM.Reciver_SematId = erja.Reciver_SematId;
                erjaVM.Sender_UserId = erja.Sender_UserId;
                erjaVM.Reciver_UserId = erja.Reciver_UserId;
                erjaVM.Date = erja.Date;
                erjaVM.Type = erja.Type;
                erjaVM.Type_Taeed = erja.Type_Taeed;
                erjaVM.Answer = erja.Answer;
                erjaVM.IsRead = erja.IsRead;
                erjaVM.Is_Bayegani = erja.Is_Bayegani;
                erjaVM.Mohlat_Pasokh = erja.Mohlat_Pasokh;
                erjaVM.Matn_Erja = erja.Matn_Erja;
                erjaVM.Amalgar_Id = erja.Amalgar_Id;
                erjaVM.Amalgar_Title = erja.Amalgar.Title;
                erjaVM.IsNeshan = erja.IsNeshan;
                erjaVM.ShowForAll = erja.ShowForAll;
                erjaVM.ShowMassage = erja.ShowMassage;
                erjaVM.DateRead = erja.DateRead;
                erjaVM.DateEmza = erja.DateEmza;
                erjaVM.DateAnswer = erja.DateAnswer;
                erjaVM.IsReadAnswer = erja.IsReadAnswer;
                erjaVM.ShowMassageAnswer = erja.ShowMassageAnswer;
                erjaVM.SenderName = erja.SematSender.Title + " " + erja.SematSender.User.FirstName + " " + erja.SematSender.User.LastName;
                erjaVM.ReciverName = erja.SematReceiver.Title + " " + erja.SematReceiver.User.FirstName + " " + erja.SematReceiver.User.LastName;

                model.Data = erjaVM;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<ApiModel> DeleteErjaByIdAsync(int sematId, int erjaId)
        {
            var model = new ApiModel();

            try
            {
                var erja = await GetErjaByIdAsync(erjaId);

                if (erja.ErjaId == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                if (erja.Sender_SematId != sematId)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "شما مجاز به حذف نیستید فقط سازنده آن مجاز به حذف است";
                    model.Success = false;
                    return model;
                }

                erja.IsDelete = true;
                await _context.SaveChangesAsync();

                var erjaVM = new VMErja();
                erjaVM.ErjaId = erja.ErjaId;
                erjaVM.SourceId = erja.SourceId;
                erjaVM.Sender_SematId = erja.Sender_SematId;
                erjaVM.Reciver_SematId = erja.Reciver_SematId;
                erjaVM.Sender_UserId = erja.Sender_UserId;
                erjaVM.Reciver_UserId = erja.Reciver_UserId;
                erjaVM.Date = erja.Date;
                erjaVM.Type = erja.Type;
                erjaVM.Type_Taeed = erja.Type_Taeed;
                erjaVM.Answer = erja.Answer;
                erjaVM.IsRead = erja.IsRead;
                erjaVM.Is_Bayegani = erja.Is_Bayegani;
                erjaVM.Mohlat_Pasokh = erja.Mohlat_Pasokh;
                erjaVM.Matn_Erja = erja.Matn_Erja;
                erjaVM.Amalgar_Id = erja.Amalgar_Id;
                erjaVM.Amalgar_Title = erja.Amalgar.Title;
                erjaVM.IsNeshan = erja.IsNeshan;
                erjaVM.ShowForAll = erja.ShowForAll;
                erjaVM.ShowMassage = erja.ShowMassage;
                erjaVM.DateRead = erja.DateRead;
                erjaVM.DateEmza = erja.DateEmza;
                erjaVM.DateAnswer = erja.DateAnswer;
                erjaVM.IsReadAnswer = erja.IsReadAnswer;
                erjaVM.ShowMassageAnswer = erja.ShowMassageAnswer;
                erjaVM.SenderName = erja.SematSender.Title + " " + erja.SematSender.User.FirstName + " " + erja.SematSender.User.LastName;
                erjaVM.ReciverName = erja.SematReceiver.Title + " " + erja.SematReceiver.User.FirstName + " " + erja.SematReceiver.User.LastName;

                model.Data = erjaVM;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<ApiModel> GetGardeshErjaTreeViewAsync(int sourceId)
        {
            ApiModel model = new ApiModel();
            try
            {
                var GirandeList = await _context.Erjas.Where(x => x.SourceId == sourceId)
                                  .OrderBy(x=>x.Date)
                                  .Select(c => new TreeNodeLetter()
                                  {
                                      Type = c.Type,
                                      Date = c.Date,
                                      DateRead = c.DateRead,
                                      DateAnswer = c.DateAnswer,
                                      DateEmza = c.DateEmza,
                                      IsRead = c.IsRead,
                                      Is_Bayegani = c.Is_Bayegani,
                                      Type_Taeed = c.Type_Taeed,
                                      Answer = c.Answer,
                                      Matn_Erja = c.Matn_Erja,
                                      Amalgar_Title = c.Amalgar.Title,
                                      ReciverId = c.Reciver_SematId,
                                      SenderId = c.Sender_SematId,
                                      Reciver = c.SematReceiver.Title + " " + c.UserReciver.FirstName + " " + c.UserReciver.LastName,
                                      Sender = c.SematSender.Title + " " + c.UserSender.FirstName + " " + c.UserSender.LastName,
                                      FileNameReciver = c.UserReciver.UserPicture,
                                      FileNameSender = c.UserSender.UserPicture,
                                  }).ToListAsync();

                if (GirandeList.Count == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                model.Data = GirandeList;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;

                return model;
            }
        }

        public async Task<ApiModel> UpdateIsReadInErjaAsync(int erjaId)
        {
            var model = new ApiModel();

            try
            {
                var erja = await GetErjaByIdAsync(erjaId);

                if (erja.ErjaId == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                erja.IsRead = true;

                await _context.SaveChangesAsync();

                var erjaVM = new VMErja();

                erjaVM.ErjaId = erja.ErjaId;
                erjaVM.SourceId = erja.SourceId;
                erjaVM.Sender_SematId = erja.Sender_SematId;
                erjaVM.Reciver_SematId = erja.Reciver_SematId;
                erjaVM.Sender_UserId = erja.Sender_UserId;
                erjaVM.Reciver_UserId = erja.Reciver_UserId;
                erjaVM.Date = erja.Date;
                erjaVM.Type = erja.Type;
                erjaVM.Type_Taeed = erja.Type_Taeed;
                erjaVM.Answer = erja.Answer;
                erjaVM.IsRead = erja.IsRead;
                erjaVM.Is_Bayegani = erja.Is_Bayegani;
                erjaVM.Mohlat_Pasokh = erja.Mohlat_Pasokh;
                erjaVM.Matn_Erja = erja.Matn_Erja;
                erjaVM.Amalgar_Id = erja.Amalgar_Id;
                erjaVM.Amalgar_Title = erja.Amalgar.Title;
                erjaVM.IsNeshan = erja.IsNeshan;
                erjaVM.ShowForAll = erja.ShowForAll;
                erjaVM.ShowMassage = erja.ShowMassage;
                erjaVM.DateRead = erja.DateRead;
                erjaVM.DateEmza = erja.DateEmza;
                erjaVM.DateAnswer = erja.DateAnswer;
                erjaVM.IsReadAnswer = erja.IsReadAnswer;
                erjaVM.ShowMassageAnswer = erja.ShowMassageAnswer;
                erjaVM.SenderName = erja.SematSender.Title + " " + erja.SematSender.User.FirstName + " " + erja.SematSender.User.LastName;
                erjaVM.ReciverName = erja.SematReceiver.Title + " " + erja.SematReceiver.User.FirstName + " " + erja.SematReceiver.User.LastName;

                model.Data = erjaVM;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<ApiModel> GetAllAmalgar()
        {
            ApiModel _model = new ApiModel();

            try
            {

                var amalgars = _context.Amalgar
               .Select(c => new VMAmalgar()
               {
                   Title = c.Title,
                   Amalgar_Id = c.Amalgar_Id,
                   Taeed_Emza = c.Taeed_Emza,
               }).ToList();

                _model.Data = amalgars;
                _model.Status = 200;
                _model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Success = true;
            }
            catch (Exception e)
            {
                _model.Data = null;
                _model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? _model.Message = messager
                    : _model.Message = "کد وضعیت نامعتبر است.";
                _model.Status = 500;
                _model.Success = false;
                _model.TotalCount = 0;
            }

            return _model;



        }
    }
}
