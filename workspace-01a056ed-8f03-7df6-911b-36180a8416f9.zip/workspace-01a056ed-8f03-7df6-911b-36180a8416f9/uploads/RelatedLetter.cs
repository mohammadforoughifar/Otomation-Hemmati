﻿using DataLayerApp.Entites.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation.Letter
{
    public class RelatedLetter
    {
        [Column("RelatedId")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int Related { get; set; }
        //1 =>عطف
        //2 =>پیرو
        public int LetterId { get; set; }
        public int RelateLetterId { get; set; }
        public int SematId { get; set; }
        public Guid UserId { get; set; }
        //public int TypeForm { get; set; }
        public bool IsDelete { get; set; }

        #region Relations

        [ForeignKey(nameof(SematId))]
        public Semats Semat { get; set; }

        [ForeignKey(nameof(UserId))]
        public User User { get; set; }

        [ForeignKey(nameof(LetterId))]
        public SourceKeyID Letter { get; set; }

        [ForeignKey(nameof(RelateLetterId))]
        public SourceKeyID RelateLetter { get; set; }

        [ForeignKey(nameof(Id))]
        public SourceKeyID Source { get; set; }

        #endregion
    }
}
