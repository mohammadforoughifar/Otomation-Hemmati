﻿using DataLayerApp.Entites.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation.Letter
{
    public class PishnevisLetter
    {
        public int Pishnevis_Id { get; set; }
        public string Title { get; set; }
        public string Text { get; set; }
        public Guid UserId { get; set; }
        public int SematId { get; set; }
        public bool IsNeshan { get; set; }
        public bool IsDelete { get; set; }

        #region Relations

        [ForeignKey(nameof(SematId))]
        public Semats Semat { get; set; }
        [ForeignKey(nameof(UserId))]
        public User User { get; set; }

        #endregion
    }


}
