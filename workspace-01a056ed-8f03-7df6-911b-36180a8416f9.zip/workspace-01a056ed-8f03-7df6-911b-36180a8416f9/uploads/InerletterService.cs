﻿using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class InerletterService(DataContext _context, ISematService _sematService, IGroupService _groupService, ISourceKeyIdService _sourceKeyIdService
        , IStructureLetterService _letterStratureService, IPeyvastLetterService _peyvastService, IErjaService _erjaService, ISystemLogService _systemLogService) : IInerletterService
    {
        private async Task<int> MaxNumber()
        {
            return await _context.InnerLetter
                .OrderBy(u => u.Id)
                .Select(l => l.Number)
                .LastOrDefaultAsync();
        }
        private async Task<int> LetterNumber()
        {
            //  دریافت سال جاری شمسی
            var persianCalendar = new PersianCalendar();
            int currentYear = persianCalendar.GetYear(DateTime.Now);


            //  دریافت آخرین تاریخ ثبت‌شده برای نامه‌ها از دیتابیس
            var lastDateSabt = await _context.InnerLetter
                .OrderBy(u => u.Id)
                .Select(s => (DateTime?)s.DateSabt)
                .LastOrDefaultAsync();

            if (lastDateSabt == null)
                return 1;

            //  آخرین سال ثبت‌شده شمسی
            int lastYear = persianCalendar.GetYear(lastDateSabt.Value);

            //  اگر آخرین سال ثبت‌شده، از سال جاری کوچک‌تر است
            //    یعنی تا الان برای سال جاری هیچ نامه‌ای ثبت نشده است
            if (lastYear < currentYear)
            {
                return 1;
            }
            else
            {
                // در غیر این صورت، یعنی برای سال جاری حداقل یک نامه وجود دارد.
                // متد MaxNumber را صدا می‌زنیم تا شماره بعدی را محاسبه کند.
                return await MaxNumber() + 1;
            }
        }
        private Erja CreateErja(SourceKeyID source, int senderSematId, Guid senderUserId,
                        int receiverSematId, Guid receiverUserId,
                        DateTime date, string type)
        {
            return new Erja
            {
                Source = source,
                Sender_SematId = senderSematId,
                Reciver_SematId = receiverSematId,
                Sender_UserId = senderUserId,
                Reciver_UserId = receiverUserId,
                Date = date,
                Type = type,
                Type_Taeed = 0,
                Answer = "",
                IsRead = false,
                Is_Bayegani = false,
                Matn_Erja = "",
                Amalgar_Id = 1,
                IsNeshan = false,
                ShowForAll = false,
                ShowMassage = true,
                IsReadAnswer = false,
                ShowMassageAnswer = false,
                IsDelete = false,
            };
        }
        public async Task<ApiModel> AddInnerLetterAsync(VMInnerLetrer.InnerLetrer vmAddInner
            //, List<IFormFile> peyvastFiles
            )
        {
            ApiModel model = new ApiModel();
            DateTime dateNow = DateTime.Now;

            List<Peyvast> addedPeyvasts = null;
            List<string> savedPaths = null;

            // عنوان نباید خالی باشد یا لیست گیرنده و لیست گروه گیرنده نباید جفتشون پر باشند و نباید جفتشون هم خالی باشند
            bool isGirandeEmpty = vmAddInner.Reciver_Girande == null || vmAddInner.Reciver_Girande.Count == 0;
            bool isGroupsGirandeEmpty = vmAddInner.Reciver_GroupsGirande == null || vmAddInner.Reciver_GroupsGirande.Count == 0;
            bool isErjaEmpty = vmAddInner.Reciver_Erja == null || vmAddInner.Reciver_Erja.Count == 0;
            bool isGroupsErjaEmpty = vmAddInner.Reciver_GroupsErja == null || vmAddInner.Reciver_GroupsErja.Count == 0;
            bool isHameshEmpty = vmAddInner.Reciver_Hamesh == null || vmAddInner.Reciver_Hamesh.Count == 0;
            bool isGroupsHameshEmpty = vmAddInner.Reciver_GroupsHamesh == null || vmAddInner.Reciver_GroupsHamesh.Count == 0;
            if (string.IsNullOrEmpty(vmAddInner.Title) || (isGirandeEmpty == isGroupsGirandeEmpty))
            {
                model.Data = null;
                model.Status = 400;
                model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
                return model;
            }
            else
            {
                using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    if (!isGirandeEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Girande.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت گیرنده معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsGirandeEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsGirande))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه گیرنده معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isErjaEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Erja.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsErjaEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsErja))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isHameshEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Hamesh.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsHameshEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsHamesh))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!await _sematService.CheckSematIdAndUserIdAsync(vmAddInner.Sender_SematId, vmAddInner.Sender_UserId))
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "آیدی سمت فرستنده یا آیدی یوزر فرستنده معتبر نیست";
                        model.Success = false;
                        return model;
                    }

                    SourceKeyID newSource = new SourceKeyID()
                    {
                        SourceType = 1,
                        IsDelete = false
                    };

                    newSource = _sourceKeyIdService.AddSource(newSource);

                    //if (newSource.Id == 0)
                    //{
                        //model.Data = null;
                        //model.Status = 0;
                        //model.Message = "اطلاعات در جدول پایه ذخیره نشد";
                        //model.Success = false;
                        //return model;
                    //}

                    int number = await LetterNumber();
                    string letter_Number = await _letterStratureService.TotalNumberAsync(number, 1, vmAddInner.Sender_SematId);

                    if (letter_Number == string.Empty)
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "شماره نامه ساخته نشد";
                        model.Success = false;
                        return model;
                    }

                    InnerLetter newLetter = new InnerLetter()
                    {
                        //Id = newSource.Id,
                        Source = newSource,
                        Letter_Number = letter_Number,
                        Number = number,
                        CreatorSematId = vmAddInner.Sender_SematId,
                        CreatorUserId = vmAddInner.Sender_UserId,
                        Title = vmAddInner.Title,
                        Text = vmAddInner.Text,
                        DateSabt = dateNow,
                        Mahramanegi = vmAddInner.Mahramanegi,
                        Foriat = vmAddInner.Foriat,
                        IsDelete = false
                    };
                    _context.InnerLetter.Add(newLetter);

                    //if (peyvastFiles?.Any() == true)
                    //{
                    //    (addedPeyvasts, savedPaths) = _peyvastService.AddPeyvastLetter(
                    //        peyvastFiles,
                    //        "Peyvast",
                    //        newSource.Id,
                    //        vmAddInner.Sender_SematId,
                    //        vmAddInner.Sender_UserId
                    //    );
                    //}

                    List<Erja> listErja = new List<Erja>();

                    if (!isGirandeEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Girande.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "G")));

                    }
                    if (!isErjaEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Erja.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "E")));

                    }
                    if (!isHameshEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Hamesh.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "H")));

                    }
                    if (!isGroupsGirandeEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsGirande);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "G")));
                    }
                    if (!isGroupsErjaEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsErja);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "E")));

                    }
                    if (!isGroupsHameshEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsHamesh);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateNow, "H")));
                    }

                    listErja.Add(CreateErja(newSource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, vmAddInner.Sender_SematId, vmAddInner.Sender_UserId,
                                             dateNow, "E"));

                    if (listErja.Any())
                        _erjaService.AddErja(listErja);

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();

                    List<SystemLog> logs = new List<SystemLog>();
                    logs.Add(new SystemLog()
                    {
                        SematId = vmAddInner.Sender_SematId,
                        UserId = vmAddInner.Sender_UserId,
                        LastDate = dateNow,
                        FormId = newSource.Id,
                        FormType = 1,
                        Action = 1,
                        Number = newLetter.Letter_Number,
                        IsDelete = false
                    });
                    if (addedPeyvasts != null && addedPeyvasts.Any())
                    {
                        logs.AddRange(addedPeyvasts.Select(item => new SystemLog()
                        {
                            SematId = vmAddInner.Sender_SematId,
                            UserId = vmAddInner.Sender_UserId,
                            LastDate = dateNow,
                            FormId = item.Peyvast_Id,
                            FormType = 11,
                            Action = 1,
                            IsDelete = false
                        }));
                    }
                    if (listErja != null && listErja.Any())
                    {
                        logs.AddRange(listErja.Select(item => new SystemLog()
                        {
                            SematId = vmAddInner.Sender_SematId,
                            UserId = vmAddInner.Sender_UserId,
                            LastDate = dateNow,
                            FormId = item.ErjaId,
                            FormType = 10,
                            Action = 1,
                            IsDelete = false
                        }));
                    }

                    await _systemLogService.AddSystemLogAsync(logs);

                    //ویومدلی که کاربر پاس داده است
                    vmAddInner.InnerId = newSource.Id;
                    vmAddInner.Letter_Number = newLetter.Letter_Number;
                    vmAddInner.Number= newLetter.Number;

                    model.Data = vmAddInner;
                    model.Status = 201;
                    model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                    return model;


                }
                catch (Exception e)
                {
                    await transaction.RollbackAsync();

                    // پاک‌سازی فایل‌ها در صورت خطا
                    if (savedPaths != null)
                    {
                        foreach (var path in savedPaths)
                        {
                            if (File.Exists(path))
                                File.Delete(path);
                        }
                    }

                    model.Data = null;
                    model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                        ? model.Message = messager2
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Status = 500;
                    model.Success = false;
                    return model;
                }
            }
        }

        public async Task<ApiModel> GetDetailLetterVMAsync(int letterId)
        {
            var model = new ApiModel();

            try
            {
                var query = await _context.Erjas
                    .Where(e => e.SourceId == letterId && e.Sender_SematId != e.Reciver_SematId)
                    .Select(e => new
                    {
                        Letter = e.Source.InnerLetter,
                        Sender = e.SematSender,
                        Receiver = e.SematReceiver,
                        Type = e.Type,
                        Date = e.Date,
                        SenderFullName = e.SematSender.Title + " " + e.SematSender.User.FirstName + " " + e.SematSender.User.LastName,
                        ReceiverFullName = e.SematReceiver.Title + " " + e.SematReceiver.User.FirstName + " " + e.SematReceiver.User.LastName,
                        ReceiverUserId = e.Reciver_UserId
                    })
                    .ToListAsync();

                if (!query.Any())
                {
                    model.Status = 404;
                    model.Message = "نامه‌ای با این شناسه یافت نشد.";
                    model.Success = false;
                    return model;
                }

                // استخراج اطلاعات نامه از اولین رکورد
                var first = query.First();
                var result = new VMInnerLetrer.InnerLetrer
                {
                    InnerId = letterId,
                    Letter_Number = first.Letter?.Letter_Number,
                    Number= first.Letter?.Number,
                    Date = first.Date,
                    Title = first.Letter?.Title,
                    Text = first.Letter?.Text,
                    SenderName = first.SenderFullName,
                    Sender_SematId=first.Sender.SematId,
                    Sender_UserId=first.Sender.UserId,
                    Foriat = first.Letter?.Foriat,
                    Mahramanegi = first.Letter?.Mahramanegi
                };

                // دسته‌بندی گیرندگان بر اساس نوع
                result.Reciver_Girande = query
                    .Where(x => x.Type == "G")
                    .Select(x => new SematUserFullName
                    {
                        FullName = x.ReceiverFullName,
                        userId = x.ReceiverUserId,
                        sematId = x.Receiver.SematId
                    })
                    .ToList();

                result.Reciver_Erja = query
                    .Where(x => x.Type == "E")
                    .Select(x => new SematUserFullName
                    {
                        FullName = x.ReceiverFullName,
                        userId = x.ReceiverUserId,
                        sematId = x.Receiver.SematId
                    })
                    .ToList();

                result.Reciver_Hamesh = query
                    .Where(x => x.Type == "H")
                    .Select(x => new SematUserFullName
                    {
                        FullName = x.ReceiverFullName,
                        userId = x.ReceiverUserId,
                        sematId = x.Receiver.SematId
                    })
                    .ToList();

                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch (Exception ex)
            {
                model.Data = null;
                model.Status = 500;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
            }

            return model;
        }

        public async Task<ApiModel> UpdateInnerLetterAsync(VMInnerLetrer.InnerLetrer vmAddInner
            //, List<IFormFile> peyvastFiles
            )
        {
            ApiModel model = new ApiModel();
            DateTime dateLetter;

            List<Peyvast> addedPeyvasts = null;
            List<string> savedPaths = null;
            List<int> peyvastsId = null;

            // عنوان نباید خالی باشد یا لیست گیرنده و لیست گروه گیرنده نباید جفتشون پر باشند و نباید جفتشون هم خالی باشند
            bool isGirandeEmpty = vmAddInner.Reciver_Girande == null || vmAddInner.Reciver_Girande.Count == 0;
            bool isGroupsGirandeEmpty = vmAddInner.Reciver_GroupsGirande == null || vmAddInner.Reciver_GroupsGirande.Count == 0;
            bool isErjaEmpty = vmAddInner.Reciver_Erja == null || vmAddInner.Reciver_Erja.Count == 0;
            bool isGroupsErjaEmpty = vmAddInner.Reciver_GroupsErja == null || vmAddInner.Reciver_GroupsErja.Count == 0;
            bool isHameshEmpty = vmAddInner.Reciver_Hamesh == null || vmAddInner.Reciver_Hamesh.Count == 0;
            bool isGroupsHameshEmpty = vmAddInner.Reciver_GroupsHamesh == null || vmAddInner.Reciver_GroupsHamesh.Count == 0;
            if (string.IsNullOrEmpty(vmAddInner.Title) || (isGirandeEmpty == isGroupsGirandeEmpty))
            {
                model.Data = null;
                model.Status = 400;
                model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
                return model;
            }
            else
            {
                using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    if (!isGirandeEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Girande.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت گیرنده معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsGirandeEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsGirande))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه گیرنده معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isErjaEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Erja.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsErjaEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsErja))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه ارجاع معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isHameshEmpty)
                    {
                        if (!await _sematService.CheckSematIdAsync(vmAddInner.Reciver_Hamesh.Select(c => c.sematId).ToList()))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی سمت هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!isGroupsHameshEmpty)
                    {
                        if (!await _groupService.CheckGroupIdAsync(vmAddInner.Reciver_GroupsHamesh))
                        {
                            model.Data = null;
                            model.Status = 0;
                            model.Message = "آیدی گروه هامش معتبر نیست";
                            model.Success = false;
                            return model;
                        }
                    }
                    if (!await _sematService.CheckSematIdAndUserIdAsync(vmAddInner.Sender_SematId, vmAddInner.Sender_UserId))
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "آیدی سمت فرستنده یا آیدی یوزر فرستنده معتبر نیست";
                        model.Success = false;
                        return model;
                    }

                    var letter = await GetDetailLetterAsync(vmAddInner.InnerId);

                    if (letter.Id == 0)
                    {
                        model.Data = null;
                        model.Status = 0;
                        model.Message = "آیدی نامه معتبر نیست";
                        model.Success = false;
                        return model;
                    }

                    letter.Title = vmAddInner.Title;
                    letter.Text = vmAddInner.Text;
                    letter.Mahramanegi = vmAddInner.Mahramanegi;
                    letter.Foriat = vmAddInner.Foriat;

                    dateLetter = letter.DateSabt;

                    peyvastsId = await _peyvastService.DeletePeyvastWithSourceIdAsync(letter.Id);
                    await _erjaService.DeleteErjaWithSourceIdAsync(letter.Id);

                    //if (peyvastFiles?.Any() == true)
                    //{
                    //    (addedPeyvasts, savedPaths) = _peyvastService.AddPeyvastLetter(
                    //        peyvastFiles,
                    //        "Peyvast",
                    //        vmAddInner.InnerId,
                    //        vmAddInner.Sender_SematId,
                    //        vmAddInner.Sender_UserId
                    //    );
                    //}

                    var mySource = await _sourceKeyIdService.GetSourceByIdAsync(letter.Id);

                    List<Erja> listErja = new List<Erja>();

                    if (!isGirandeEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Girande.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "G")));

                    }
                    if (!isErjaEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Erja.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "E")));

                    }
                    if (!isHameshEmpty)
                    {
                        listErja.AddRange(vmAddInner.Reciver_Hamesh.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "H")));

                    }
                    if (!isGroupsGirandeEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsGirande);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "G")));
                    }
                    if (!isGroupsErjaEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsErja);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "E")));

                    }
                    if (!isGroupsHameshEmpty)
                    {
                        var usersGroup = await _groupService.GetUserByGroupIdAsync(vmAddInner.Reciver_GroupsHamesh);

                        listErja.AddRange(usersGroup.Select(item =>
                                             CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, item.sematId, item.userId,
                                             dateLetter, "H")));
                    }

                    listErja.Add(CreateErja(mySource, vmAddInner.Sender_SematId,
                                             vmAddInner.Sender_UserId, vmAddInner.Sender_SematId, vmAddInner.Sender_UserId,
                                             dateLetter, "E"));

                    if (listErja.Any())
                        _erjaService.AddErja(listErja);

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();

                    List<SystemLog> logs = new List<SystemLog>();
                    logs.Add(new SystemLog()
                    {
                        SematId = vmAddInner.Sender_SematId,
                        UserId = vmAddInner.Sender_UserId,
                        LastDate = dateLetter,
                        FormId = vmAddInner.InnerId,
                        Action = 2,
                        IsDelete = false
                    });
                    if (peyvastsId != null && peyvastsId.Any())
                    {
                        logs.AddRange(peyvastsId.Select(item => new SystemLog()
                        {
                            SematId = vmAddInner.Sender_SematId,
                            UserId = vmAddInner.Sender_UserId,
                            LastDate = dateLetter,
                            FormId = item,
                            Action = 3,
                            IsDelete = false
                        }));
                    }
                    if (addedPeyvasts != null && addedPeyvasts.Any())
                    {
                        logs.AddRange(addedPeyvasts.Select(item => new SystemLog()
                        {
                            SematId = vmAddInner.Sender_SematId,
                            UserId = vmAddInner.Sender_UserId,
                            LastDate = dateLetter,
                            FormId = item.Peyvast_Id,
                            Action = 1,
                            IsDelete = false
                        }));
                    }

                    await _systemLogService.AddSystemLogAsync(logs);

                    //ویومدلی که کاربر پاس داده است
                    vmAddInner.Letter_Number = letter.Letter_Number;
                    vmAddInner.Number = letter.Number;
                    vmAddInner.Sender_SematId = letter.CreatorSematId;
                    vmAddInner.Sender_UserId = letter.CreatorUserId;
                    vmAddInner.Date = dateLetter;

                    model.Data = vmAddInner;
                    model.Status = 200;
                    model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                    return model;


                }
                catch (Exception e)
                {
                    await transaction.RollbackAsync();

                    // پاک‌سازی فایل‌ها در صورت خطا
                    if (savedPaths != null)
                    {
                        foreach (var path in savedPaths)
                        {
                            if (File.Exists(path))
                                File.Delete(path);
                        }
                    }

                    model.Data = null;
                    model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager2) == true
                        ? model.Message = messager2
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Status = 500;
                    model.Success = false;
                    return model;
                }
            }
        }

        public async Task<InnerLetter> GetDetailLetterAsync(int letterId)
        {
            var result = await _context.InnerLetter.FindAsync(letterId);
            if (result is not null)
            {
                return result;
            }
            return new InnerLetter();
        }
    }
}
