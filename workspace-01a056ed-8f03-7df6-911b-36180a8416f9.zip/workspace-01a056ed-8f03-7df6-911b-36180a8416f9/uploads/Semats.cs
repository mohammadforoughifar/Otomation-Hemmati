﻿
using DataLayerApp.Entites.Base.BaseEntitiesProvider;
using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using DataLayerApp.Entites.Provider;
using DataLayerApp.Entites.Yarco.ElamMoghayerat;
using DataLayerApp.Entities.Arshiv;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayerApp.Entites.Base
{
    public class Semats
    {

        public int SematId { get; set; }
        public int Parent { get; set; }
        public Guid UserId { get; set; }
        public string Title { get; set; }
        public string OnvanMokatebati { get; set; }

        public int OrganizationId { get; set; }
        public bool IsActive { get; set; }
        public bool IsDelete { get; set; }
        public bool DefaultSemat { get; set; }

        #region relation

        public User User { get; set; }
        [ForeignKey("OrganizationId")]
        public Organization Organizations { get; set; }
        public List<SematRole> SematRole { get; set; }
        public List<Level> Level { get; set; }
        public List<ActionPlan> ActionPlans { get; set; }
        public List<FirstAssessment> FirstAssessments { get; set; }
        public List<SematPermission> SematPermissions { get; set; }
        public List<RolePermission> RolePermissions { get; set; }
        public List<Adit> Adits { get; set; }
        public List<PayeshAmalkard> PayeshAmalkards { get; set; }
        public ICollection<Signature> signature { get; set; }
        public ICollection<SematGroups> SematGroups { get; set; }
        public ICollection<Groups> Groups { get; set; }
        public ICollection<Erja> ErjasSender { get; set; } = new List<Erja>();
        public ICollection<Erja> ErjasReciver { get; set; } = new List<Erja>();
        public ICollection<RelatedLetter> RelatedLetters { get; set; } = new List<RelatedLetter>();

        public ICollection<InnerLetter> InnerLetters { get; set; }
        public ICollection<Peyvast> Peyvasts { get; set; }
        public ICollection<PishnevisLetter> PishnevisLetter { get; set; }
        public ICollection<SystemLog> SystemLog { get; set; } = new List<SystemLog>();

        public List<ArshivVersion> ArshivVersions { get; set; }
        public ICollection<MoghayeratDocument> SematCreatorF { get; set; }
        public ICollection<MoghayeratDocument> SematCreatorSe { get; set; }
        public ICollection<MoghayeratDocument> SematCreatorSu { get; set; }
        public ICollection<MoghayeratDocument> SematCreatorSC { get; set; }
        public ICollection<MoghayeratDocument> SematCreatorSubmitter { get; set; }

        #endregion
    }
}
