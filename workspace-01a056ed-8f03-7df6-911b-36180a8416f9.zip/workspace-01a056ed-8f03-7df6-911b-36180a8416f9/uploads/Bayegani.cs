﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation
{
    public class Bayegani
    {
        public int Baygani_Id { get; set; }
        public string Title { get; set; }
        public int Erja_Id { get; set; }
        public int Parent_Id { get; set; }
        public Guid UserId { get; set; }
        public int Semat_Id { get; set; }
        public int TypeBayegani { get; set; }
        public bool Is_Folder { get; set; }
        public bool IsDelete { get; set; }
    }
}
