﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMBasic;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Base.BaseEntitiesProvider;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using static CoreApp.DTOs.ViewModel.VMBasic.VmChartOrganization;
using Permission = DataLayerApp.Entites.Base.BaseEntitiesProvider.Permission;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class PermissionService(DataContext context
    ) : IPermissionService
    {
        public async Task<ApiModel> AddPermissionRole(VmChartOrganization.AddPermission permission)
        {
            ApiModel model = new ApiModel();
            if (permission.value == "")
            {
                return new ApiModel();
            }
            else
            {
                try
                {
                    var role = new IdentityRole<Guid>()
                    {
                        Name =permission.value.ToString(),

                    };

                    context.Roles.Add(role);
                    context.SaveChanges();
                    if (permission.PermissionId.Any())
                    {
                        foreach (var id in permission.PermissionId)
                        {
                            var rolepermission = new RolePermission();
                            rolepermission.RoleId = role.Id;
                            rolepermission.PermissionId = id;
                            context.RolePermissions.Add(rolepermission);

                        }
                        context.SaveChanges();

                    }
                    model.Data = permission;
                    model.Status = 201;
                    model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                    return model;
                }
                catch (Exception e)
                {
                    model.Data = null;
                    model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Status = 500;
                    model.Success = false;

                    return model;

                }


            }
        }

        public async Task<ApiModel> GetPermissions()
        {
            ApiModel model = new ApiModel();
            try
            {
                model.Data = context.Permissions.Select(x => new VmChartOrganization.TreeNode()
                {
                    ParentId = x.Parent,
                    PermissionId = x.PermissionId,
                    Title = x.Title,
                    IsChecked = true
                }).ToList();
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;

                return model;
            }

       
        }

        public async Task<ApiModel> GetPermissionsSemat(int sematId)
        {
            ApiModel model = new ApiModel();
            try
            {
                model.Data = context.SematPermissions.Select(x => new VmChartOrganization.TreeNode()
                {
                   
                    PermissionId = x.PermissionId,
                  
                }).Distinct().ToList();
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;

                return model;
            }

         
        }

        public async Task<ApiModel> AddPermissionsSemat(AddPermission permission)
        {
            ApiModel _model = new ApiModel();
            if (permission.value == "")
            {
                return new ApiModel();
            }
            else
            {
                try
                {
                    var valueAsJsonElement = (JsonElement)permission.value;///تبدیل object به int
                    foreach (var item in permission.PermissionId)
                    {
                        var sematPermission = new SematPermission()
                        {
                            SematId = valueAsJsonElement.GetInt32(),
                            PermissionId = item,
                        };
                        context.SematPermissions.Add(sematPermission);
                    }
                    context.SaveChanges();

                    _model.Data = permission;
                    _model.Status = 201;
                    _model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                        ? _model.Message = messager
                        : _model.Message = "کد وضعیت نامعتبر است.";
                    _model.Success = true;
                    _model.SematId = (int)permission.value;
                    return _model;
                }
                catch (Exception e)
                {
                    _model.Data = null;
                    _model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                        ? _model.Message = messager
                        : _model.Message = "کد وضعیت نامعتبر است.";
                    _model.Status = 500;
                    _model.Success = false;

                    return _model;

                }


            }
        }
        public async Task<ApiModel> GetPermissionsBySematId(int sematid)
        {
            ApiModel model = new ApiModel();
            try
            {


                var listpermissinid = await context.SematRoles
           .Where(r => r.SematId == sematid)
           .SelectMany(rr => context.RolePermissions
               .Where(p => p.RoleId == rr.RoleId)
               .Select(p => p.PermissionId))
           .Union(
               context.SematPermissions
                   .Where(p => p.SematId == sematid)
                   .Select(p => p.PermissionId)
           )
           .ToListAsync(); // EF Core 7+؛ اگر نسخه شما پشتیبانی نمی‌کند از ToListAsync و سپس سازنده HashSet استفاده کنید
                HashSet<int> listpermissin = new HashSet<int>(listpermissinid);
                model.Data = listpermissin;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            catch
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
            }

            return model;


        }
    }
}
