﻿using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class PishnevisService(DataContext _dataContext) : IPishnevisNameService
{

    public async Task<ApiModel> AddPishNevisAsync(VMPishNavisName vMPeyvastName)
    {
        ApiModel model = new ApiModel();
        if (string.IsNullOrWhiteSpace(vMPeyvastName.Text) || string.IsNullOrWhiteSpace(vMPeyvastName.Title) || vMPeyvastName.SematId == 0 || vMPeyvastName.UserId == Guid.Empty)
        {

            model.Data = null;
            model.Status = 400;
            model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = false;
            return model;
        }
        else
        {
            try
            {
                var peyvast = new PishnevisLetter()
                {
                    Text = vMPeyvastName.Text,
                    Title = vMPeyvastName.Title,
                    SematId = vMPeyvastName.SematId,
                    UserId = vMPeyvastName.UserId,
                    IsDelete = false,
                    IsNeshan = false,
                };
                _dataContext.PishnevisLetters.Add(peyvast);
                await _dataContext.SaveChangesAsync();
                vMPeyvastName.Pishnevis_Id = peyvast.Pishnevis_Id;

                model.Data = vMPeyvastName;
                model.Status = 201;
                model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                return model;
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Status = 500;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;

                return model;
            }
        }
    }

    public async Task<ApiModel> GetAllAsync(GetResultQuery request)
    {
        ApiModel model = new ApiModel();
        try
        {
            var query = _dataContext.PishnevisLetters.AsQueryable();
            query = query.Where(x => x.SematId == request.SematId);
            if (!string.IsNullOrWhiteSpace(request.SearchTerm))
            {
                query = query.Where(x =>
                    x.Title.Contains(request.SearchTerm) ||
                    x.Text.Contains(request.SearchTerm));
            }
            if (!string.IsNullOrEmpty(request.FilterColumn) && !string.IsNullOrEmpty(request.FilterValue))
            {
                switch (request.FilterColumn.Trim().ToLower())
                {
                    case "title":
                        query = query.Where(c =>
                            c.Title.Trim().ToLower() == request.FilterValue.Trim().ToLower());
                        break;
                    case "text":
                        query = query.Where(c =>
                        c.Text.Trim().ToLower() == request.FilterValue.Trim().ToLower());
                        break;
                }
            }

            if (request.SortOrder?.ToLower() == "desc")
            {
                query = query.OrderByDescending(x => x.Pishnevis_Id);
            }
            else
            {
                query = query.OrderBy(x => x.Pishnevis_Id);
            }

            var result = query.Select(c => new VMPishNavisName()
            {
                Pishnevis_Id = c.Pishnevis_Id,
                Title = c.Title,
                SematId = c.SematId,
                Text = c.Text,
                UserId = c.UserId,
            });
            var data = await PagedList<VMPishNavisName>.CreateAsync(result, (int)request.Page, (int)request.PageSize);
            model.Data = data;
            model.Status = 200;
            model.Success = true;
            model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            return model;
        }
        catch (Exception exception)
        {
            model.Data = null;
            model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Status = 500;
            model.Success = false;
            return model;
        }

    }

    public async Task<ApiModel> EditPishNevisAsync(VMPishNavisName vMPeyvastName)
    {
        ApiModel model = new ApiModel();
        if (string.IsNullOrWhiteSpace(vMPeyvastName.Text) || string.IsNullOrWhiteSpace(vMPeyvastName.Title) || vMPeyvastName.SematId == 0 || vMPeyvastName.UserId == Guid.Empty)
        {

            model.Data = null;
            model.Status = 400;
            model.Message = MessageCode.StatusCode.TryGetValue(400, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = false;
            return model;
        }
        try
        {
            var result = await GetByIdPishNavis(vMPeyvastName.Pishnevis_Id);
            if (result.Pishnevis_Id == 0)
            {
                model.Data = null;
                model.Status = 0;
                model.Message = "این آیدی در جدول وجود ندارد";
                model.Success = false;
                return model;
            }
            result.Text = vMPeyvastName.Text;
            result.Title = vMPeyvastName.Title;
            result.SematId = vMPeyvastName.SematId;
            result.UserId = vMPeyvastName.UserId;
            await _dataContext.SaveChangesAsync();


            model.Data = vMPeyvastName;
            model.Status = 200;
            model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = true;
            return model;
        }
        catch (Exception e)
        {
            model.Data = null;
            model.Status = 500;
            model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                ? model.Message = messager
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = false;

            return model;
        }
    }


    public async Task<ApiModel> DeletePishNevisAsync(int id)
    {
        ApiModel model = new ApiModel();
        var result = await GetByIdPishNavis(id);
        if (result != null)
        {
            result.IsDelete = true;
            await _dataContext.SaveChangesAsync();
            VMPishNavisName vMPeyvastName = new VMPishNavisName()
            {
                Text = result.Text,
                Title = result.Title,
                SematId = result.SematId,
                UserId = result.UserId,


            };
            model.Data = vMPeyvastName;
            model.Status = 200;
            model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager2) == true
            ? model.Message = messager2
            : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = true;
        }
        else
        {
            model.Data = null;
            model.Status = 0;
            model.Message = "این آیدی در جدول وجود ندارد";
            model.Success = false;
        }

        return model;
    }


    public async Task<PishnevisLetter> GetByIdPishNavis(int id)
    {
        var res = await _dataContext.PishnevisLetters.FindAsync(id);
        if (res is not null)
        {
            return res;
        }
        return new PishnevisLetter();
    }

    public async Task<ApiModel> GetByIdPishNavisAsync(int id)
    {
        ApiModel model = new ApiModel();

        var result = await _dataContext.PishnevisLetters.FindAsync(id);
        if (result is not null)
        {
            var peyvast = new PishnevisLetter()
            {
                Pishnevis_Id = result.Pishnevis_Id,
                Text = result.Text,
                Title = result.Title,
                SematId = result.SematId,
                UserId = result.UserId,
                IsDelete = false,
                IsNeshan = result.IsNeshan,
            };

            model.Data = peyvast;
            model.Status = 200;
            model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                ? model.Message = messager : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = true;
        }
        else
        {
            model.Data = null;
            model.Status = 0;
            model.Message = "این آیدی در جدول وجود ندارد";
            model.Success = false;
        }

        return model;
    }
}
