﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMRelatedLetter
    {
        public int RelatedId { get; set; }
        public int Related { get; set; }
        public int LetterId { get; set; }
        public string Sender_Name { get; set; }
        public string Titel { get; set; }
        public DateTime DateInnerLetter { get; set; }
        public string Ltter_Number { get; set; }
        public List<int> RelateLetterIds { get; set; }
        public int SematId { get; set; }
        public Guid UserId { get; set; }
        public IEnumerable<Links> Links { get; set; }
    }
}
