﻿using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using DataLayerApp.Entites.TiketEntity.Ticket;
using DataLayerApp.Entites.Yarco.ElamMoghayerat;
using DataLayerApp.Entities.Arshiv;
using DataLayerApp.Entities.TiketEntity.Company;
using DataLayerApp.Entities.TiketEntity.Ticket;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;



namespace DataLayerApp.Entites.Base
{
    public class User : IdentityUser<Guid>
    {

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CodePersoneli { get; set; }
        public string CodeMeli { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }
        public DateTime RegistryDate { get; set; }
        public string UserPicture { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public DateTime BirthdayDate { get; set; }
        //public int CompanyId { get; set; }

        #region Relation
        public ICollection<RefreshToken> RefreshTokens { get; set; }

        public ICollection<Semats> Semats { get; set; }
        public ICollection<Signature> Signatures { get; set; }
        public ICollection<Groups> Groups { get; set; }
        public ICollection<Erja> ErjasSender { get; set; }
        public ICollection<Erja> ErjasReciver { get; set; }
        public ICollection<ErjaTiket> ErjaTikets { get; set; }
        public ICollection<ErjaTiket> ErjaTiketsPasokh { get; set; }
        public ICollection<InnerLetter> InnerLetters { get; set; }
        public ICollection<Peyvast> Peyvasts { get; set; }
        public ICollection<PishnevisLetter> PishnevisLetters { get; set; }
        //[ForeignKey("CompanyId")]
        //public Company Companies { get; set; }
        public ICollection<UserCompany> userCompanies { get; set; }
        public List<Tickets> Tickets { get; set; }
        public List<ArshivVersion> ArshivVersions { get; set; }

        public ICollection<MoghayeratDocument> UserFBazras { get; set; }
        public ICollection<MoghayeratDocument> UserSBazras { get; set; }
        public ICollection<MoghayeratDocument> UserSupervisor { get; set; }
        public ICollection<MoghayeratDocument> UserCreatorFBazras { get; set; }
        public ICollection<MoghayeratDocument> UserCreatorSBazras { get; set; }
        public ICollection<MoghayeratDocument> UserCreatorSupervisor { get; set; }
        public ICollection<MoghayeratDocument> UserCreatorSubmitter { get; set; }
        public ICollection<MoghayeratDocument> UserCreatorSC { get; set; }

        #endregion
    }
}
