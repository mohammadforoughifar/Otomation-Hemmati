﻿using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using DataLayerApp.Entites.Otomation.Letter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.IService.IserviceOtomation
{
    public interface IRelatedLetterService
    {
        Task<ApiModel> AddRelatedLetterAsync(VMRelatedLetter vmRelatedLetter);

        Task<ApiModel> EditRelatedLetterAsync(VMRelatedLetter vmRelatedLetter, int RelatedLetterId);
        Task<ApiModel> GetRelatedLetterByIdVMAsync(int relatedId);
        Task<RelatedLetter> GetRelatedLetterByIdAsync(int relatedId);
        Task<ApiModel> DeleteRelatedLetterByIdAsync(int SematId,int relatedId);
         Task<ApiModel> GetRelatedLettersAsync(
    int letterId,
    GetResultQuery request);
    }
}
