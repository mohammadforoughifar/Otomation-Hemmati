﻿using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation.Letter;

namespace DataLayerApp.Entites.Otomation
{
    public class SourceKeyID
    {
        public int Id { get; set; }
        public int SourceType { get; set; }
        public bool IsDelete { get; set; }


        #region Relation

        public InnerLetter InnerLetter { get; set; }
        public RelatedLetter RelatedLetter { get; set; }
        public ICollection<RelatedLetter> RelatedLetters { get; set; } = new List<RelatedLetter>(); // روابطی که نامه به عنوان نامه اصلی دارد
        public ICollection<RelatedLetter> RelatedToLetters { get; set; } = new List<RelatedLetter>(); // روابطی که نامه به عنوان نامه مرتبط است
        public ICollection<Erja> Erjas { get; set; } = new List<Erja>();
        public ICollection<Peyvast> Peyvasts { get; set; } = new List<Peyvast>();

        #endregion
    }
}
