﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser;
using CoreApp.DTOs.ViewModel.VMBasic;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;
using static CoreApp.DTOs.ViewModel.VMOtomations.VMPeyvast;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMInnerLetrer
    {
        public class InnerLetrer
        {
            public int InnerId { get; set; }
            public string? Letter_Number { get; set; }
            public int? Number { get; set; }
            public int Sender_SematId { get; set; }
            public Guid Sender_UserId { get; set; }
            public List<SematUserFullName>? Reciver_Girande { get; set; } = new List<SematUserFullName>();
            public List<SematUserFullName>? Reciver_Erja { get; set; } = new List<SematUserFullName>();
            public List<SematUserFullName>? Reciver_Hamesh { get; set; } = new List<SematUserFullName>();
            public List<int>? Reciver_GroupsGirande { get; set; } = new List<int>();
            public List<int>? Reciver_GroupsErja { get; set; } = new List<int>();
            public List<int>? Reciver_GroupsHamesh { get; set; } = new List<int>();
            public string Mahramanegi { get; set; } = "عادی";
            public string Foriat { get; set; } = "عادی";

            [Required(ErrorMessage = "عنوان نامه الزامی است")]
            public string? Title { get; set; }
            public string? Text { get; set; }
            public string? SenderName { get; set; }
            public DateTime Date { get; set; } = DateTime.Now;
            public List<UsersViewModel.UserAvatarVM>? UsersGirandeAvatar { get; set; } = new();
            public List<UsersViewModel.UserAvatarVM>? UsersSenderAvatar { get; set; } = new();
            public bool? IsRead { get; set; }
            public bool IsNeshan { get; set; }
            public List<FileDetail>? FileDetails { get; set; } = new List<FileDetail>();


            public IEnumerable<Links>? Links { get; set; }
        }
        public class AddInner
        {
            public int InnerId { get; set; } = 1;
            public string? Letter_Number { get; set; } = "k";
            public int? Number { get; set; } = 1;
            public int Creator { get; set; }
            public int ReciverId { get; set; }
            public int SenderId { get; set; }
            public Guid CraeteUserId { get; set; }
            [Required(ErrorMessage = "عنوان نامه الزامی است")]
            public string Title { get; set; }
            public string? Text { get; set; }
            public string? SenderName { get; set; }
            public DateTime? Date { get; set; } = DateTime.Now;
            public string Mahramanegi { get; set; } = "عادی";
            public string Foriat { get; set; } = "فوری";
            public List<FileDetail>? FileDetails { get; set; } = new List<FileDetail>();
            [MinLength(1, ErrorMessage = "حداقل یک گیرنده باید انتخاب شود")]
            public List<VMSettings.SematUserFullName> ReciversGirandegan { get; set; } =
                new List<VMSettings.SematUserFullName>();
            public List<VMSettings.SematUserFullName>? ReciversErja { get; set; } = new List<VMSettings.SematUserFullName>();

            public List<VMSettings.SematUserFullName>? ReciversHamesh { get; set; } =
                new List<VMSettings.SematUserFullName>();
            public List<int>? GroupsGirande { get; set; } = new List<int>();
            public List<int>? GroupsErja { get; set; } = new List<int>();
            public List<int>? GroupsHamesh { get; set; } = new List<int>();

        }
        public class viewInnerLetterList
        {
            public int LetterId { get; set; }
            public int? Erja_Id { get; set; }
            public string Letter_Number { get; set; }
            public string Title { get; set; }
            public string Sender { get; set; }
            public int? SenderSematId { get; set; }
            public string Reciver { get; set; }
            public DateTime Date_InnerLetter { get; set; }
            public string Mahramanegi { get; set; }
            public string Foriat { get; set; }
            public int? RelatedLetterId { get; set; }
            public int? RelatedId { get; set; }
            public int? Related { get; set; } ///عطف==2
                                              ///پیرو==1
            public int? TypeForm { get; set; }
            public bool IsNeshan { get; set; } = false;
            public bool IsTODO { get; set; } = false;
            public string IsAttach { get; set; } = "فاقدپیوست";
            public bool IsRead { get; set; } = false;
            public bool IsSelected { get; set; } = false;
        }
        public class TreeNodeBayegani
        {
            public int? Baygani_Id { get; set; }
            public string? Title { get; set; }
            public int? Erja_Id { get; set; }
            public int Parent_Id { get; set; }
            public Guid UserId { get; set; }
            public int Semat_Id { get; set; }
            public int TypeBayegani { get; set; }//نوع بایگانی در نامه  0=نامه داخلی  2=تیکت
            public int? TypeBayeganiTiket { get; set; }//نوع بایگانی در تیکت 1==ادمین   2==نماینده
            public bool Is_Folder { get; set; }
            // اینو اضافه کن برای کنترل باز/بسته بودن
            public bool Expanded { get; set; } = false;
            public Dictionary<int, string> ListErjaId { get; set; } = new Dictionary<int, string>();
            public List<TreeNodeBayegani> Children { get; set; } = new List<TreeNodeBayegani>();
        }
      
        public class ViewModelAnswerKartabl
        {
            public int ErjaId { get; set; }
            public int LetterId { get; set; }
            public int ReciverId { get; set; }
            public int SenderId { get; set; }
            public int UserIdReciver { get; set; }
            public string? Answer { get; set; }
            public int TypeForm { get; set; }
            public string FormName { get; set; }
            public DateTime DateTime { get; set; }
            public DateTime? deadlineAnswer { get; set; }
            public DateTime? DateAnswer { get; set; }

            public string? Title { get; set; }
            public string? LetterNumber { get; set; }
            public bool ShowForAll { get; set; }

            public string? ReciverFullName { get; set; }
            public string? FullSemat { get; set; }

            /// <summary>
            /// این پراپرتی فقط خواندنی و براساس TypeForm ساخته می‌شود
            /// </summary>
            public string TypeFormString =>
                TypeForm switch
                {
                    1 => "نامه داخلی",
                    2 => "نامه صادره",
                    3 => "نامه وارده",
                    _ => "نامشخص"
                };
        }
    }
}
