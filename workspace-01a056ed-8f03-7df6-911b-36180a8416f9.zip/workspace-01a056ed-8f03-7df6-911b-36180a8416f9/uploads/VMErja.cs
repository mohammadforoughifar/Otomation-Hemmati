﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser;
using CoreApp.DTOs.ViewModel.VMBasic;
using static CoreApp.DTOs.ViewModel.VMBasic.VMSettings;

namespace CoreApp.DTOs.ViewModel.VMOtomations
{
    public class VMErja
    {
        public int ErjaId { get; set; }
        public int SourceId { get; set; }
        public int Sender_SematId { get; set; }
        public int Reciver_SematId { get; set; }
        public Guid Sender_UserId { get; set; }
        public Guid Reciver_UserId { get; set; }
        public DateTime Date { get; set; }
        public string? Type { get; set; }
        //public int Type_Form { get; set; }
        public int Type_Taeed { get; set; }
        public string? Answer { get; set; }
        public bool IsRead { get; set; }
        public bool? Is_Bayegani { get; set; }
        public DateTime? Mohlat_Pasokh { get; set; }
        public string? Matn_Erja { get; set; }
        public int Amalgar_Id { get; set; }
        public string? Amalgar_Title { get; set; }
        public bool IsNeshan { get; set; }
        public bool ShowForAll { get; set; }
        public bool ShowMassage { get; set; }
        public DateTime? DateRead { get; set; }
        public DateTime? DateEmza { get; set; }
        public DateTime? DateAnswer { get; set; }
        public bool IsReadAnswer { get; set; }
        public bool ShowMassageAnswer { get; set; }
        public List<SematUserFullName>? Reciver_Erja { get; set; } = new List<SematUserFullName>();
        public List<SematUserFullName>? Reciver_Hamesh { get; set; } = new List<SematUserFullName>();
        public List<int>? Reciver_GroupsErja { get; set; } = new List<int>();
        public List<int>? Reciver_GroupsHamesh { get; set; } = new List<int>();
        public bool IsErja { get; set; }
        public bool IsHamesh { get; set; }
        public string? SenderName { get; set; }
        public string? ReciverName { get; set; }
        public List<UsersViewModel.UserAvatarVM>? UsersGirandeAvatar { get; set; } = new();
        public List<UsersViewModel.UserAvatarVM>? UsersSenderAvatar { get; set; } = new();
        public IEnumerable<Links>? Links { get; set; }

    }

    public class AnswerRequest
    {
        public string Answer { get; set; }
        public bool ShowForAll { get; set; }
        public int Type_Taeed { get; set; }
    }
    public class TreeNodeLetter
    {
        public DateTime? Mohlat_Pasokh { get; set; }
        public string? Matn_Erja { get; set; }
        public string? Amalgar_Title { get; set; }
        public int Type_Taeed { get; set; }
        public string? Answer { get; set; }
        public bool IsRead { get; set; }
        public bool? Is_Bayegani { get; set; }
        public DateTime? DateRead { get; set; }
        public DateTime? DateEmza { get; set; }
        public DateTime? DateAnswer { get; set; }
        public DateTime Date { get; set; }
        public string? Type { get; set; }
        public int LetterId { get; set; }
        public int ReciverId { get; set; }
        public int SenderId { get; set; }
        public string Reciver { get; set; }
        public string Sender { get; set; }
        public string FileNameReciver { get; set; }
        public string FileNameSender { get; set; }

        public List<TreeNodeLetter> Children { get; set; } = new List<TreeNodeLetter>();
    }
    public class AddErja
    {
        public int LetterId { get; set; }
        public bool IsMohlat { get; set; } = false;
        public int ErjaId { get; set; }
        public string Type { get; set; }
        public int Type_Form { get; set; }
        public int Creator { get; set; }
        public Guid CraeteUserId { get; set; }
        public string TextErja { get; set; }
        public int AmalgarId { get; set; }
        public DateTime? deadlineAnswer { get; set; }
        [MinLength(1, ErrorMessage = "حداقل یک گیرنده باید انتخاب شود")]
        public List<VMSettings.SematUserFullName> ReciversGirandegan { get; set; } =
            new List<VMSettings.SematUserFullName>();
    }
    public class VMAmalgar
    {
        public int Amalgar_Id { get; set; }
        public string Title { get; set; }
        public string Taeed_Emza { get; set; }
  
    }
}
