﻿using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.Service.ServiceBase;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Base.Settings;
using DataLayerApp.Entites.Otomation;
using DataLayerApp.Entites.Otomation.Letter;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using PaginationSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CoreApp.DTOs.Service.ServiceOtomation
{
    public class RelatedLetterService(DataContext _context,
        ISourceKeyIdService _sourceKeyIdService,
        ISematService _sematService,
        ISystemLogService _systemLogService,
         ISystemLogService systemLogService)
        : IRelatedLetterService
    {
        public async Task<ApiModel> AddRelatedLetterAsync(
    VMRelatedLetter vmRelatedLetter)
        {
            ApiModel model = new ApiModel();

            try
            {
                // 1. بررسی اطلاعات ورودی
                if (vmRelatedLetter == null)
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message = "اطلاعات ورودی نمی‌تواند خالی باشد.";
                    model.Success = false;
                    return model;
                }

                // 2. حداقل یک نامه باید انتخاب شده باشد
                if (vmRelatedLetter.RelateLetterIds == null ||
                    !vmRelatedLetter.RelateLetterIds.Any())
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message =
                        "حداقل یک نامه برای عطف یا پیرو باید انتخاب شود.";
                    model.Success = false;
                    return model;
                }

                // حذف نامه‌های تکراری از لیست
                vmRelatedLetter.RelateLetterIds =
                    vmRelatedLetter.RelateLetterIds
                        .Distinct()
                        .ToList();

                // 3. بررسی معتبر بودن SourceId نامه اصلی
                if (!await _sourceKeyIdService
                    .CheckSourceIdAsync(vmRelatedLetter.LetterId))
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message = "آیدی نامه اصلی معتبر نیست.";
                    model.Success = false;
                    return model;
                }

                // 4. بررسی معتبر بودن SourceId تمام نامه‌های مرتبط
                if (!await _sourceKeyIdService
                    .CheckListSourceIdAsync(vmRelatedLetter.RelateLetterIds))
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message = "آیدی یکی از نامه‌های مرتبط معتبر نیست.";
                    model.Success = false;
                    return model;
                }

                // 5. بررسی سمت و کاربر
                if (!await _sematService.CheckSematIdAndUserIdAsync(
                        vmRelatedLetter.SematId,
                        vmRelatedLetter.UserId))
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message =
                        "آیدی سمت یا آیدی یوزر معتبر نیست.";
                    model.Success = false;
                    return model;
                }

                // 6. جلوگیری از ارجاع نامه به خودش
                if (vmRelatedLetter.RelateLetterIds
                    .Contains(vmRelatedLetter.LetterId))
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message =
                        "نامه نمی‌تواند به خود ارجاع دهد.";
                    model.Success = false;
                    return model;
                }

                // 7. بررسی اینکه نامه اصلی قبلاً رابطه مخالف نداشته باشد
                // یک نامه نمی‌تواند همزمان هم عطف و هم پیرو باشد.
                var oppositeRelationExists =
                    await _context.RelatedLetter
                        .AnyAsync(x =>
                            x.LetterId == vmRelatedLetter.LetterId &&
                            !x.IsDelete &&
                            x.Related != vmRelatedLetter.Related);

                if (oppositeRelationExists)
                {
                    var relationName =
                        vmRelatedLetter.Related == 1
                            ? "پیرو"
                            : "عطف";

                    model.Data = null;
                    model.Status = 400;
                    model.Message =
                        $"این نامه قبلاً دارای رابطه مخالف است و نمی‌تواند به صورت {relationName} ثبت شود.";
                    model.Success = false;
                    return model;
                }

                // 8. پیدا کردن روابطی که قبلاً ثبت شده‌اند
                var existingRelations =
                    await _context.RelatedLetter
                        .Where(x =>
                            x.LetterId == vmRelatedLetter.LetterId &&
                            vmRelatedLetter.RelateLetterIds
                                .Contains(x.RelateLetterId) &&
                            x.Related == vmRelatedLetter.Related &&
                            !x.IsDelete)
                        .Select(x => x.RelateLetterId)
                        .ToListAsync();

                // 9. حذف روابط تکراری
                var newRelateIds =
                    vmRelatedLetter.RelateLetterIds
                        .Except(existingRelations)
                        .ToList();

                if (!newRelateIds.Any())
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Message =
                        "همه نامه‌های انتخاب‌شده قبلاً به این نامه متصل شده‌اند.";
                    model.Success = false;
                    return model;
                }

                // 10. ایجاد Source جدید
                SourceKeyID newSource = new SourceKeyID
                {
                    SourceType = 9,
                    IsDelete = false
                };

                _sourceKeyIdService.AddSource(newSource);

                // 11. ایجاد روابط جدید
                var listRelatedLetter =
                    newRelateIds
                        .Select(item => new RelatedLetter
                        {
                            Source = newSource,
                            Related = vmRelatedLetter.Related,
                            LetterId = vmRelatedLetter.LetterId,
                            RelateLetterId = item,
                            SematId = vmRelatedLetter.SematId,
                            UserId = vmRelatedLetter.UserId,
                            IsDelete = false
                        })
                        .ToList();

                _context.RelatedLetter.AddRange(listRelatedLetter);

                // 12. ذخیره روابط
                await _context.SaveChangesAsync();

                // 13. دریافت اطلاعات نامه‌های مرتبط
                var innerLetterIds = listRelatedLetter
                    .Select(x => x.RelateLetterId)
                    .ToList();

                var innerLetters =
                    await _context.InnerLetter
                        .Where(x =>
                            innerLetterIds.Contains(x.Id) &&
                            !x.IsDelete)
                        .Include(x => x.User)
                        .Include(x => x.Semat)
                        .ToListAsync();

                // 14. ساخت خروجی
                var data = listRelatedLetter
                    .Select(c =>
                    {
                        var innerLetter =
                            innerLetters.FirstOrDefault(
                                x => x.Id == c.RelateLetterId);

                        return new VMRelatedLetter
                        {
                            RelatedId = c.Id,
                            Related = c.Related,
                            LetterId = c.LetterId,

                            RelateLetterIds = new List<int>
                            {
                        c.RelateLetterId
                            },

                            SematId = c.SematId,
                            UserId = c.UserId,

                            Sender_Name =
                                innerLetter == null
                                    ? null
                                    : string.IsNullOrWhiteSpace(
                                        innerLetter.Semat?.Title)
                                        ? $"{innerLetter.User?.FirstName} {innerLetter.User?.LastName}"
                                        : $"{innerLetter.User?.FirstName} {innerLetter.User?.LastName} - {innerLetter.Semat.Title}",

                            Titel = innerLetter?.Title,

                            DateInnerLetter =
                                innerLetter?.DateSabt
                                ?? DateTime.MinValue,

                            Ltter_Number =
                                innerLetter?.Letter_Number
                        };
                    })
                    .ToList();

                // 15. ثبت لاگ برای عملیات
                var logs = listRelatedLetter
                    .Select(x => new SystemLog
                    {
                        SematId = vmRelatedLetter.SematId,
                        UserId = vmRelatedLetter.UserId,
                        LastDate = DateTime.Now,
                        FormId = vmRelatedLetter.LetterId,
                        FormType = 9,

                        // مقدار Action را مطابق سیستم خودت تنظیم کن
                        Action = 1,

                        Number = null,
                        IsDelete = false
                    })
                    .ToList();

                await systemLogService.AddSystemLogAsync(logs);

                model.Data = data;
                model.Status = 200;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        200,
                        out string messager)
                        ? messager
                        : "عملیات با موفقیت انجام شد.";

                model.Success = true;

                return model;
            }
            catch (Exception)
            {
                model.Data = null;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        500,
                        out string messager)
                        ? messager
                        : "خطایی در انجام عملیات رخ داد.";

                model.Status = 500;
                model.Success = false;

                return model;
            }
        }

        public async Task<ApiModel> DeleteRelatedLetterByIdAsync(int sematId, int relatedId)
        {
            var model = new ApiModel();

            try
            {
                var relatedLetter = await GetRelatedLetterByIdAsync(relatedId);

                if (relatedLetter.Id == 0)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "این آیدی در جدول وجود ندارد";
                    model.Success = false;
                    return model;
                }

                if (relatedLetter.SematId != sematId)
                {
                    model.Data = null;
                    model.Status = 0;
                    model.Message = "شما مجاز به حذف این نامه مرتبط نیستید فقط سازنده آن مجاز به حذف است";
                    model.Success = false;
                    return model;
                }

                relatedLetter.IsDelete = true;

                var log = new SystemLog();
                log.SematId = sematId;
                log.UserId = relatedLetter.UserId;
                log.LastDate = DateTime.Now;
                log.FormId = relatedId;
                log.Action = 3;
                log.IsDelete = false;

                await _systemLogService.AddSystemLogAsync(log);

                var vmRelatedLetter = new VMRelatedLetter();

                vmRelatedLetter.RelatedId = relatedLetter.Id;
                vmRelatedLetter.Related = relatedLetter.Related;
                vmRelatedLetter.LetterId = relatedLetter.LetterId;
                vmRelatedLetter.RelateLetterIds = new List<int> { relatedLetter.RelateLetterId };
                vmRelatedLetter.SematId = relatedLetter.SematId;
                vmRelatedLetter.UserId = relatedLetter.UserId;


                model.Data = vmRelatedLetter;
                model.Status = 200;
                model.Success = true;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                return model;

            }
            catch (Exception exception)
            {
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                return model;
            }
        }

        public async Task<ApiModel> EditRelatedLetterAsync(
    VMRelatedLetter vmRelatedLetter,
    int relatedLetterId)
        {
            var model = new ApiModel();

            try
            {
                // 1. بررسی شناسه رابطه
                if (relatedLetterId <= 0)
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message = "شناسه رابطه معتبر نیست.";
                    model.Data = null;
                    return model;
                }

                // 2. بررسی اطلاعات ورودی
                if (vmRelatedLetter == null)
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "اطلاعات ورودی نمی‌تواند خالی باشد.";
                    model.Data = null;
                    return model;
                }

                // 3. در Edit فقط یک نامه مجاز است
                if (vmRelatedLetter.RelateLetterIds == null ||
                    vmRelatedLetter.RelateLetterIds.Count != 1)
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "برای ویرایش فقط یک نامه باید انتخاب شود.";
                    model.Data = null;
                    return model;
                }

                // شناسه نامه مرتبط
                var relateLetterId =
                    vmRelatedLetter.RelateLetterIds.First();

                // 4. دریافت رابطه موجود
                var relatedLetter =
                    await _context.RelatedLetter
                        .FirstOrDefaultAsync(x =>
                            x.Id == relatedLetterId &&
                            !x.IsDelete);

                if (relatedLetter == null)
                {
                    model.Status = 404;
                    model.Success = false;
                    model.Message =
                        "رابطه‌ای جهت ویرایش یافت نشد.";
                    model.Data = null;
                    return model;
                }

                // 5. بررسی SourceId نامه اصلی
                if (!await _sourceKeyIdService
                    .CheckSourceIdAsync(vmRelatedLetter.LetterId))
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "آیدی نامه اصلی معتبر نیست.";
                    model.Data = null;
                    return model;
                }

                // 6. بررسی SourceId نامه مرتبط
                if (!await _sourceKeyIdService
                    .CheckSourceIdAsync(relateLetterId))
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "آیدی نامه مرتبط معتبر نیست.";
                    model.Data = null;
                    return model;
                }

                // 7. بررسی سمت و کاربر
                if (!await _sematService.CheckSematIdAndUserIdAsync(
                        vmRelatedLetter.SematId,
                        vmRelatedLetter.UserId))
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "آیدی سمت یا آیدی یوزر معتبر نیست.";
                    model.Data = null;
                    return model;
                }

                // 8. جلوگیری از ارجاع نامه به خودش
                if (vmRelatedLetter.LetterId == relateLetterId)
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "نامه نمی‌تواند به خود ارجاع دهد.";
                    model.Data = null;
                    return model;
                }

                // 9. بررسی رابطه مخالف
                // یک نامه نمی‌تواند همزمان عطف و پیرو باشد.
                var oppositeRelationExists =
                    await _context.RelatedLetter
                        .AnyAsync(x =>
                            x.LetterId == vmRelatedLetter.LetterId &&
                            !x.IsDelete &&
                            x.Id != relatedLetterId &&
                            x.Related != vmRelatedLetter.Related);

                if (oppositeRelationExists)
                {
                    var relationName =
                        vmRelatedLetter.Related == 1
                            ? "پیرو"
                            : "عطف";

                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        $"این نامه دارای رابطه مخالف است و نمی‌تواند به صورت {relationName} ثبت شود.";
                    model.Data = null;
                    return model;
                }

                // 10. جلوگیری از رابطه تکراری
                var duplicateRelation =
                    await _context.RelatedLetter
                        .AnyAsync(x =>
                            x.Id != relatedLetterId &&
                            !x.IsDelete &&
                            x.LetterId == vmRelatedLetter.LetterId &&
                            x.RelateLetterId == relateLetterId &&
                            x.Related == vmRelatedLetter.Related);

                if (duplicateRelation)
                {
                    model.Status = 400;
                    model.Success = false;
                    model.Message =
                        "این رابطه عطف یا پیرو قبلاً ثبت شده است.";
                    model.Data = null;
                    return model;
                }

                // 11. بروزرسانی رابطه
                relatedLetter.LetterId =
                    vmRelatedLetter.LetterId;

                relatedLetter.RelateLetterId =
                    relateLetterId;

                relatedLetter.Related =
                    vmRelatedLetter.Related;

                relatedLetter.SematId =
                    vmRelatedLetter.SematId;

                relatedLetter.UserId =
                    vmRelatedLetter.UserId;

                // 12. ذخیره تغییرات
                await _context.SaveChangesAsync();

                // 13. دریافت اطلاعات نامه مرتبط
                var innerLetter =
                    await _context.InnerLetter
                        .Where(x =>
                            x.Id == relateLetterId &&
                            !x.IsDelete)
                        .Include(x => x.User)
                        .Include(x => x.Semat)
                        .FirstOrDefaultAsync();

                if (innerLetter == null)
                {
                    model.Status = 404;
                    model.Success = false;
                    model.Message =
                        "اطلاعات نامه مرتبط یافت نشد.";
                    model.Data = null;
                    return model;
                }

                // 14. ساخت خروجی
                var data = new VMRelatedLetter
                {
                    RelatedId = relatedLetter.Id,
                    Related = relatedLetter.Related,
                    LetterId = relatedLetter.LetterId,

                    RelateLetterIds = new List<int>
            {
                relatedLetter.RelateLetterId
            },

                    SematId = relatedLetter.SematId,
                    UserId = relatedLetter.UserId,

                    Sender_Name =
                        string.IsNullOrWhiteSpace(
                            innerLetter.Semat?.Title)
                            ? $"{innerLetter.User?.FirstName} {innerLetter.User?.LastName}"
                            : $"{innerLetter.User?.FirstName} {innerLetter.User?.LastName} - {innerLetter.Semat.Title}",

                    Titel = innerLetter.Title,

                    DateInnerLetter = innerLetter.DateSabt,

                    Ltter_Number = innerLetter.Letter_Number
                };

                // 15. ثبت لاگ ویرایش
                var log = new SystemLog
                {
                    SematId = vmRelatedLetter.SematId,
                    UserId = vmRelatedLetter.UserId,
                    LastDate = DateTime.Now,
                    FormId = vmRelatedLetter.LetterId,
                    FormType = 9,

                    // مقدار Action ویرایش
                    Action = 2,

                    Number = null,
                    IsDelete = false
                };

                await systemLogService.AddSystemLogAsync(log);

                model.Data = data;
                model.Status = 200;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        200,
                        out string messager)
                        ? messager
                        : "اطلاعات با موفقیت ویرایش شد.";

                model.Success = true;

                return model;
            }
            catch (Exception)
            {
                model.Data = null;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        500,
                        out string messager)
                        ? messager
                        : "خطایی در انجام عملیات رخ داد.";

                model.Status = 500;
                model.Success = false;

                return model;
            }
        }
        public async Task<RelatedLetter> GetRelatedLetterByIdAsync(int relatedId)
        {
            var data = await _context.RelatedLetter
                .Where(e => e.Id == relatedId)
                .FirstOrDefaultAsync();

            if (data != null)
            {
                return data;
            }

            return new RelatedLetter();
        }

        public async Task<ApiModel> GetRelatedLetterByIdVMAsync(int relatedId)
        {
            var model = new ApiModel();

            var data = await _context.RelatedLetter
                .Where(e => e.Id == relatedId)
                .Select(e => new VMRelatedLetter
                {
                    RelatedId = e.Id,
                    Related = e.Related,
                    LetterId = e.LetterId,
                    RelateLetterIds = new List<int> { e.RelateLetterId },
                    SematId = e.SematId,
                    UserId = e.UserId
                })
                .FirstOrDefaultAsync();

            if (data != null)
            {
                model.Data = data;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
            }
            else
            {
                model.Data = null;
                model.Status = 0;
                model.Message = "این آیدی در جدول وجود ندارد";
                model.Success = false;
            }

            return model;
        }

        public async Task<ApiModel> GetRelatedLettersAsync(
    int letterId,
    GetResultQuery request)
        {
            var model = new ApiModel();

            try
            {
                // 1. بررسی شناسه نامه
                if (letterId <= 0)
                {
                    model.Data = null;
                    model.Status = 400;
                    model.Success = false;
                    model.Message = "شناسه نامه معتبر نیست.";
                    return model;
                }

                // 2. بررسی وجود نامه اصلی
                if (!await _sourceKeyIdService.CheckSourceIdAsync(letterId))
                {
                    model.Data = null;
                    model.Status = 404;
                    model.Success = false;
                    model.Message = "نامه مورد نظر یافت نشد.";
                    return model;
                }

                // 3. دریافت نامه‌های عطف شده و اتصال به اطلاعات نامه
                var query =
                    from related in _context.RelatedLetter.AsNoTracking()

                    join innerLetter in _context.InnerLetter
                        on related.RelateLetterId equals innerLetter.Id

                    join semat in _context.Semats
                        on innerLetter.CreatorSematId equals semat.SematId

                    join user in _context.Users
                        on innerLetter.CreatorUserId equals user.Id

                    where related.LetterId == letterId
                          && related.Related == 1   // 1 = عطف
                          && !related.IsDelete
                          && !innerLetter.IsDelete

                    select new VMRelatedLetter
                    {
                        RelatedId = related.Id,


                        // شناسه نامه اصلی
                        LetterId = related.LetterId,

                        // نوع رابطه
                        Related = related.Related,

                        // فرستنده نامه
                        Sender_Name =
                            semat.Title + " " +
                            user.FirstName + " " +
                            user.LastName,

                        // عنوان نامه
                        Titel = innerLetter.Title,

                        // شماره نامه
                        Ltter_Number = innerLetter.Letter_Number,

                        // تاریخ ثبت نامه
                        DateInnerLetter = innerLetter.DateSabt
                    };

                // 4. جستجو
                if (!string.IsNullOrWhiteSpace(request.SearchTerm))
                {
                    var searchTerm = request.SearchTerm.Trim();

                    query = query.Where(x =>
                        x.Titel.Contains(searchTerm) ||
                        x.Ltter_Number.Contains(searchTerm) ||
                        x.Sender_Name.Contains(searchTerm));
                }

                // 5. مرتب‌سازی
                if (!string.IsNullOrWhiteSpace(request.SortColumn))
                {
                    if (request.SortOrder?.ToLower() == "desc")
                    {
                        query = request.SortColumn.ToLower() switch
                        {
                            "title" =>
                                query.OrderByDescending(x => x.Titel),

                            "letter_number" =>
                                query.OrderByDescending(x => x.Ltter_Number),

                            "date" =>
                                query.OrderByDescending(
                                    x => x.DateInnerLetter),

                            "sender" =>
                                query.OrderByDescending(x => x.Sender_Name),

                            _ =>
                                query.OrderByDescending(x => x.RelatedId)
                        };
                    }
                    else
                    {
                        query = request.SortColumn.ToLower() switch
                        {
                            "title" =>
                                query.OrderBy(x => x.Titel),

                            "letter_number" =>
                                query.OrderBy(x => x.Ltter_Number),

                            "date" =>
                                query.OrderBy(x => x.DateInnerLetter),

                            "sender" =>
                                query.OrderBy(x => x.Sender_Name),

                            _ =>
                                query.OrderBy(x => x.RelatedId)
                        };
                    }
                }
                else
                {
                    // مرتب‌سازی پیش‌فرض
                    query = query.OrderBy(x => x.RelatedId);
                }

                // 6. صفحه‌بندی
                int page = request.Page ?? 1;
                int pageSize = request.PageSize ?? 10;

                var data =
                    await PagedList<VMRelatedLetter>
                        .CreateAsync(query, page, pageSize);

                // 7. خروجی
                model.Data = data;
                model.Status = 200;
                model.Success = true;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        200,
                        out string messager)
                        ? messager
                        : "نامه‌های عطف شده با موفقیت دریافت شدند.";

                return model;
            }
            catch (Exception)
            {
                model.Data = null;
                model.Status = 500;
                model.Success = false;

                model.Message =
                    MessageCode.StatusCode.TryGetValue(
                        500,
                        out string messager)
                        ? messager
                        : "خطایی در دریافت نامه‌های عطف شده رخ داد.";

                return model;
            }
        }
    }
}
