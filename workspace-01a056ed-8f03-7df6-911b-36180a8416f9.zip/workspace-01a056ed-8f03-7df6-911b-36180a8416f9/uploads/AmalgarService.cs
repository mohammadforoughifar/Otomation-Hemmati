﻿using CoreApp.DTOs.IService.IServiceBase;
using DataLayerApp.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class AmalgarService(DataContext _context) : IAmalgarService
    {
        public async Task<bool> CheckAmalgarIdAsync(int amalgarId)
        {
            return await _context.Amalgar.AnyAsync(c=>c.Amalgar_Id == amalgarId);
        }
    }
}
