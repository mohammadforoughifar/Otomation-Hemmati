﻿using DataLayerApp.Entites.Base;
using DataLayerApp.Entites.Base.Settings;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Otomation
{
    public class Erja
    {
        public int ErjaId { get; set; }
        public int SourceId { get; set; }
        public int Sender_SematId { get; set; }
        public int Reciver_SematId { get; set; }
        public Guid Sender_UserId { get; set; }
        public Guid Reciver_UserId { get; set; }
        public DateTime Date { get; set; }
        public string Type { get; set; }
        //public int Type_Form { get; set; }
        public int Type_Taeed { get; set; }
        public string Answer { get; set; }
        public bool IsRead { get; set; }
        public bool? Is_Bayegani { get; set; }
        public DateTime? Mohlat_Pasokh { get; set; }
        public string Matn_Erja { get; set; }
        public int Amalgar_Id { get; set; }
        public bool IsNeshan { get; set; }
        public bool ShowForAll { get; set; }
        public bool ShowMassage { get; set; }
        public DateTime? DateRead { get; set; }
        public DateTime? DateEmza { get; set; }
        public DateTime? DateAnswer { get; set; }
        public bool IsReadAnswer { get; set; }
        public bool ShowMassageAnswer { get; set; }
        public bool IsDelete { get; set; }

        #region Relations

        [ForeignKey(nameof(SourceId))]
        public SourceKeyID Source { get; set; }

        [ForeignKey(nameof(Amalgar_Id))]
        public Amalgar Amalgar { get; set; }

        // روابط جداگانه برای Sender و Receiver
        [ForeignKey(nameof(Sender_SematId))]
        public Semats SematSender { get; set; }

        [ForeignKey(nameof(Reciver_SematId))]
        public Semats SematReceiver { get; set; }

        [ForeignKey(nameof(Sender_UserId))]
        public User UserSender { get; set; }

        [ForeignKey(nameof(Reciver_UserId))]
        public User UserReciver { get; set; }

        #endregion
    }
}
