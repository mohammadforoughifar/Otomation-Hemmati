﻿using PaginationSample.Models;

namespace CoreApp.DTOs.ViewModel
{
    public class ApiModel
    {
        public Guid? UserId { get; set; }
        public int SematId { get; set; }= 0;
        public bool Success { get; set; }

        public int Status { get; set; }

        public string Message { get; set; }
  
        public object Data { get; set; }

        public int TotalCount { get; set; } = 0;
        public IEnumerable<Links> Links { get; set; }
    }
    public class Links
    {
        public string? Href { get; set; }
        public string Rel { get; set; }
        public string Method { get; set; }
    }
 
}
