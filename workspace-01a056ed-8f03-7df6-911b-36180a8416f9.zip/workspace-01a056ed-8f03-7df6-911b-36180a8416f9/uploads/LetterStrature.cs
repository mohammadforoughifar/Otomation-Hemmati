using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerApp.Entites.Base.Settings
{
    public class LetterStrature
    {
        public int StratureId { get; set; }
        public int TypeForm { get; set; }
        public string TypeStrature { get; set; }
    }


}
