﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using CoreApp.DTOs.IService.IServiceBase;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMBasic;
using CoreApp.Helps.Responses;
using CoreApp.Helps.StatusCode;
using DataLayerApp.Context;
using DataLayerApp.Entites.Base;
using Microsoft.EntityFrameworkCore;
using PaginationSample.Models;
using static CoreApp.DTOs.ViewModel.VMBasic.VmSemats;
using static CoreApp.DTOs.ViewModel.ViewModelBasic.VMUser.UsersViewModel;

namespace CoreApp.DTOs.Service.ServiceBase
{
    public class OrganizationService(DataContext context
    ) : IOrganizationServices
    {
        public async Task<ApiModel> GetOrganizationTuple(GetResultQuery request)
        {
            int totalOrganization = context.Organizations.Where(c=>!c.IsDelete).Count();

            try
            {
                var organizations = context.Organizations.Where(x=>!x.IsDelete)
        
                    .Select(s => new VmOrganization()
                    {
                        OrganizationId = s.OrganizationId,
                        NameUnit = s.NameUnit, // or s.UserId if it's a property of Semats
                        NameUniq = s.NameUniq
   
                    });
                // فیلتر کردن بر اساس جستجو  
                if (!string.IsNullOrEmpty(request.SearchTerm))
                {
                    organizations = organizations.Where(ca => ca.NameUnit.Trim().Contains(request.SearchTerm) || ca.NameUniq.Contains(request.SearchTerm));
                    //users = users.Where(ca => ca.CodePersoneli.Contains(request.SearchTerm));
                }
                if (!string.IsNullOrEmpty(request.SortColumn))
                {
                    organizations = organizations.Where(ca => ca.NameUniq == request.SortColumn);
                }
                if (request.SortOrder?.ToLower() == "desc")
                    organizations = organizations.OrderByDescending(GetSortProperty(request));
                else
                    organizations = organizations.OrderBy(GetSortProperty(request));
                var result = await PagedList<VmOrganization>.CreateAsync(organizations, (int)request.Page, (int)request.PageSize);
                ApiModel model = new ApiModel();
                model.Data = result;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.TotalCount = totalOrganization;
                return model;
            }
            catch (Exception exception)
            {
                ApiModel model = new ApiModel();
                model.Data = null;
                model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Status = 500;
                model.Success = false;
                model.TotalCount = 0;
                return model;
            }
        }

        public async Task<ApiModel> AddOrganization(VmOrganization Organization)
        {
            ApiModel model = new ApiModel();
            if (Organization.NameUniq == "" || Organization.NameUnit == "")
            {
                return new ApiModel();
            }
            else
            {
                try
                {
                    var organization = new Organization()
                    {
                        NameUniq = Organization.NameUniq,
                        NameUnit = Organization.NameUnit,
                        IsDelete = false,
                   
                    };
                    context.Organizations.Add(organization);
                    await context.SaveChangesAsync();

                    model.Data = organization;
                    model.Status = 201;
                    model.Message = MessageCode.StatusCode.TryGetValue(201, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                
                    model.SematId = organization.OrganizationId;
                    return model;
                }
                catch (Exception e)
                {
                    model.Data = null;
                    model.Message = MessageCode.StatusCode.TryGetValue(500, out string messager) == true
                        ? model.Message = messager
                        : model.Message = "کد وضعیت نامعتبر است.";
                    model.Status = 500;
                    model.Success = false;

                    return model;

                }


            }
        }

        public async Task<ApiModel> DeleteOrganization(int OrganizationId)
        {
            ApiModel model = new ApiModel();
            var get = context.Organizations.Find(OrganizationId);
            var result = context.Semats.Any(x=>x.OrganizationId==get.OrganizationId);
            if (result)
            {
                model.Data = null;
                model.Status = 409;
                model.Message = MessageCode.StatusCode.TryGetValue(409, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = false;
                model.SematId = 0;
                return model;
            }
            get.IsDelete=true;
            context.SaveChanges();
            model.Data = get;
            model.Status = 200;
            model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager2) == true
                ? model.Message = messager2
                : model.Message = "کد وضعیت نامعتبر است.";
            model.Success = true;
            model.SematId = get.OrganizationId;
            return model;
        }

        public async Task<ApiModel> UpdateOrganization(VmOrganization Organization)
        {
            ApiModel model = new ApiModel();
            if (Organization.NameUniq is "" || Organization.NameUnit is "")
            {
                return new ApiModel();
            }

            try
            {
                var get = context.Organizations.Find(Organization.OrganizationId);
                get.NameUniq = Organization.NameUniq;
                get.NameUnit = Organization.NameUnit;
                context.SaveChanges();
                model.Data = get;
                model.Status = 200;
                model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = get.OrganizationId;
               
            }
            catch (Exception e)
            {
                model.Data = null;
                model.Status = 204;
                model.Message = MessageCode.StatusCode.TryGetValue(204, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = 0;
            }
           return model;
        }

        public async Task<ApiModel> GetOrganizationById(int OrganizationId)
        { ApiModel model=  new ApiModel();
            var get= context.Organizations.Find(OrganizationId);
            if (get is not null)
            {
                
              model.Data = get;
              model.Status = 200;
              model.Message = MessageCode.StatusCode.TryGetValue(200, out string messager) == true
                  ? model.Message = messager
                  : model.Message = "کد وضعیت نامعتبر است.";
                    model.Success = true;
                    model.SematId = get.OrganizationId;
            }
            else
            {
                model.Data = null;
                model.Status = 204;
                model.Message = MessageCode.StatusCode.TryGetValue(204, out string messager) == true
                    ? model.Message = messager
                    : model.Message = "کد وضعیت نامعتبر است.";
                model.Success = true;
                model.SematId = get.OrganizationId;
            }

            return model;
        }

        public async Task<List<VmOrganization>> GetOrganizationsName()
        {
            var result = context.Organizations.Where(c => !c.IsDelete).Select(x => new VmOrganization()
            {
                OrganizationId = x.OrganizationId,
                NameUnit = x.NameUnit
            }).ToList();
            return result;
        }

        public async Task<string> GetOrganizationName(int SematId)
        {
            var semat= context.Semats.FirstOrDefault(c=>c.SematId== SematId).OrganizationId;
            return  context.Organizations.Find(semat).NameUnit;
        }

        private Expression<Func<VmOrganization, object>> GetSortProperty(GetResultQuery request)
            => request.SortColumn?.ToLower() switch
            {
                "Name" => Student => Student.NameUnit,
                "NameQuiq" => Student => Student.NameUniq,
             

                _ => Student => Student.OrganizationId,
            };
        public async Task<string> GetOrganizationNameUniqAsync(int sematId)
        {
            var nameUniq = await context.Semats
                        .Where(s => s.SematId == sematId)
                        .Select(s => s.Organizations.NameUniq)
                        .FirstOrDefaultAsync();

            return nameUniq ?? string.Empty;
        }
    }

}
