﻿using CoreApp.DTOs.IService.IserviceOtomation;
using CoreApp.DTOs.Service.ServiceOtomation;
using CoreApp.DTOs.ViewModel;
using CoreApp.DTOs.ViewModel.VMOtomations;
using CoreApp.Helps.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaginationSample.Models;

namespace WebAppApi.Controllers.ControllerV1.OtoController
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class RelatedLetterController(IRelatedLetterService _relatedLetterService) : ControllerBase
    {
        [HttpGet("{id:int}")]
        public async Task<ApiModel> GetById(int id)
        {
            return await _relatedLetterService.GetRelatedLetterByIdVMAsync(id);
        }

        [HttpGet("{id:int}")]
        public async Task<IResult> Get(int id, [FromQuery] GetResultQuery request)
        {
            var model = await _relatedLetterService.GetRelatedLettersAsync(
                id, 
                request );


            if (model.Success &&
                model.Data is PagedList<VMRelatedLetter> result)
            {
                foreach (var item in result.Items)
                {
                    item.Links = new List<Links>
                    {
                        new Links
                        {
                            Href = Url.Action(
                                nameof(GetById),
                                ControllerContext.ActionDescriptor.ControllerName,
                                new
                                {
                                    version = "1",
                                    id = item.RelatedId
                                },
                                Request.Scheme),
                            Rel = "Self",
                            Method = "GET"
                        },

                        new Links
                        {
                            Href = Url.Action(
                                nameof(DeleteRelatedLetter),
                                ControllerContext.ActionDescriptor.ControllerName,
                                new
                                {
                                    version = "1",
                                    id = item.RelatedId
                                },
                                Request.Scheme),
                            Rel = "Delete",
                            Method = "DELETE"
                        }
                    };
                }
            }

            return Results.Ok(model);
        }

        [HttpPost]
        public async Task<ApiModel> AddInerletter([FromBody] VMRelatedLetter model)
        {
            var result = await _relatedLetterService.AddRelatedLetterAsync(model);

            if (result.Success && result.Data is List<VMRelatedLetter> resultData)
            {
                foreach (var item in resultData)
                {
                    item.Links = new List<Links>
                    {
                        new Links
                        {
                            Href = Url.Action(nameof(GetById),"RelatedLetter",new { version = "1", Id = item.RelatedId },Request.Scheme),
                            Rel = "Self",
                            Method = "GET"
                        }
                    };
                }
            }

            return result;
        }


        [HttpDelete("{sematId:int}/{id:int}")]
        public async Task<ApiModel> DeleteRelatedLetter(int sematId,int id)
        {
            return await _relatedLetterService.DeleteRelatedLetterByIdAsync(sematId,id);
        }
    }
}
