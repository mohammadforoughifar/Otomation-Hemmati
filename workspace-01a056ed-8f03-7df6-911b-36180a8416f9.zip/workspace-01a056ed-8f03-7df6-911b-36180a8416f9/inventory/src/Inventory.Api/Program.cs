using System.Text;
using System.Text.Json;
using Inventory.Api.Controllers;
using Inventory.Api.Data;
using Inventory.Api.Hubs;
using Inventory.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// ================== تنظیمات دیتابیس ==================
// پیش‌فرض: SQL Server — برای توسعه/تست می‌توان Provider را روی Sqlite گذاشت.
var provider = builder.Configuration["Database:Provider"] ?? "SqlServer";
var connectionString = builder.Configuration.GetConnectionString("Default");

if (string.IsNullOrWhiteSpace(connectionString))
    throw new InvalidOperationException(
        "رشته اتصال دیتابیس پیدا نشد. لطفاً مقدار ConnectionStrings:Default را در appsettings.json تنظیم کنید.");

// لاگ راه‌اندازی (رمز عبور پوشیده می‌شود) برای اشکال‌زدایی اتصال
Console.WriteLine($"[DB] Provider = {provider}");
Console.WriteLine($"[DB] ConnectionString = {Mask(connectionString)}");

builder.Services.AddDbContext<AppDbContext>(options =>
{
    if (provider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
        options.UseSqlite(connectionString);
    else
        options.UseSqlServer(connectionString);
});

// ثبت سرویس‌ها با اینترفیس (اصل وارونگی وابستگی — DIP)
builder.Services.AddScoped<IInventoryService, InventoryService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IRepairService, RepairService>();
builder.Services.AddScoped<IExpenseService, ExpenseService>();
// ---------- اتوماسیون اداری — نامه داخلی ----------
builder.Services.AddScoped<IInnerLetterService, InnerLetterService>();
builder.Services.AddScoped<IErjaService, ErjaService>();
builder.Services.AddScoped<IPishnevisService, PishnevisService>();
builder.Services.AddScoped<ILetterGroupService, LetterGroupService>();

// ================== پیوست‌های پروژه — رمزنگاری AES روی دیسک ==================
builder.Services.AddSingleton<IProjectFileProtection, ProjectFileProtection>();

// ================== احراز هویت JWT ==================
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = AuthService.JwtIssuer,
            ValidAudience = AuthService.JwtIssuer,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AuthService.JwtKey))
        };
    });
builder.Services.AddAuthorization();

// CORS برای کلاینت Blazor WASM (در محیط توسعه)
builder.Services.AddCors(options =>
    options.AddPolicy("wasm", p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// کنترلرها + فیلتر سراسری خطا + JSON با نام‌گذاری camelCase
builder.Services.AddControllers(options =>
    {
        options.Filters.Add<ApiExceptionFilter>();
    })
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
    });

// ================== Swagger — مستندات و تست تعاملی API (/swagger) ==================
// ================== SignalR — داشبورد بلادرنگ ==================
builder.Services.AddSignalR().AddJsonProtocol(o =>
{
    o.PayloadSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
});
builder.Services.AddSingleton<DashboardBroadcaster>();
builder.Services.AddScoped<Inventory.Api.Hubs.INotifyService, Inventory.Api.Hubs.NotifyService>();
builder.Services.AddScoped<IMessengerService, MessengerService>();
builder.Services.AddHttpClient("messenger", c => c.Timeout = TimeSpan.FromSeconds(10));
builder.Services.AddSingleton<HardwareMonitor>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<HardwareMonitor>());

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "API برنامه انبار — فروغ آریا",
        Version = "v1",
        Description = "تست تعاملی همه‌ی سرویس‌ها — از جمله اسکن شبکه (/api/NetworkScan) و اسکن دوربین (/api/CctvScan)"
    });
});

var app = builder.Build();

// ساخت دیتابیس و داده اولیه (نه در زمان ابزارهای EF)
if (!EF.IsDesignTime)
    await DbInitializer.InitializeAsync(app);

// در همه‌ی محیط‌ها فعال است (حتی Production) تا روی هر سیستمی قابل تست باشد
app.UseSwagger();
app.UseSwaggerUI(o =>
{
    o.SwaggerEndpoint("/swagger/v1/swagger.json", "API انبار v1");
    o.DocumentTitle = "API برنامه انبار";
});

app.UseCors("wasm");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// هاب بلادرنگ داشبورد
app.MapHub<DashboardHub>("/hubs/dashboard");
app.MapHub<Inventory.Api.Hubs.NotifyHub>("/hubs/notify");

// سرو فایل‌های استاتیک کلاینت (استقرار تک‌سروره — در صورت وجود پوشه wwwroot)
var clientRoot = Path.Combine(app.Environment.ContentRootPath, "wwwroot");
if (Directory.Exists(clientRoot) && File.Exists(Path.Combine(clientRoot, "index.html")))
{
    // امنیت پیوست‌ها: فایل‌های رمزنگاری‌شده زیر wwwroot/SecureFiles هرگز به‌صورت استاتیک و بدون احراز هویت
    // سرو نشوند — دسترسی به آن‌ها فقط از مسیر API (ProjectAttachController با RBAC) مجاز است.
    app.Use(async (ctx, next) =>
    {
        if (ctx.Request.Path.StartsWithSegments("/SecureFiles", StringComparison.OrdinalIgnoreCase))
        {
            ctx.Response.StatusCode = StatusCodes.Status404NotFound;
            return;
        }
        await next();
    });
    app.UseDefaultFiles();
    // فایل‌های حیاتی SPA نباید در مرورگر کش شوند تا کاربران همیشه آخرین نسخه UI را بگیرند
    // (فایل‌های _framework خودشان با هش نسخه‌بندی می‌شوند و مشکلی ندارند)
    app.UseStaticFiles(new StaticFileOptions
    {
        OnPrepareResponse = ctx =>
        {
            var name = ctx.File.Name.ToLowerInvariant();
            if (name.EndsWith(".html") || name.EndsWith(".css") || name is "service-worker.js" or "service-worker-assets.js")
            {
                ctx.Context.Response.Headers.CacheControl = "no-cache, no-store, must-revalidate";
                ctx.Context.Response.Headers.Pragma = "no-cache";
                ctx.Context.Response.Headers.Expires = "0";
            }
        }
    });
    app.MapFallbackToFile("index.html");
}

// آدرس و پورت سرو — ترتیب اولویت برای هرکدام:
//   ۱) متغیر محیطی (PORT / HOST)  ۲) مقدار «Server:Port» و «Server:Host» در appsettings.json  ۳) پیش‌فرض
// نکته: Host=0.0.0.0 یعنی همه کارت‌های شبکه؛ برای محدود کردن به یک IP مشخص (مثل IP سرور) آن را در appsettings بگذارید.
var port = Environment.GetEnvironmentVariable("PORT")
           ?? app.Configuration["Server:Port"]
           ?? "5100";
var host = Environment.GetEnvironmentVariable("HOST")
           ?? app.Configuration["Server:Host"]
           ?? "0.0.0.0";
app.Run($"http://{host}:{port}");

// پوشاندن رمز عبور در لاگ رشته اتصال
static string Mask(string cs)
{
    foreach (var key in new[] { "Password", "Pwd", "User Id" })
    {
        var idx = cs.IndexOf(key + "=", StringComparison.OrdinalIgnoreCase);
        if (idx >= 0)
        {
            var valStart = idx + key.Length + 1;
            var end = cs.IndexOf(';', valStart);
            if (end < 0) end = cs.Length;
            return cs[..valStart] + "***" + cs[end..];
        }
    }
    return cs;
}
