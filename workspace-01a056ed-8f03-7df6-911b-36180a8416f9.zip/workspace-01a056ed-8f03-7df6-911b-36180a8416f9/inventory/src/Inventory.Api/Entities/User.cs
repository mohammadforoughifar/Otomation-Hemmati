using System.ComponentModel.DataAnnotations;
using Inventory.Shared;
namespace Inventory.Api.Data;
public class User
{
    public int Id { get; set; }
    [MaxLength(100)] public string Username { get; set; } = "";
    [MaxLength(200)] public string PasswordHash { get; set; } = "";
    [MaxLength(20)] public string Role { get; set; } = "Admin";
    public int? ReferrerId { get; set; }

    /// <summary>نام</summary>
    [MaxLength(100)] public string? FirstName { get; set; }

    /// <summary>نام خانوادگی</summary>
    [MaxLength(100)] public string? LastName { get; set; }

    /// <summary>شماره موبایل — برای ارسال پیام بله/ایتا</summary>
    [MaxLength(20)] public string? Mobile { get; set; }

    /// <summary>شناسه چت کاربر در پیام‌رسان بله (بعد از استارت ربات)</summary>
    [MaxLength(50)] public string? BaleChatId { get; set; }

    /// <summary>شناسه چت کاربر در پیام‌رسان ایتا</summary>
    [MaxLength(50)] public string? EitaaChatId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}