using System.Security.Cryptography;
using System.Text;

namespace Inventory.Api.Services;

/// <summary>
/// سرویس رمزنگاری پیوست‌های پروژه:
/// ۱) فایل‌ها با AES-256-GCM روی دیسک سرور رمزنگاری می‌شوند (نام فیزیکی تصادفی).
/// ۲) نام اصلی فایل هم رمزنگاری شده و در دیتابیس ذخیره می‌شود.
/// کلید از تنظیمات Files:EncryptionKey خوانده می‌شود؛ در صورت نبود، یک کلید تصادفی
/// در فایل .key داخل پوشه ذخیره‌سازی ساخته و نگهداری می‌شود (این فایل را بکاپ بگیرید!).
/// </summary>
public interface IProjectFileProtection
{
    /// <summary>رمزنگاری داده‌ها و ذخیره با نام تصادفی — خروجی: نام فایل ذخیره‌شده</summary>
    Task<string> EncryptAndStoreAsync(Stream data, CancellationToken ct = default);

    /// <summary>رمزگشایی فایل ذخیره‌شده — خروجی: استریم حاوی محتوای اصلی</summary>
    Task<MemoryStream> LoadAndDecryptAsync(string storedFileName, CancellationToken ct = default);

    /// <summary>رمزنگاری رشته (نام فایل) — خروجی Base64</summary>
    string EncryptString(string plain);

    /// <summary>رمزگشایی رشته (نام فایل)</summary>
    string DecryptString(string cipher);

    /// <summary>حذف فیزیکی فایل ذخیره‌شده</summary>
    void Delete(string storedFileName);

    /// <summary>مسیر کامل فایل ذخیره‌شده (جهت بررسی وجود)</summary>
    string GetPath(string storedFileName);
}

public class ProjectFileProtection : IProjectFileProtection
{
    private const int NonceSize = 12; // GCM استاندارد
    private const int TagSize = 16;

    private readonly byte[] _key;
    private readonly string _root;
    private readonly string _rootLegacy;

    public ProjectFileProtection(IConfiguration config, IWebHostEnvironment env)
    {
        var configuredRoot = config["Files:SecureRoot"];
        // محل ذخیره‌سازی فایل‌ها: زیر wwwroot/SecureFiles (درخواست کاربر)
        _root = string.IsNullOrWhiteSpace(configuredRoot)
            ? Path.Combine(env.ContentRootPath, "wwwroot", "SecureFiles")
            : configuredRoot;
        // مسیر قدیمی (در صورت وجود) — برای سازگاری با فایل‌های قبلی نگه‌داشته می‌شود
        _rootLegacy = string.IsNullOrWhiteSpace(configuredRoot)
            ? Path.Combine(env.ContentRootPath, "SecureFiles")
            : configuredRoot;
        Directory.CreateDirectory(_root);
        MigrateLegacyFiles();

        _key = LoadOrCreateKey(config["Files:EncryptionKey"]);
    }

    /// <summary>انتقال یک‌باره فایل‌های مسیر قدیمی (ContentRoot/SecureFiles) به مسیر جدید زیر wwwroot</summary>
    private void MigrateLegacyFiles()
    {
        try
        {
            if (string.Equals(_root, _rootLegacy, StringComparison.OrdinalIgnoreCase)) return;
            if (!Directory.Exists(_rootLegacy)) return;

            var moved = 0;
            foreach (var src in Directory.EnumerateFiles(_rootLegacy))
            {
                var dest = Path.Combine(_root, Path.GetFileName(src));
                // از جملهٔ فایل‌های مهم: «.key» (کلید رمزنگاری) — بدون آن فایل‌های قبلی باز نمی‌شوند
                if (File.Exists(dest)) continue;
                File.Copy(src, dest);
                moved++;
            }
            if (moved > 0)
                Console.WriteLine($"[SecureFiles] {moved} فایل از مسیر قدیمی به wwwroot/SecureFiles منتقل شد.");
        }
        catch (Exception ex)
        {
            // انتقال نباید مانع اجرای برنامه شود
            Console.WriteLine($"[SecureFiles] انتقال فایل‌های قدیمی ناموفق بود: {ex.Message}");
        }
    }

    private byte[] LoadOrCreateKey(string? configured)
    {
        if (!string.IsNullOrWhiteSpace(configured))
        {
            // هر رشته‌ای (Base64 یا عبارت عادی) با SHA256 به کلید ۳۲ بایتی تبدیل می‌شود
            return SHA256.HashData(Encoding.UTF8.GetBytes(configured));
        }

        var keyFile = Path.Combine(_root, ".key");
        if (File.Exists(keyFile))
            return Convert.FromBase64String(File.ReadAllText(keyFile).Trim());

        var key = RandomNumberGenerator.GetBytes(32);
        File.WriteAllText(keyFile, Convert.ToBase64String(key));
        return key;
    }

    // ==================== فایل ====================

    public async Task<string> EncryptAndStoreAsync(Stream data, CancellationToken ct = default)
    {
        using var plain = new MemoryStream();
        await data.CopyToAsync(plain, ct);
        var plainBytes = plain.ToArray();

        var nonce = RandomNumberGenerator.GetBytes(NonceSize);
        var cipher = new byte[plainBytes.Length];
        var tag = new byte[TagSize];

        using (var aes = new AesGcm(_key, TagSize))
            aes.Encrypt(nonce, plainBytes, cipher, tag);

        var storedName = $"{Guid.NewGuid():N}.bin";
        var path = GetPath(storedName);

        // چیدمان: [nonce][cipher][tag]
        await using (var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write))
        {
            await fs.WriteAsync(nonce, ct);
            await fs.WriteAsync(cipher, ct);
            await fs.WriteAsync(tag, ct);
        }
        return storedName;
    }

    public async Task<MemoryStream> LoadAndDecryptAsync(string storedFileName, CancellationToken ct = default)
    {
        var path = GetPath(storedFileName);
        if (!File.Exists(path)) throw new FileNotFoundException("فایل روی سرور پیدا نشد.", storedFileName);

        var all = await File.ReadAllBytesAsync(path, ct);
        if (all.Length < NonceSize + TagSize) throw new InvalidDataException("فایل پیوست معتبر نیست.");

        var nonce = all.AsMemory(0, NonceSize);
        var cipher = all.AsMemory(NonceSize, all.Length - NonceSize - TagSize);
        var tag = all.AsMemory(all.Length - TagSize, TagSize);

        var plain = new byte[cipher.Length];
        using (var aes = new AesGcm(_key, TagSize))
            aes.Decrypt(nonce.Span, cipher.Span, tag.Span, plain.AsSpan());

        return new MemoryStream(plain, writable: false);
    }

    public void Delete(string storedFileName)
    {
        var path = GetPath(storedFileName);
        if (File.Exists(path)) File.Delete(path);
    }

    public string GetPath(string storedFileName)
    {
        // جلوگیری از Path Traversal — فقط نام فایل مجاز است
        var safe = Path.GetFileName(storedFileName);
        var pNew = Path.Combine(_root, safe);
        // سازگاری: اگر فایل هنوز در مسیر قدیمی مانده (و منتقل نشده) همان را برگردان
        if (!File.Exists(pNew) && !string.Equals(_root, _rootLegacy, StringComparison.OrdinalIgnoreCase))
        {
            var pOld = Path.Combine(_rootLegacy, safe);
            if (File.Exists(pOld)) return pOld;
        }
        return pNew;
    }

    // ==================== رشته (نام فایل) ====================

    public string EncryptString(string plain)
    {
        var bytes = Encoding.UTF8.GetBytes(plain);
        var nonce = RandomNumberGenerator.GetBytes(NonceSize);
        var cipher = new byte[bytes.Length];
        var tag = new byte[TagSize];
        using (var aes = new AesGcm(_key, TagSize))
            aes.Encrypt(nonce, bytes, cipher, tag);
        var result = new byte[NonceSize + cipher.Length + TagSize];
        nonce.CopyTo(result, 0);
        cipher.CopyTo(result, NonceSize);
        tag.CopyTo(result, NonceSize + cipher.Length);
        return Convert.ToBase64String(result);
    }

    public string DecryptString(string cipherText)
    {
        var all = Convert.FromBase64String(cipherText);
        var nonce = all.AsMemory(0, NonceSize);
        var cipher = all.AsMemory(NonceSize, all.Length - NonceSize - TagSize);
        var tag = all.AsMemory(all.Length - TagSize, TagSize);
        var plain = new byte[cipher.Length];
        using (var aes = new AesGcm(_key, TagSize))
            aes.Decrypt(nonce.Span, cipher.Span, tag.Span, plain.AsSpan());
        return Encoding.UTF8.GetString(plain);
    }
}
