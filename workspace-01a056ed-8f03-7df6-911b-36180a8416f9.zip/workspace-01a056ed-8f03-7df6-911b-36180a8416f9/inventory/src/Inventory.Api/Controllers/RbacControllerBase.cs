using System.Security.Claims;
using Inventory.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Controllers;

/// <summary>
/// کنترلر پایه برای ماژول‌هایی که چک دسترسی دقیق (ماژول.اکشن) لازم دارند —
/// مثل WorkOrdersController: اگر کاربر نقش RBAC دارد از جداول RBAC چک می‌شود،
/// وگرنه نقش قدیمی (Admin=همه‌چیز، Operator=خواندنی/ایجاد) فال‌بک است.
/// </summary>
public abstract class RbacControllerBase : ApiControllerBase
{
    protected readonly AppDbContext Db;

    protected RbacControllerBase(AppDbContext db) => Db = db;

    protected int MyUserId =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var v) ? v : 0;

    protected string MyUsername => User.FindFirstValue(ClaimTypes.Name) ?? "";

    /// <summary>آیا کاربر جاری این مجوز را دارد؟ (مثال: HasAsync("Projects", "Create"))</summary>
    protected async Task<bool> HasAsync(string module, string action)
    {
        var hasRoles = await Db.UserRoles.AnyAsync(ur => ur.UserId == MyUserId);
        if (!hasRoles)
        {
            var legacy = User.FindFirstValue(ClaimTypes.Role);
            if (legacy == "Admin") return true;
            if (legacy == "Operator") return action is "Create" or "Read" or "Export" or "Erja";
            return false;
        }
        return await Db.UserRoles.Where(ur => ur.UserId == MyUserId)
            .Join(Db.RolePermissions, ur => ur.RoleId, rp => rp.RoleId, (ur, rp) => rp.PermissionId)
            .Join(Db.Permissions, pid => pid, p => p.Id, (pid, p) => p)
            .AnyAsync(p => p.Module == module && p.Action == action);
    }

    /// <summary>اگر مجوز را نداشت 403 می‌دهد.</summary>
    protected async Task<IActionResult?> ForbiddenUnlessAsync(string module, string action)
        => await HasAsync(module, action) ? null
           : StatusCode(403, new { message = "شما به این بخش دسترسی ندارید." });
}
