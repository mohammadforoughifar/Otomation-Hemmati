using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Api.Data;
using Inventory.Shared.Entities;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SystemUsersController : ControllerBase
{
    private readonly AppDbContext _db;
    public SystemUsersController(AppDbContext db) => _db = db;

    // ================== CRUD کاربران سیستم ==================

    [HttpGet]
    public async Task<ActionResult> Get() =>
        Ok(await _db.SystemUsers.OrderBy(u => u.Id).ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult> Get(int id)
    {
        var user = await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (user == null) return NotFound(new { message = "کاربر پیدا نشد." });
        return Ok(user);
    }

    [HttpPost]
    public async Task<ActionResult> Post([FromBody] SystemUser u)
    {
        if (string.IsNullOrWhiteSpace(u.FirstName))
            return BadRequest(new { message = "نام کاربر الزامی است." });

        u.Id = 0; // جلوگیری از خطای IDENTITY_INSERT
        if (u.CreatedAt == default) u.CreatedAt = DateTime.Now;

        _db.SystemUsers.Add(u);
        await _db.SaveChangesAsync();
        return Ok(new { id = u.Id });
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult> Put(int id, [FromBody] SystemUser u)
    {
        var item = await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound(new { message = "کاربر پیدا نشد." });

        item.Username = u.Username;
        item.FirstName = u.FirstName;
        item.LastName = u.LastName;
        item.StaffNumber = u.StaffNumber;
        item.DepartmentId = u.DepartmentId;
        item.CompanyId = u.CompanyId;
        item.Role = u.Role;
        item.IsActive = u.IsActive;

        await _db.SaveChangesAsync();
        return Ok();
    }

    [HttpDelete("{id:int}")]
    public async Task<ActionResult> Delete(int id)
    {
        var item = await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound(new { message = "کاربر پیدا نشد." });

        _db.SystemUsers.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }

    // توجه: تخصیص نقش (RBAC) از کاربران سیستم حذف شد —
    // نقش‌ها به کاربران «لاگین» (بخش کاربران) اختصاص داده می‌شوند.
}