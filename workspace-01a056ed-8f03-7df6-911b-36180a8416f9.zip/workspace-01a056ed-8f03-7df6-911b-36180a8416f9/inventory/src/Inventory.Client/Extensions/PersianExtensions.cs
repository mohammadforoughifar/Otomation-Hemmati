using Inventory.Shared;

namespace Inventory.Client.Extensions;

public static class PersianExtensions
{
    /// <summary>تاریخ شمسی کوتاه: 1403/05/12</summary>
    public static string ToFa(this DateTime dt) => PersianDate.ToShort(dt);

    /// <summary>تاریخ شمسی بلند: ۱۲ مرداد ۱۴۰۳</summary>
    public static string ToFaLong(this DateTime dt) => PersianDate.ToLong(dt);

    /// <summary>تاریخ و ساعت شمسی</summary>
    public static string ToFaDateTime(this DateTime dt) => PersianDate.ToShortDateTime(dt);

    /// <summary>مبلغ با ارقام فارسی و جداکننده هزارگان</summary>
    public static string Money(this decimal v) => Fa.Money(v);

    /// <summary>عدد صحیح با ارقام فارسی</summary>
    public static string Num(this decimal v) => Fa.Number(v);

    public static string Num(this int v) => Fa.Number(v);

    /// <summary>تاریخ شمسی کوتاه با ارقام فارسی: ۱۴۰۳/۰۵/۱۲</summary>
    public static string ToFaDate(this DateTime dt) => PersianDate.ToShortFa(dt);

    /// <summary>ارقام فارسی برای هر متن (مثلاً ساعت ۰۸:۳۰ یا تاریخ)</summary>
    public static string FaDigits(this string? s) => Fa.Digits(s);

    /// <summary>ارقام فارسی برای اعداد صحیح (بدون جداکننده هزارگان)</summary>
    public static string FaDigits(this int n) => Fa.Digits(n);

    /// <summary>بازه زمانی به‌صورت «H:MM» با ارقام فارسی (مثلاً ۸:۳۰)</summary>
    public static string HoursFa(this TimeSpan t) => Fa.Digits($"{(int)t.TotalHours}:{t.Minutes:00}");

    /// <summary>ساعت روز به‌صورت «HH:mm» با ارقام فارسی (مثلاً ۰۸:۰۰)</summary>
    public static string TimeFa(this TimeOnly t) => Fa.Digits(t.ToString("HH:mm"));
}
