namespace Inventory.Client.Services;

/// <summary>
/// داده‌های یک سند چاپی جدولی (گزارش‌های کار و …) که با window.printTableReport در JS چاپ می‌شود.
/// همه رشته‌ها باید قبل از ارسال فارسی‌سازی (ارقام فارسی/تاریخ شمسی) شده باشند.
/// </summary>
public sealed class PrintTableOptions
{
    /// <summary>عنوان اصلی سند</summary>
    public string Title { get; set; } = "";

    /// <summary>زیرعنوان (مثلاً نام پروژه)</summary>
    public string SubTitle { get; set; } = "";

    /// <summary>ردیف اطلاعات بالای جدول (هر آیتم یک برچسب کوچک می‌شود)</summary>
    public List<string> Meta { get; set; } = new();

    /// <summary>سرستون‌های جدول</summary>
    public List<string> Headers { get; set; } = new();

    /// <summary>ردیف‌های جدول — هر ردیف آرایه‌ای از سلول‌ها</summary>
    public List<List<string>> Rows { get; set; } = new();

    /// <summary>متن جمع پایانی (مثلاً «جمع ساعت خالص: ۱۲:۳۰ ساعت»)</summary>
    public string? FooterTotal { get; set; }

    /// <summary>زمان چاپ (رشته آماده با ارقام فارسی)</summary>
    public string PrintedAt { get; set; } = "";

    /// <summary>نام کاربر چاپ‌کننده</summary>
    public string PrintedBy { get; set; } = "";
}
