namespace Inventory.Client;

/// <summary>
/// اطلاعات نسخه سامانه — با هر تحویل به‌روزرسانی می‌شود تا روی صفحه ورود دیده شود
/// و مشخص باشد مرورگر واقعاً آخرین بیلد را اجرا می‌کند (تشخیص مشکل کش PWA).
/// </summary>
public static class AppInfo
{
    /// <summary>شماره نسخه تحویل</summary>
    public const string Version = "۷.۲";

    /// <summary>تاریخ تحویل (شمسی)</summary>
    public const string BuildDateFa = "۱۴۰۵/۰۶/۰۳";

    /// <summary>متن کامل نمایشی: «نسخه ۷.۱ — ۱۴۰۵/۰۶/۰۲»</summary>
    public static string Display => $"نسخه {Version} — {BuildDateFa}";
}
